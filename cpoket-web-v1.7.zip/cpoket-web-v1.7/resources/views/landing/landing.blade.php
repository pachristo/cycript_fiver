@extends('landing.master',['menu'=>'dashboard'])
@section('title', isset($title) ? $title : '')
@section('style')
@endsection
@section('content')

{{-- banner --}}
<section class="banner-area" id="banner-area">
    {{-- <div class="banner-right-img" >
        <img class="animation-img" 
             src="{{landingPageImage('landing_page_logo','images/banner/hero.svg')}}" alt="banner">
    </div> --}}
    <div class="container">
        <div class="banner-wrap">
            <div class="row">
                <div class="col-lg-6 col-md-12">
                    <div class="banner-text">
                        <div class="banner-title" data-aos="fade-down" data-aos-duration="2000">
                            <h1>@if(isset($content['landing_title'])) {!!clean($content['landing_title']) !!} @else {{__('Mine Crypto Currency and Earn Coin Easily')}} @endif</h1>
                        </div>
                        <div class="banner-content" data-aos="fade-down" data-aos-duration="3000">
                           <p>
                               @if(isset($content['landing_description'])) {!!clean($content['landing_description']) !!} @else {{__('There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration.There are many There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration')}} @endif
                           </p>
                        </div>
                        <div class="banner-btn" data-aos="fade-down" data-aos-duration="3000">
                            <a href="{{$content['landing_1st_button_link'] ?? ''}}" class="primary-btn">{{__('Token Distribution')}}</a>
                            <a href="{{$content['landing_2nd_button_link'] ?? ''}}" class="primary-btn">{{__('Whitepaper')}}</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="white_svg svg_white">
        <svg x="0px" y="0px" viewBox="0 0 1920 289" enable-background="new 0 0 1920 289" xml:space="preserve">
        <path fill="#0f4571" d="M959,169C582.541,169,240.253,104.804-14.125,0H0v289h1920V0h12.125C1677.747,104.804,1335.459,169,959,169
            z"></path>
       </svg>
    </div>
</section>
<!-- banner area end here -->
<!-- client-area start -->
<div class="client-area">
    <div class="container">
        <div class="client-item">
            <div class="Gift-carousel owl-carousel">
                @if(isset($coins))
                    @foreach($coins as $coin)
                        <div class="client-logo">
                            <i class="fa fa-bitcoin"></i>
                            {!! clean($coin->name) !!}
                        </div>
                    @endforeach
                @else
                <img src="{{landingPageImage('landing_client_logo','images/client/1.png')}}" alt="clientlogo">
                <img src="{{landingPageImage('landing_client_logo','images/client/2.png')}}" alt="clientlogo">
                <img src="{{landingPageImage('landing_client_logo','images/client/3.png')}}" alt="clinet">
                <img src="{{landingPageImage('landing_client_logo','images/client/4.png')}}" alt="clinet">
                <img src="{{landingPageImage('landing_client_logo','images/client/5.png')}}" alt="clinet">
                @endif
            </div>
        </div>
    </div>
    <div class="white_svg svg_white">
        <svg x="0px" y="0px" viewBox="0 0 1920 289" enable-background="new 0 0 1920 289" xml:space="preserve">
        <path fill="#316593" d="M959,169C582.541,169,240.253,104.804-14.125,0H0v289h1920V0h12.125C1677.747,104.804,1335.459,169,959,169
            z"></path>
       </svg>
    </div>
</div>
<!-- client-area end -->

<!-- feature area start here -->
<section class="feature-area section" id="features">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="section-title">
                    <h2>
                        @if(isset($content['landing_feature_title'])) {!! $content['landing_feature_title'] !!} @else {{__('Why Choose Cpocket ?')}} @endif
                    </h2>
                    <span class="separator"></span>
                    <p>
                        @if(isset($content['landing_feature_subtitle'])) {!!clean($content['landing_feature_subtitle']) !!} @else {{__('There are many variations of passages of Lorem Ipsum available, but the majority')}} @endif
                    </p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-4 col-md-6 mb-30">
                <div class="single-feature text-center" data-aos="fade-up" data-aos-duration="2000">
                    <div class="feature-icon">
                        <img src="{{landingPageImage('1st_feature_icon','images/feature/1.svg')}}" alt="">
                    </div>
                    <div class="feature-title">
                        <h3>
                            @if(isset($content['1st_feature_title'])) {!! $content['1st_feature_title'] !!} @else {{__('Instant Exchange')}} @endif
                        </h3>
                    </div>
                    <div class="feature-content">
                        <p>
                            @if(isset($content['1st_feature_subtitle'])) {!!clean($content['1st_feature_subtitle']) !!} @else {{__('The point of using Lorem Ipsum is that it has or-less normal distribution letters, as opposed Content here.')}} @endif
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="single-feature text-center mb-3" data-aos="fade-up" data-aos-duration="2500">
                    <div class="feature-icon">
                        <img src="{{landingPageImage('2nd_feature_icon','images/feature/2.svg')}}" alt="">
                    </div>
                    <div class="feature-title">
                        <h3>
                            @if(isset($content['2nd_feature_title'])) {!! $content['2nd_feature_title'] !!} @else {{__('Instant Cashout')}} @endif
                        </h3>
                    </div>
                    <div class="feature-content">
                        <p>
                            @if(isset($content['2nd_feature_subtitle'])) {!!clean($content['2nd_feature_subtitle']) !!} @else {{__('The point of using Lorem Ipsum is that it has or-less normal distribution letters, as opposed Content here.')}} @endif
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="single-feature text-center mb-3" data-aos="fade-up" data-aos-duration="2500">
                    <div class="feature-icon">
                        <img src="{{landingPageImage('3rd_feature_icon','images/feature/3.svg')}}" alt="">
                    </div>
                    <div class="feature-title">
                        <h3>
                            @if(isset($content['3rd_feature_title'])) {!! $content['3rd_feature_title'] !!} @else {{__('Safe & Secure')}} @endif
                        </h3>
                    </div>
                    <div class="feature-content">
                        <p>
                            @if(isset($content['3rd_feature_subtitle'])) {!!clean($content['3rd_feature_subtitle']) !!} @else {{__('The point of using Lorem Ipsum is that it has or-less normal distribution letters, as opposed Content here.')}} @endif
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="white_svg svg_white">
        <svg x="0px" y="0px" viewBox="0 0 1920 289" enable-background="new 0 0 1920 289" xml:space="preserve">
        <path fill="#0f4571" d="M959,169C582.541,169,240.253,104.804-14.125,0H0v289h1920V0h12.125C1677.747,104.804,1335.459,169,959,169
            z"></path>
       </svg>
    </div>
</section>
<!-- feature area end here -->
<!-- about us area start here -->
<section class="about-us-area section" id="about">
    <div class="white_svg svg_white">
        <svg x="0px" y="0px" viewBox="0 0 1920 289" enable-background="new 0 0 1920 289" xml:space="preserve">
        <path fill="#316593" d="M959,169C582.541,169,240.253,104.804-14.125,0H0v289h1920V0h12.125C1677.747,104.804,1335.459,169,959,169
            z"></path>
       </svg>
    </div>
    <div class="container">
        <div class="row align-items-center about-1">
            <div class="col-lg-6">
                <div class="about-wrap">
                    <div class="about-img">
                        <img class="animation-img" src="{{landingPageImage('about_1st_logo','images/banner/ab2.svg')}}" alt="banner" alt="">
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="about-text">
                    <h2>
                        @if(isset($content['about_1st_title'])) {!! $content['about_1st_title'] !!} @else {{__('We’ve built a platform to buy and sell shares.')}} @endif
                    </h2>
                    <p>
                        @if(isset($content['about_1st_description'])) {!!clean($content['about_1st_description']) !!} @else {{__('While existing solutions offer to solve just one problem at a time, our team is up to build a secure, useful, & easy-to-use product based on private blockchain. It will include easy cryptocurrency payments integration, and even a digital arbitration system. At the end, Our aims to integrate all companies, employees, and business assets into a unified blockchain ecosystem, which will make business truly efficient, transparent, and reliable.')}} @endif
                    </p>

                </div>
            </div>
        </div>
        <div class="row align-items-center">
            <div class="col-lg-6">
                <div class="about-text">
                    <h2>
                        @if(isset($content['about_2nd_title'])) {!! $content['about_2nd_title'] !!} @else {{__('We’ve built a platform to buy and sell shares.')}} @endif
                    </h2>
                    <p>
                        @if(isset($content['about_2nd_description'])) {!!clean($content['about_2nd_description']) !!} @else {{__('While existing solutions offer to solve just one problem at a time, our team is up to build a secure, useful, & easy-to-use product based on private blockchain. It will include easy cryptocurrency payments integration, and even a digital arbitration system. At the end, Our aims to integrate all companies, employees, and business assets into a unified blockchain ecosystem, which will make business truly efficient, transparent, and reliable.')}} @endif
                    </p>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="about-wrap">
                    <div class="about-img">
                        <img class="animation-img" src="{{landingPageImage('about_2nd_logo','images/banner/ab3.svg')}}" alt="banner" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- about us area end here -->
<section id="roadmap" class="section roadmap-area">
    <div class="white_svg svg_white">
        <svg x="0px" y="0px" viewBox="0 0 1920 289" enable-background="new 0 0 1920 289" xml:space="preserve">
        <path fill="#0f4571" d="M959,169C582.541,169,240.253,104.804-14.125,0H0v289h1920V0h12.125C1677.747,104.804,1335.459,169,959,169
            z"></path>
       </svg>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="section-title">
                    <h2>
                        @if(isset($content['landing_roadmap_title'])) {{$content['landing_roadmap_title'] }} @else {{__('Project Roadmap')}} @endif
                    </h2>
                    <span class="separator"></span>
                    <p>
                        @if(isset($content['landing_roadmap_subtitle'])) {!!clean($content['landing_roadmap_subtitle']) !!} @else {{__('There are many variations of passages of Lorem Ipsum available, but the majority')}} @endif
                    </p>
                </div>
            </div>
        </div>
        <div class="timeline">
            <div class="container">
              <div class="row">
                <div class="col-lg-12">
                  <div class="timeline-container">
                    <div class="timeline-end">
                      <p>Now</p>
                    </div>
                    <div class="timeline-continue">
          
                      <div class="row timeline-right">
                        <div class="col-md-6">
                          <p class="timeline-date">
                            @if(isset($content['roadmap_1st_date'])) {!!clean($content['roadmap_1st_date']) !!} @else {{__('JUNE 2020')}} @endif
                          </p>
                        </div>
                        <div class="col-md-6">
                          <div class="timeline-box">
                            <div class="timeline-icon">
                                <i class="fa fa-file-code-o" aria-hidden="true"></i>
                            </div>
                            <div class="timeline-text">
                              <h3>@if(isset($content['roadmap_1st_title'])) {!! $content['roadmap_1st_title'] !!} @else {{__('Project Concept')}} @endif</h3>
                                <p>
                                    @if(isset($content['roadmap_1st_title'])) {!!clean($content['roadmap_1st_title']) !!} @else {{__('Lorem ipsum dolor sit amet, consectetur adipiscing elit.')}} @endif
                                </p>
                            </div>
                          </div>
                        </div>
                      </div>
          
                      <div class="row timeline-left">
                        <div class="col-md-6 d-md-none d-block">
                          <p class="timeline-date dfgderg">
                            @if(isset($content['roadmap_2nd_date'])) {!!clean($content['roadmap_2nd_date']) !!} @else {{__('SEPTEMBER 2020')}}@endif
                          </p>
                        </div>
                        <div class="col-md-6">
                          <div class="timeline-box">
                            <div class="timeline-icon d-md-none d-block">
                              <i class="fa fa-bullhorn" aria-hidden="true"></i>
                            </div>
                            <div class="timeline-text">
                                <h3>
                                    @if(isset($content['roadmap_2nd_title'])) {!! $content['roadmap_2nd_title'] !!} @else {{__('Platform Launch')}} @endif
                                </h3>
                                <p>
                                    @if(isset($content['roadmap_2nd_subtitle'])) {!!clean($content['roadmap_2nd_subtitle']) !!} @else {{__('Lorem ipsum dolor sit amet, consectetur adipiscing elit.')}} @endif
                                </p>
                            </div>
                            <div class="timeline-icon d-md-block d-none">
                              <i class="fa fa-bullhorn" aria-hidden="true"></i>
                            </div>
                          </div>
                        </div>
                        <div class="col-md-6 d-md-block d-none">
                          <p class="timeline-date">
                            @if(isset($content['roadmap_2nd_date'])) {!!clean($content['roadmap_2nd_date']) !!} @else {{__('SEPTEMBER 2020')}}@endif
                          </p>
                        </div>
                      </div>
          
                      <div class="row">
                        <div class="col-12">
                          <div class="timeline-year">
                            <p>2020</p>
                          </div>
                        </div>
                      </div>
          
                      <div class="row timeline-right">
                        <div class="col-md-6">
                          <p class="timeline-date">
                            @if(isset($content['roadmap_3rd_date'])) {!!clean($content['roadmap_3rd_date']) !!} @else {{__('January 2020')}}@endif
                          </p>
                        </div>
                        <div class="col-md-6">
                          <div class="timeline-box">
                            <div class="timeline-icon">
                                <i class="fa fa-paper-plane" aria-hidden="true"></i>
                            </div>
                            <div class="timeline-text">
                                <h3>
                                    @if(isset($content['roadmap_3rd_title'])) {!! $content['roadmap_3rd_title'] !!} @else {{__('Published Whitepaper')}} @endif
                                </h3>
                                <p>
                                    @if(isset($content['roadmap_3rd_subtitle'])) {!!clean($content['roadmap_3rd_subtitle']) !!} @else {{__('Lorem ipsum dolor sit amet, consectetur adipiscing elit.')}} @endif
                                </p>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="row timeline-left">
                        <div class="col-md-6 d-md-none d-block">
                          <p class="timeline-date">
                            @if(isset($content['roadmap_4th_date'])) {!!clean($content['roadmap_4th_date']) !!} @else {{__('March 2020')}}@endif
                          </p>
                        </div>
                        <div class="col-md-6">
                          <div class="timeline-box">
                            <div class="timeline-icon d-md-none d-block">
                              <i class="fa fa-credit-card" aria-hidden="true"></i>
                            </div>
                            <div class="timeline-text">
                                <h3>
                                    @if(isset($content['roadmap_4th_title'])) {!! $content['roadmap_4th_title'] !!} @else {{__('First Pre-Sale')}} @endif
                                </h3>
                                <p>
                                    @if(isset($content['roadmap_4th_subtitle'])) {!!clean($content['roadmap_4th_subtitle']) !!} @else {{__('Lorem ipsum dolor sit amet, consectetur adipiscing elit.')}} @endif
                                </p>
                            </div>
                            <div class="timeline-icon d-md-block d-none">
                             <i class="fa fa-credit-card" aria-hidden="true"></i>
                            </div>
                          </div>
                        </div>
                        <div class="col-md-6 d-md-block d-none">
                          <p class="timeline-date">
                            @if(isset($content['roadmap_4th_date'])) {!!clean($content['roadmap_4th_date']) !!} @else {{__('March 2020')}}@endif
                          </p>
                        </div>
                      </div>
          
                      <div class="row timeline-right">
                        <div class="col-md-6">
                          <p class="timeline-date">
                            @if(isset($content['roadmap_5th_date'])) {!!clean($content['roadmap_5th_date']) !!} @else {{__('May 2020')}}@endif
                          </p>
                        </div>
                        <div class="col-md-6">
                          <div class="timeline-box">
                            <div class="timeline-icon">
                                <i class="fa fa-mobile" aria-hidden="true"></i>
                            </div>
                            <div class="timeline-text">
                                <h3>
                                    @if(isset($content['roadmap_5th_title'])) {!! $content['roadmap_5th_title'] !!} @else {{__('Mobile App Release')}} @endif
                                </h3>
                                <p>
                                    @if(isset($content['roadmap_5th_subtitle'])) {!!clean($content['roadmap_5th_subtitle']) !!} @else {{__('Lorem ipsum dolor sit amet, consectetur adipiscing elit.')}} @endif
                                </p>
                            </div>
                          </div>
                        </div>
                      </div>
          
                    </div>
                    <div class="timeline-start">
                      <p>Launch</p>
                    </div>
                    <div class="timeline-launch">
                      <div class="timeline-box">
                        <div class="timeline-text">
                          <h3>@if(isset($content['roadmap_current_date'])) {!!clean($content['roadmap_current_date']) !!} @else {{__('Now')}}@endif</h3>
                          <p>@if(isset($content['roadmap_current_title'])) {!!clean($content['roadmap_current_title']) !!} @else {{__('ICO Launch')}}@endif</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
    </div>
    <!-- // container -->

</section>
<!-- integration area start here -->
<section class="integration-area section" id="integration">
    <div class="container">
        <div class="integration-top">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-12">
                    <div class="integration-info mb-30">
                        <h2>
                            @if(isset($content['landing_integration_title'])) {!! $content['landing_integration_title'] !!} @else {{__('Easy Customization & Secure Payment System.')}} @endif
                        </h2>
                        <p>
                            @if(isset($content['landing_integration_description'])) {!!clean($content['landing_integration_description']) !!} @else {{__('Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy when Lorem Ipsum is simply dummy text of the printing and typesetting industry I completely follow all your instructions.')}} @endif
                        </p>
                        <a href="{{$content['landing_integration_button_link'] ?? '' }}" class="primary-btn">{{__('Know More')}}</a>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12">
                    <div class="integration-img">
                        <img data-aos="zoom-in" class="animation-img" data-aos-duration="3000" src="{{landingPageImage('landing_integration_page_logo','images/banner/ab3.png')}}" alt="integration">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="white_svg svg_white">
        <svg x="0px" y="0px" viewBox="0 0 1920 289" enable-background="new 0 0 1920 289" xml:space="preserve">
        <path fill="#316593" d="M959,169C582.541,169,240.253,104.804-14.125,0H0v289h1920V0h12.125C1677.747,104.804,1335.459,169,959,169
            z"></path>
       </svg>
    </div>
</section>
<!-- integration area end here -->
<section id="faq" class="faq-area section">
    <div class="container">
        <div class="faq-wrap">
            <div class="row">
                <div class="col-12">
                    <div class="section-title">
                        <h2>{{__('Frequently Asked Question')}}</h2>
                    </div>
                </div>
            </div>
            <div class="row">
              <div class="col-12">
                <div class="faq-info choose-info">
                  <div class="accordion" id="accordionDorbar">
                      @if(isset($faqs))
                          @foreach($faqs as $faq)
                              <div class="card">
                                  <div class="card-header" id="heading{{$faq->id}}">
                                      <h5 class="mb-0">
                                          <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapse{{$faq->id}}" aria-expanded="true" aria-controls="collapse{{$faq->id}}">
                                              {!! clean($faq->question) !!}
                                          </button>
                                      </h5>
                                  </div>
                                  <div id="collapse{{$faq->id}}" class="collapse" aria-labelledby="heading{{$faq->id}}" data-parent="#accordionDorbar">
                                      <div class="card-body">
                                          {!! clean($faq->answer) !!}
                                      </div>
                                  </div>
                              </div>
                          @endforeach
                      @else
                        <div class="card">
                          <div class="card-header" id="headingOne">
                            <h5 class="mb-0">
                              <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                  What cryptocurrencies can I use to purchase?
                              </button>
                            </h5>
                          </div>
                          <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionDorbar">
                            <div class="card-body">
                              Lorem ipsum dolor sit amet, conubia eu tellus blandit at tincidunt fibus quam, urna bibendum lobortis platea, nec sed quis, vestibulum lortis adipisicing, nunc mattis.
                            </div>
                          </div>
                        </div>
                        <div class="card">
                          <div class="card-header" id="headingTwo">
                            <h5 class="mb-0">
                              <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                  How can I participate in the ICO?
                              </button>
                            </h5>
                          </div>
                          <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionDorbar">
                            <div class="card-body">
                              Lorem ipsum dolor sit amet, conubia eu tellus blandit at tincidunt fibus quam, urna bibendum lobortis platea, nec sed quis, vestibulum lortis adipisicing, nunc mattis.
                            </div>
                          </div>
                        </div>
                        <div class="card">
                          <div class="card-header" id="headingThree">
                            <h5 class="mb-0">
                              <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                  How to create LBT wallet?
                              </button>
                            </h5>
                          </div>
                          <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionDorbar">
                            <div class="card-body">
                              Lorem ipsum dolor sit amet, conubia eu tellus blandit at tincidunt fibus quam, urna bibendum lobortis platea, nec sed quis, vestibulum lortis adipisicing, nunc mattis.
                            </div>
                          </div>
                        </div>
                      @endif
                  </div>
                </div>
              </div>
            </div>
        </div>
    </div>
    <div class="white_svg svg_white">
        <svg x="0px" y="0px" viewBox="0 0 1920 289" enable-background="new 0 0 1920 289" xml:space="preserve">
        <path fill="#0f4571" d="M959,169C582.541,169,240.253,104.804-14.125,0H0v289h1920V0h12.125C1677.747,104.804,1335.459,169,959,169
            z"></path>
       </svg>
    </div>
</section>
<div id="contact" class="contact-page-area section-padding">
    <div class="white_svg svg_white">
        <svg x="0px" y="0px" viewBox="0 0 1920 289" enable-background="new 0 0 1920 289" xml:space="preserve">
        <path fill="#316593" d="M959,169C582.541,169,240.253,104.804-14.125,0H0v289h1920V0h12.125C1677.747,104.804,1335.459,169,959,169
            z"></path>
       </svg>
    </div>
    <div class="container">
         <div class="row">
             <div class="col-lg-12 col-md-12">
                 <div class="contact-page-item">
                     <div class="contact-page-title">
                         <h2>
                             @if(isset($content['contact_title'])) {{$content['contact_title']}} @else {{__('Our Contacts')}} @endif
                         </h2>
                         <p>
                             @if(isset($content['contact_sub_title'])) {!!clean($content['contact_sub_title']) !!} @else {{__('Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.')}} @endif
                         </p>
                     </div>
                     <div class="row">
                         <div class="col-lg-4">
                            <div class="adress contact-info-item">
                                <span><img src="{{landingPageImage('1st_feature_icon','images/feature/pin.svg')}}" alt=""></span>
                                <h3>
                                    @if(isset($content['address_field_title'])) {{$content['address_field_title']}} @else {{__('Address')}} @endif
                                </h3>
                                <span>
                                    @if(isset($content['address_field_details'])) {!!clean($content['address_field_details']) !!} @else {{__('245 King Street, Touterie Victoria 8520 Australia')}} @endif
                                </span>
                            </div>
                         </div>
                         <div class="col-lg-4">
                            <div class="phone contact-info-item">
                                <span><img src="{{landingPageImage('1st_feature_icon','images/feature/call.svg')}}" alt=""></span>
                                <h3>
                                    @if(isset($content['phone_field_title'])) {{$content['phone_field_title']}} @else {{__('Phone')}} @endif
                                </h3>
                                <span>
                                    @if(isset($content['phone_field_details'])) {!!clean($content['phone_field_details']) !!} @else {{__('0-123-456-7890')}} @endif</span>
       {{--                         <span>0-123-456-7890</span>--}}
                            </div>
                         </div>
                         <div class="col-lg-4">
                            <div class="email contact-info-item">
                                <span><img src="{{landingPageImage('1st_feature_icon','images/feature/email.svg')}}" alt=""></span>
                                <h3>
                                    @if(isset($content['email_field_title'])) {{$content['email_field_title']}} @else {{__('Email')}} @endif
                                </h3>
                                <span>
                                    @if(isset($content['email_field_details'])) {!!clean($content['email_field_details']) !!} @else {{__('sample@gmail.com')}} @endif
                                </span>
                            </div>
                         </div>
                     </div>
                     
                 </div>
             </div>
             <div class="col-lg-12 col-md-12">
                 <div class="contact-area contact-area-2 contact-area-3">
                     <h2>{{__('Quick Contact Form')}}</h2>
                     <div class="contact-form">
                         <form method="post" class="contact-validation-active" action="{{route('ContactUs')}}" id="contact-form" novalidate="novalidate">
                             {{ csrf_field() }}
                             <div class="half-col">
                                 <input type="text" name="name" id="name" value="{{old('name')}}" class="form-control" placeholder="{{__('Your Name')}}">
                                 <p>@error('name') <span class="text-danger">{{ $message }}</span> @enderror</p>
                             </div>

                             <div class="half-col">
                                 <input type="email" name="email" value="{{old('email')}}" id="email" class="form-control" placeholder="{{__('Your Email')}}">
                                 <p>@error('email') <span class="text-danger">{{ $message }}</span> @enderror</p>
                             </div>
                             <div class="half-col">
                                 <input type="text" name="phone" id="phone" value="{{old('phone')}}" class="form-control" placeholder="{{__('Your Phone')}}">
                                 <p>@error('phone') <span class="text-danger">{{ $message }}</span> @enderror</p>
                             </div>
                             <div class="half-col">
                                 <input type="text" name="address" id="address" value="{{old('address')}}" class="form-control" placeholder="{{__('Address')}}">
                                 <p>@error('address') <span class="text-danger">{{ $message }}</span> @enderror</p>
                             </div>
                             <div>
                                 <textarea class="form-control" name="description" id="note" placeholder="{{__('Case Description...')}}">{{old('description')}}</textarea>
                                 <p>@error('description') <span class="text-danger">{{ $message }}</span> @enderror</p>
                             </div>
                             <div class="submit-btn-wrapper">
                                 <button type="submit" class="primary-btn submit_contact_form">{{__('Submit')}}</button>
                             </div>
                         </form>
                     </div>
                 </div>
             </div>
         </div>
     </div>
</div>
@endsection

@section('script')
@endsection
