<?php echo $__env->make('email.header_new', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h3><?php echo e(__('Hello')); ?>, <?php echo e(isset($user) ? $user->first_name.' '.$user->last_name : ''); ?></h3>
<p>
    You are receiving this email because we received a password reset request for your account.
    Please use the code below to reset your password.
</p>
<p style="text-align:center;font-size:30px;font-weight:bold">
    <?php echo e($token); ?>

</p>
<p>You can change your password with this link :: <a href="<?php echo e(route('resetPasswordPage')); ?>">Click Here</a></p>

<p>
    <?php echo e(__('Thanks a lot for being with us.')); ?> <br/>
    <?php echo e(allSetting()['app_title']); ?>

</p>
<?php echo $__env->make('email.footer_new', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/cpoket-web/resources/views/email/password_reset.blade.php ENDPATH**/ ?>