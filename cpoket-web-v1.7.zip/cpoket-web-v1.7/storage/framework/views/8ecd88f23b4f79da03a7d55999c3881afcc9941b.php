<?php $__env->startSection('title', isset($title) ? $title : ''); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- breadcrumb -->
    <!-- breadcrumb -->
    <div class="custom-breadcrumb">
        <div class="row">
            <div class="col-12">
                <ul>
                    <li><?php echo e(__('Coin')); ?></li>
                    <li class="active-item"><?php echo e(__('UNBC Transfer History')); ?></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- /breadcrumb -->

    <!-- User Management -->
    <div class="user-management padding-30">
        <div class="row">
            <div class="col-12">
                <div class="header-bar mt-5">
                    <div class="table-title">
                        <h3><?php echo e(__('Give Coin History')); ?></h3>
                    </div>
                </div>
                <div class="table-area">
                    <div>
                        <table id="table" class="table-responsive table table-borderless custom-table display text-center" width="100%">
                            <thead>
                            <tr>
                                <th><?php echo e(__('Sender')); ?></th>
                                <th><?php echo e(__('Receiver')); ?></th>
                                <th><?php echo e(__('Amount ')); ?> (<?php echo e(settings('coin_name')); ?>)</th>
                                <th><?php echo e(__('Amount ')); ?> (<?php echo e(isset(settings()['currency']) ? settings()['currency'] : 'USD'); ?>)</th>
                                <th><?php echo e(__('Fees')); ?></th>
                                <th><?php echo e(__('Type')); ?></th>
                                <th><?php echo e(__('Address')); ?></th>
                                <th><?php echo e(__('IBAN')); ?></th>
                                <th><?php echo e(__('Beneficiary')); ?></th>
                                <th><?php echo e(__('Status')); ?></th>
                                <th><?php echo e(__('Created At')); ?></th>
                                <th><?php echo e(__('Actions')); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /User Management -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $('#table').DataTable({
            processing: true,
            serverSide: true,
            pageLength: 10,
            retrieve: true,
            bLengthChange: true,
            responsive: false,
            ajax: '<?php echo e(route('adminTransferCoinHistory')); ?>',
            order: [9, 'desc'],
            autoWidth: false,
            language: {
                paginate: {
                    next: 'Next &#8250;',
                    previous: '&#8249; Previous'
                }
            },
            columns: [
                {"data": "sender_user_id","orderable": true},
                {"data": "admin_wallet_id","orderable": true},
                {"data": "amount","orderable": true},
                {"data": "amount_in_dollar","orderable": true},
                {"data": "fees","orderable": true},
                {"data": "type","orderable": false},
                {"data": "address","orderable": true},
                {"data": "iban","orderable": true},
                {"data": "beneficiary","orderable": true},
                {"data": "status","orderable": false},
                {"data": "created_at","orderable": true},
                {"data": "actions","orderable": false},
            ],
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master',['menu'=>'buy_coin','sub_menu'=>'transfer_coin_history'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/cpoket-web/resources/views/admin/coin-order/transfer_coin_history.blade.php ENDPATH**/ ?>