<?php if(isset($wallets[0])): ?>
    <div class="mn-tp">
        <span><?php echo e(__('Swap with')); ?></span>
    </div>
    <button type="button" class="swip-button">
        <span  class="swip-img"><p><?php echo e(__('Select')); ?></p></span>
    </button>
    <ul class="sh">
        <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li data-to_wallet_id="<?php echo e($wallet->wallet_id); ?>" class="swip-item" data-from_coin_type="<?php echo e($wallet->type); ?>">
                <span class="swip-img">
                <p><?php echo e($wallet->wallet_name .'('.check_default_coin_type($wallet->type) .')'); ?></p>
                </span>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php else: ?>
    <div class="mn-tp">
        <span class="text-warning"><?php echo e(__('Please add some wallet with BTC,ETH,DOGE etc coin type first then try to convert')); ?></span>
    </div>
<?php endif; ?>
<?php /**PATH /var/www/html/cpoket-web/resources/views/user/pocket/swap_wallet_list.blade.php ENDPATH**/ ?>