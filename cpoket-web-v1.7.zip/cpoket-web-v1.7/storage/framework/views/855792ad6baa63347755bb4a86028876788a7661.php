<?php $__env->startSection('title', isset($title) ? $title : ''); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- breadcrumb -->
    <div class="custom-breadcrumb">
        <div class="row">
            <div class="col-9">
                <ul>
                    <li><?php echo e(__('Coin')); ?></li>
                    <li class="active-item"><?php echo e($title); ?></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- /breadcrumb -->

    <!-- User Management -->
    <div class="user-management">
        <div class="row">
            <div class="col-12">
                <div class="header-bar p-4">
                    <div class="table-title">
                        <h3><?php echo e($title); ?></h3>
                    </div>
                </div>
                <div class="table-area">
                    <div>
                        <table id="table" class=" table table-borderless custom-table display text-center" width="100%">
                            <thead>
                            <tr>
                                <th scope="col"><?php echo e(__('Coin Name')); ?></th>
                                <th scope="col"><?php echo e(__('Coin Type')); ?></th>
                                <th scope="col"><?php echo e(__('Status')); ?></th>
                                <th scope="col"><?php echo e(__('Updated At')); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if(isset($coins)): ?>
                            <?php $__currentLoopData = $coins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td> <?php echo e($coin->name); ?> </td>
                                    <td> <?php echo e($coin->type); ?> </td>
                                    <td>
                                        <div>
                                            <label class="switch">
                                                <input type="checkbox" onclick="return processForm('<?php echo e($coin->id); ?>')"
                                                       id="notification" name="security" <?php if($coin->status == STATUS_ACTIVE): ?> checked <?php endif; ?>>
                                                <span class="slider" for="status"></span>
                                            </label>
                                        </div>
                                    </td>
                                    <td> <?php echo e($coin->updated_at); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /User Management -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function processForm(active_id) {
            console.log(active_id)
            $.ajax({
                type: "POST",
                url: "<?php echo e(route('adminCoinStatus')); ?>",
                data: {
                    '_token': "<?php echo e(csrf_token()); ?>",
                    'active_id': active_id
                },
                success: function (data) {
                    console.log(data);
                }
            });
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master',['menu'=>'coin'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/cpoket-web/resources/views/admin/coin-order/coin.blade.php ENDPATH**/ ?>