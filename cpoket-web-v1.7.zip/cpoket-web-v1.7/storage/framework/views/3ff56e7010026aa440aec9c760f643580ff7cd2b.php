<?php $__env->startSection('title', isset($title) ? $title : ''); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xl-12 mb-xl-0 mb-4">
            <div class="card cp-user-custom-card">
                <div class="card-body">
                    <div class="cp-user-card-header-area">
                        <h4><?php echo e(__('UNBC Transfer History')); ?></h4>
                    </div>
                    <div class="cp-user-buy-coin-content-area">
                        <div class="cp-user-wallet-table table-responsive">
                            <table id="table" class="table">
                                <thead>
                                <tr>
                                    <th><?php echo e(__('Sender')); ?></th>
                                    <th><?php echo e(__('Amount ')); ?> (<?php echo e(settings('coin_name')); ?>)</th>
                                    <th><?php echo e(__('Amount ')); ?> (<?php echo e(isset(settings()['currency']) ? settings()['currency'] : 'USD'); ?>)</th>
                                    <th><?php echo e(__('Fees')); ?></th>
                                    <th><?php echo e(__('Type')); ?></th>
                                    <th><?php echo e(__('Address')); ?></th>
                                    <th><?php echo e(__('IBAN')); ?></th>
                                    <th><?php echo e(__('Beneficiary')); ?></th>
                                    <th><?php echo e(__('Status')); ?></th>
                                    <th><?php echo e(__('Created At')); ?></th>
                                </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $('#table').DataTable({
            processing: true,
            serverSide: true,
            pageLength: 10,
            retrieve: true,
            bLengthChange: true,
            responsive: true,
            ajax: '<?php echo e(route('transferCoinHistory')); ?>',
            order: [9, 'desc'],
            autoWidth: false,
            language: {
                paginate: {
                    next: 'Next &#8250;',
                    previous: '&#8249; Previous'
                }
            },
            columns: [
                {"data": "sender_user_id","orderable": true},
                {"data": "amount","orderable": true},
                {"data": "amount_in_dollar","orderable": true},
                {"data": "fees","orderable": true},
                {"data": "type","orderable": false},
                {"data": "address","orderable": true},
                {"data": "iban","orderable": true},
                {"data": "beneficiary","orderable": true},
                {"data": "status","orderable": false},
                {"data": "created_at","orderable": true},
            ],
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.master',['menu'=>'coin_request','sub_menu'=>'transfer_coin_history'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/cpoket-web/resources/views/user/request_coin/coin_transfer_history.blade.php ENDPATH**/ ?>