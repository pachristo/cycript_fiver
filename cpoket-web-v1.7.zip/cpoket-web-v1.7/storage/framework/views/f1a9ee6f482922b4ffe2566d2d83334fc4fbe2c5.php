<!DOCTYPE HTML>
<html class="no-js" lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="The Highly Secured Bitcoin Wallet">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta property="og:type" content="article" />
    <meta property="og:title" content="<?php echo e(allsetting('app_title')); ?>"/>
    <meta property="og:image" content="<?php echo e(asset('assets/user/images/logo.svg')); ?>">
    <meta property="og:site_name" content="Cpoket"/>
    <meta property="og:url" content="<?php echo e(url()->current()); ?>"/>
    <meta property="og:type" content="<?php echo e(allsetting('app_title')); ?>"/>
    <meta itemscope itemtype="<?php echo e(url()->current()); ?>/<?php echo e(allsetting('app_title')); ?>" />
    <meta itemprop="headline" content="<?php echo e(allsetting('app_title')); ?>" />
    <meta itemprop="image" content="<?php echo e(asset('assets/user/images/logo.svg')); ?>" />
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/user/css/bootstrap.min.css')); ?>">
    <!-- metismenu CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/user/css/metisMenu.min.css')); ?>">
    
    <link href="<?php echo e(asset('assets/toast/vanillatoasts.css')); ?>" rel="stylesheet" >
    <!-- Datatable CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/user/css/datatable/datatables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/user/css/datatable/dataTables.bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/user/css/datatable/dataTables.jqueryui.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/user/css/datatable/jquery.dataTables.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/user/css/jquery.scrollbar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/user/css/font-awesome.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/user/css/jquery.countdown.css')); ?>">


    
    <link rel="stylesheet" href="<?php echo e(asset('assets/dropify/dropify.css')); ?>">

    <!-- Style CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/user/style.css')); ?>">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/user/css/responsive.css')); ?>">

    <?php echo $__env->yieldContent('style'); ?>
    <title><?php echo e(allsetting('app_title')); ?>::<?php echo $__env->yieldContent('title'); ?></title>
    <!-- Favicon and Touch Icons -->
    <link rel="shortcut icon" href="<?php echo e(landingPageImage('favicon','images/fav.png')); ?>/">
</head>

<body class="cp-user-body-bg">
<?php $clubInfo = get_plan_info(Auth::id()) ?>
<!-- top bar -->
<div class="cp-user-top-bar">
    <div class="cp-user-sidebar-toggler">
        <img src="<?php echo e(asset('assets/user/images/menu.svg')); ?>" class="img-fluid d-lg-none d-block" alt="">
    </div>
    <div class="container-fluid">
        <div class="row align-items-center justify-content-between">
            <div class="col-xl-2 col-lg-2 d-lg-block d-none">
                <div class="cp-user-logo">
                    <a href="<?php echo e(route('userDashboard')); ?>">
                        <img src="<?php echo e(show_image(Auth::id(),'logo')); ?>" class="img-fluid cp-user-logo-large" alt="">
                    </a>
                </div>
            </div>
            <?php
                $notifications = \App\Model\Notification::where(['user_id'=> Auth::user()->id, 'status' => 0])->orderBy('id', 'desc')->get();
            ?>
            <?php
                $balance = getUserBalance(Auth::id());
                $activity = \App\Model\ActivityLog::where(['user_id' => Auth::id(), 'action' => USER_ACTIVITY_LOGIN])->first();
            ?>
            <div class="col-xl-8 col-lg-7 col-md-9">
                <ul class="cp-user-top-bar-status-area">
                    <li class="cp-user-date-time">
                        <p class="cp-user-title"><?php echo e(__('Date & Time')); ?></p>
                        <div class="cp-user-content">
                            <p class="cp-user-last-visit"><span><?php echo e(__('Last Visit')); ?> :</span> <?php echo e(date('F j, Y, g:i a', strtotime($activity->created_at))); ?></p>
                            <p class="cp-user-today"><span><?php echo e(__('Today')); ?> :</span> <?php echo e(date("F j, Y, g:i a")); ?></p>
                        </div>
                    </li>
                    <li class="cp-user-available-balance">
                        <p class="cp-user-title"><?php echo e(__('Available Balance')); ?></p>
                        <div class="cp-user-content">
                            <p class="cp-user-btc"><span><?php echo e(number_format($balance['available_coin'],2)); ?></span> <?php echo e(allsetting('coin_name')); ?></p>
                            <p class="cp-user-usd"><span><?php echo e(number_format($balance['available_used'],2)); ?></span> <?php echo e(__('USD')); ?></p>
                        </div>
                    </li>
                    <li class="cp-user-available-balance">
                        <p class="cp-user-title"><?php echo e(__('Blocked Coin')); ?></p>
                        <div class="cp-user-content">
                            <p class="cp-user-btc"><span><?php echo e(number_format(get_blocked_coin(Auth::id()),2)); ?></span> <?php echo e(allsetting('coin_name')); ?></p>
                        </div>
                    </li>
                    <li class="cp-user-pending-withdrawal">
                        <p class="cp-user-title"><?php echo e(__('Membership Status')); ?></p>
                        <div class="cp-user-content">
                            <p class="cp-user-btc">
                                <?php if(!empty($clubInfo['club_id'])): ?>
                                <span>
                                    <img src="<?php echo e($clubInfo['plan_image']); ?>" class="img-fluid" alt="">
                                </span>
                                <?php echo e($clubInfo['plan_name']); ?>

                                <?php else: ?>
                                    <span class="text-warning"><?php echo e(__("No Membership yet")); ?></span>
                                <?php endif; ?>
                            </p>
                        </div>
                    </li>
                </ul>
            </div>
            <div class="col-xl-2 col-lg-3 col-md-3">
                <div class="cp-user-top-bar-right">
                    <ul>
                        <li class="hm-notify" id="notification_item">
                            <div class="btn-group dropdown">
                                <button type="button" class="btn notification-btn dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <span class="notify-value hm-notify-number"><?php if(isset($notifications) && ($notifications ->count() > 0)): ?> <?php echo e($notifications->count()); ?> <?php else: ?> 0 <?php endif; ?></span>
                                    <img src="<?php echo e(asset('assets/img/icons/notification.png')); ?>" class="img-fluid" alt="">
                                </button>
                                <?php if(!empty($notifications)): ?>
                                    <div class="dropdown-menu notification-list dropdown-menu-right">
                                        <div class="text-center p-2 border-bottom nt-title"><?php echo e(__('New Notifications')); ?></div>
                                        <ul class="scrollbar-inner">
                                            <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <a href="javascript:void(0);" data-toggle="modal" data-id="<?php echo e($item->id); ?>" data-target="#notificationShow" class="dropdown-item viewNotice">
                                                        <span class="small d-block"><?php echo e(date('d M y', strtotime($item->created_at))); ?></span>
                                                        <?php echo e($item->title); ?>

                                                    </a>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </li>
                        <li>
                            <div class="btn-group profile-dropdown">
                                <button type="button" class="btn dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <span class="cp-user-avater">
                                        <span class="cp-user-img">
                                            <img src="<?php echo e(show_image(Auth::user()->id,'user')); ?>" class="img-fluid" alt="">
                                        </span>
                                        <span class="cp-user-avater-info">

                                        </span>
                                    </span>
                                </button>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <span class="big-user-thumb">
                                        <img src="<?php echo e(show_image(Auth::user()->id,'user')); ?>" class="img-fluid" alt="">
                                    </span>
                                    <div class="user-name">
                                        <p><?php echo e(Auth::user()->first_name.' '.Auth::user()->last_name); ?></p>
                                    </div>
                                    <button class="dropdown-item" type="button"><a href="<?php echo e(route('userProfile')); ?>"><i class="fa fa-user-circle-o"></i> <?php echo e(__('Profile')); ?></a></button>
                                    <button class="dropdown-item" type="button"><a href="<?php echo e(route('userSetting')); ?>"><i class="fa fa-cog"></i> <?php echo e(__('My Settings')); ?></a></button>
                                    <button class="dropdown-item" type="button"><a href="<?php echo e(route('myPocket')); ?>"><i class="fa fa-credit-card"></i> <?php echo e(__('My Pocket')); ?></a></button>
                                    <button class="dropdown-item" type="button"><a href="<?php echo e(route('logOut')); ?>"><i class="fa fa-sign-out"></i> <?php echo e(__('Logout')); ?></a></button>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /top bar -->

<!-- Start sidebar -->
<div class="cp-user-sidebar">
    <div class="mb-sidebar-toggler">
        <img src="<?php echo e(asset('assets/user/images/menu.svg')); ?>" class="img-fluid d-lg-none d-block" alt="">
    </div>
    <!-- logo -->
    <div class="cp-user-logo d-lg-none d-block my-4">
        <a href="i<?php echo e(route('userDashboard')); ?>">
            <img src="<?php echo e(show_image(Auth::user()->id,'logo')); ?>" class="img-fluid cp-user-logo-large" alt="">
        </a>
    </div>
    <!-- /logo -->


    <!-- sidebar menu -->
    <div class="cp-user-sidebar-menu scrollbar-inner">
        <nav>
            <ul id="metismenu">
                <li class="<?php if(isset($menu) && $menu == 'dashboard'): ?> cp-user-active-page <?php endif; ?>">
                    <a href="<?php echo e(route('userDashboard')); ?>">
                            <span class="cp-user-icon">
                                <img src="<?php echo e(asset('assets/user/images/sidebar-icons/dashboard.svg')); ?>" class="img-fluid cp-user-side-bar-icon" alt="">
                                <img src="<?php echo e(asset('assets/user/images/sidebar-icons/hover/dashboard.svg')); ?>" class="img-fluid cp-user-side-bar-icon-hover" alt="">
                            </span>
                        <span class="cp-user-name"><?php echo e(__('Dashboard')); ?></span>
                    </a>
                </li>
                <li class=" <?php if(isset($menu) && $menu == 'coin'): ?> cp-user-active-page mm-active <?php endif; ?>">
                    <a class="arrow-icon" href="#" aria-expanded="true">
                        <span class="cp-user-icon">
                            <img src="<?php echo e(asset('assets/user/images/sidebar-icons/buy_coin.svg')); ?>" class="img-fluid cp-user-side-bar-icon" alt="">
                            <img src="<?php echo e(asset('assets/user/images/sidebar-icons/hover/buy_coin.svg')); ?>" class="img-fluid cp-user-side-bar-icon-hover" alt="">
                        </span>
                        <span class="cp-user-name"><?php echo e(__('Buy Coin')); ?></span>
                    </a>
                    <ul class=" <?php if(isset($menu) && $menu == 'coin'): ?> mm-show <?php endif; ?>">
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'buy_coin'): ?> cp-user-submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('buyCoin')); ?>"><?php echo e(__('Buy Coin')); ?></a>
                        </li>
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'buy_coin_history'): ?> cp-user-submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('buyCoinHistory')); ?>"><?php echo e(__('Buy Coin History')); ?></a>
                        </li>
                    </ul>
                </li>
                <li class=" <?php if(isset($menu) && $menu == 'coin_request'): ?> cp-user-active-page mm-active <?php endif; ?>">
                    <a class="arrow-icon" href="#" aria-expanded="true">
                        <span class="cp-user-icon">
                            <img src="<?php echo e(asset('assets/user/images/sidebar-icons/coin.svg')); ?>" class="img-fluid cp-user-side-bar-icon" alt="">
                            <img src="<?php echo e(asset('assets/user/images/sidebar-icons/hover/coin.svg')); ?>" class="img-fluid cp-user-side-bar-icon-hover" alt="">
                        </span>
                        <span class="cp-user-name"><?php echo e(__(' Send/Receive')); ?></span>
                    </a>
                    <ul class=" <?php if(isset($menu) && $menu == 'coin_request'): ?> mm-show <?php endif; ?>">
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'give_coin'): ?> cp-user-submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('requestCoin')); ?>"><?php echo e(__('Send/Request Coin')); ?></a>
                        </li>
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'give_request_history'): ?> cp-user-submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('giveCoinHistory')); ?>"><?php echo e(__('Send History')); ?></a>
                        </li>
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'received_history'): ?> cp-user-submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('receiveCoinHistory')); ?>"><?php echo e(__('Receive History')); ?></a>
                        </li>
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'pending_request'): ?> cp-user-submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('pendingRequest')); ?>"><?php echo e(__('Pending Request')); ?></a>
                        </li>
                    </ul>
                </li>
                <li class="<?php if(isset($menu) && $menu == 'pocket'): ?> cp-user-active-page mm-active  <?php endif; ?>">
                    <a class="arrow-icon" href="#" aria-expanded="true">
                        <span class="cp-user-icon">
                            <img src="<?php echo e(asset('assets/user/images/sidebar-icons/Wallet.svg')); ?>" class="img-fluid cp-user-side-bar-icon" alt="">
                            <img src="<?php echo e(asset('assets/user/images/sidebar-icons/hover/Wallet.svg')); ?>" class="img-fluid cp-user-side-bar-icon-hover" alt="">
                        </span>
                        <span class="cp-user-name"><?php echo e(__('Pocket')); ?></span>
                    </a>
                    <ul class="<?php if(isset($menu) && $menu == 'pocket'): ?>  mm-show  <?php endif; ?>">
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'my_pocket'): ?> cp-user-submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('myPocket')); ?>"><?php echo e(__('My Pocket')); ?></a>
                        </li>
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'swap_history'): ?> cp-user-submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('coinSwapHistory')); ?>"><?php echo e(__('Swap History')); ?></a>
                        </li>
                    </ul>
                </li>
                <li class="<?php if(isset($menu) && $menu == 'coin_swap'): ?> cp-user-active-page <?php endif; ?>">
                    <a href="<?php echo e(route('coinSwap')); ?>">
                        <span class="cp-user-icon">
                            <img src="<?php echo e(asset('assets/user/images/sidebar-icons/buy_coin.svg')); ?>" class="img-fluid cp-user-side-bar-icon" alt="">
                            <img src="<?php echo e(asset('assets/user/images/sidebar-icons/hover/buy_coin.svg')); ?>" class="img-fluid cp-user-side-bar-icon-hover" alt="">
                        </span>
                        <span class="cp-user-name"><?php echo e(__('Swap Coin')); ?></span>
                    </a>
                </li>
                <li class="<?php if(isset($menu) && $menu == 'member'): ?> cp-user-active-page mm-active  <?php endif; ?>">
                    <a class="arrow-icon" href="#" aria-expanded="true">
                        <span class="cp-user-icon">
                            <img src="<?php echo e(asset('assets/user/images/sidebar-icons/Membership.svg')); ?>" class="img-fluid cp-user-side-bar-icon" alt="">
                            <img src="<?php echo e(asset('assets/user/images/sidebar-icons/hover/Membership-1.svg')); ?>" class="img-fluid cp-user-side-bar-icon-hover" alt="">
                        </span>
                        <span class="cp-user-name"><?php echo e(__('Membership Club')); ?></span>
                    </a>
                    <ul class="<?php if(isset($menu) && $menu == 'member'): ?>  mm-show  <?php endif; ?>">
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'coin_transfer'): ?> cp-user-submenu-active <?php endif; ?>"><a href="<?php echo e(route('membershipClubPlan')); ?>"><?php echo e(__('Transfer Coin')); ?></a></li>
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'my_membership'): ?> cp-user-submenu-active <?php endif; ?>"><a href="<?php echo e(route('myMembership')); ?>"><?php echo e(__('My Membership')); ?></a></li>
                    </ul>
                </li>
                <li class="<?php if(isset($menu) && $menu == 'profile'): ?> cp-user-active-page <?php endif; ?>">
                    <a href="<?php echo e(route('userProfile')); ?>">
                            <span class="cp-user-icon">
                                <img src="<?php echo e(asset('assets/user/images/sidebar-icons/user.svg')); ?>" class="img-fluid cp-user-side-bar-icon" alt="">
                                <img src="<?php echo e(asset('assets/user/images/sidebar-icons/hover/user.svg')); ?>" class="img-fluid cp-user-side-bar-icon-hover" alt="">
                            </span>
                        <span class="cp-user-name"><?php echo e(__('My Profile')); ?></span>
                    </a>
                </li>
                <li class="<?php if(isset($menu) && $menu == 'referral'): ?> cp-user-active-page <?php endif; ?>">
                    <a href="<?php echo e(route('myReferral')); ?>">
                            <span class="cp-user-icon">
                                <img src="<?php echo e(asset('assets/user/images/sidebar-icons/referral.svg')); ?>" class="img-fluid cp-user-side-bar-icon" alt="">
                                <img src="<?php echo e(asset('assets/user/images/sidebar-icons/hover/referral.svg')); ?>" class="img-fluid cp-user-side-bar-icon-hover" alt="">
                            </span>
                        <span class="cp-user-name"><?php echo e(__('My Referral')); ?></span>
                    </a>
                </li>
                <li class="<?php if(isset($menu) && $menu == 'setting'): ?> cp-user-active-page mm-active <?php endif; ?>">
                    <a class="arrow-icon" href="#" aria-expanded="true">
                        <span class="cp-user-icon">
                            <img src="<?php echo e(asset('assets/user/images/sidebar-icons/settings.svg')); ?>" class="img-fluid cp-user-side-bar-icon" alt="">
                            <img src="<?php echo e(asset('assets/user/images/sidebar-icons/hover/settings.svg')); ?>" class="img-fluid cp-user-side-bar-icon-hover" alt="">
                        </span>
                        <span class="cp-user-name"><?php echo e(__('Settings')); ?></span>
                    </a>
                    <ul class="<?php if(isset($menu) && $menu == 'setting'): ?>  mm-show  <?php endif; ?>">
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'setting'): ?> cp-user-submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('userSetting')); ?>"><?php echo e(__('My Settings')); ?></a>
                        </li>
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'faq'): ?> cp-user-submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('userFaq')); ?>"><?php echo e(__('FAQ')); ?></a>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>
        <div class="nav-bottom-img">
            <img src="<?php echo e(asset('assets/user/images/sidebar-coin-img.svg')); ?>" alt="">
        </div>
    </div><!-- /sidebar menu -->

</div>
<!-- End sidebar -->



<div class="modal fade" id="notificationShow" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content dark-modal">
            <div class="modal-header align-items-center">
                <h5 class="modal-title" id="exampleModalCenterTitle"><?php echo e(__('New Notification')); ?>  </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>

            <div class="modal-body">
                <div class="hm-form">
                    <div class="row">
                        <div class="col-12">
                            <h6 id="n_title"></h6>
                            <p id="n_date"></p>
                            <p id="n_notice"></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- main wrapper -->
<div class="cp-user-main-wrapper">
    <div class="container-fluid">





        <div class="alert alert-success alert-dismissible fade show d-none" role="alert" id="web_socket_notification">
            <span id="socket_message"></span>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>

        <div class="modal fade" id="confirm-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <img src="<?php echo e(asset('assets/user/images/close.svg')); ?>" class="img-fluid" alt="">
                    </button>
                    <div class="text-center">
                        <img src="<?php echo e(asset('assets/user/images/add-pockaet-vector.svg')); ?>" class="img-fluid img-vector" alt="">
                        <h3 id="confirm-title"></h3>
                    </div>
                    <div class="modal-body">
                        <a id="confirm-link" href="#" class="btn btn-block cp-user-move-btn"><?php echo e(__('Confirm')); ?></a>
                    </div>
                </div>
            </div>
        </div>

        <?php echo $__env->yieldContent('content'); ?>
    </div>
</div>
<!-- /main wrapper -->

<!-- js file start -->

<!-- JavaScript -->
<script src="<?php echo e(asset('assets/user/js/jquery.min.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="<?php echo e(asset('assets/user/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/user/js/metisMenu.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/toast/vanillatoasts.js')); ?>"></script>
<!-- Datatable -->
<script src="<?php echo e(asset('assets/user/js/datatable/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/user/js/datatable/dataTables.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/user/js/datatable/dataTables.jqueryui.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/user/js/datatable/jquery.dataTables.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/user/js/jquery.scrollbar.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/user/js/jquery.plugin.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/user/js/jquery.countdown.min.js')); ?>"></script>


<script src="<?php echo e(asset('assets/dropify/dropify.js')); ?>"></script>
<script src="<?php echo e(asset('assets/dropify/form-file-uploads.js')); ?>"></script>

<script src="<?php echo e(asset('assets/user/js/main.js')); ?>"></script>

<script src="https://js.pusher.com/3.0/pusher.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/laravel-echo/1.8.1/echo.iife.min.js"></script>
<script>
    let my_env_socket_port = "<?php echo e(env('BROADCAST_PORT')); ?>";
    Pusher.logToConsole = true;
    window.Echo = new Echo({
        broadcaster: 'pusher',
        wsHost: window.location.hostname,
        wsPort: my_env_socket_port,
        wssPort: 443,
        key: '<?php echo e(env('PUSHER_APP_KEY')); ?>',
        cluster: 'mt1',
        encrypted: false,
        disableStats: true
    });
</script>
<script>

    Pusher.logToConsole = true;

    Echo.channel('usernotification_' + '<?php echo e(Auth::id()); ?>')
        .listen('.receive_notification', (data) => {
            console.log(data);
            if (data.success == true) {
                let message = data.message
                $('#web_socket_notification').removeClass('d-none');
                $('#socket_message').html(message);

                $.ajax({
                    type: "GET",
                    url: '<?php echo e(route('getNotification')); ?>',
                    data: {
                        '_token': '<?php echo e(csrf_token()); ?>',
                        'user_id': data.user_id,
                    },
                    success: function (datas) {
                        $('#notification_item').html(datas.data)
                    }
                });
            }
        });
</script>
<script>
    $(document).ready(function() {
        $('.cp-user-custom-table').DataTable({
            responsive: true,
            paging: true,
            searching: true,
            ordering:  true,
            select: false,
            bDestroy: true
        });


    });
</script>
<?php if(session()->has('success')): ?>
    <script>
        window.onload = function () {
            VanillaToasts.create({
                //  title: 'Message Title',
                text: '<?php echo e(session('success')); ?>',
                backgroundColor: "linear-gradient(135deg, #73a5ff, #5477f5)",
                type: 'success',
                timeout: 10000
            });
        }

    </script>

<?php elseif(session()->has('dismiss')): ?>
    <script>
        window.onload = function () {

            VanillaToasts.create({
                // title: 'Message Title',
                text: '<?php echo e(session('dismiss')); ?>',
                type: 'warning',
                timeout: 10000

            });
        }
    </script>

<?php elseif($errors->any()): ?>
    <?php $__currentLoopData = $errors->getMessages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <script>
            window.onload = function () {
                VanillaToasts.create({
                    // title: 'Message Title2',
                    text: '<?php echo e($error[0]); ?>',
                    type: 'warning',
                    timeout: 10000

                });
            }
        </script>

        <?php break; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php endif; ?>

<script>
    $(document).on('click', '.viewNotice', function (e) {
        var id = $(this).data('id');
        // alert(id);
        $.ajax({
            type: "GET",
            url: '<?php echo e(route('showNotification')); ?>',
            data: {
                '_token': '<?php echo e(csrf_token()); ?>',
                'id': id,
            },
            success: function (data) {
                console.log(data);
                $("#n_title").text(data['data']['title']);
                $("#n_date").text(data['data']['date']);
                $("#n_notice").text(data['data']['notice']);

                $('#notification_item').html(data['data']['html'])
            }
        });
    });
</script>


<script>
    $(document).on("click", ".confirm-modal", function (){
        $("#confirm-title").text($(this).data('title'));
        $("#confirm-link").attr('href', $(this).data('href'));
        $("#confirm-modal").modal("show");
    });
</script>
<!-- End js file -->
<?php echo $__env->yieldContent('script'); ?>
</body>
</html>

<?php /**PATH /var/www/html/cpoket-web/resources/views/user/master.blade.php ENDPATH**/ ?>