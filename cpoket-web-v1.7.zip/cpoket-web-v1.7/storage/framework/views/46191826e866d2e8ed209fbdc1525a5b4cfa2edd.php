<?php $__env->startSection('title', isset($title) ? $title : ''); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card cp-user-custom-card cp-user-wallet-card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="cp-user-card-header-area">
                                <div class="cp-user-title">
                                    <h4><?php echo e(__('Send/Request Coin')); ?></h4>
                                </div>
                            </div>
                            <div class="clap-wrap mt-5">

                                <ul class="nav nav-pills transfer-tabs my-3" id="pills-tab" role="tablist">
                                    <li class="nav-item" role="presentation">
                                        <a class="nav-link <?php if($qr == 'requests'): ?> active <?php endif; ?>" id="pills-transfer-1-tab" data-toggle="pill"
                                           href="#pills-transfer-1" role="tab" aria-controls="pills-transfer-1"
                                           aria-selected="true"><?php echo e(__('UNBC Request')); ?></a>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <a class="nav-link <?php if($qr == 'give'): ?> active <?php endif; ?>" id="pills-transfer-2-tab" data-toggle="pill"
                                           href="#pills-transfer-2" role="tab" aria-controls="pills-transfer-2"
                                           aria-selected="false"><?php echo e(__('Send UNBC')); ?></a>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <a class="nav-link <?php if($qr == 'transfer'): ?> active <?php endif; ?>" id="pills-transfer-3-tab" data-toggle="pill"
                                           href="#pills-transfer-3" role="tab" aria-controls="pills-transfer-3"
                                           aria-selected="false"><?php echo e(__('Transfer UNBC')); ?></a>
                                    </li>
                                </ul>
                                <div class="tab-content" id="pills-tabContent">
                                    <div class="tab-pane fade <?php if($qr == 'requests'): ?> show active <?php endif; ?>" id="pills-transfer-1" role="tabpanel"
                                         aria-labelledby="pills-transfer-1-tab">
                                        <div class="cp-user-card-header-area d-block">
                                            <div class="cp-user-title">
                                                <h4><?php echo e(__('Send UNBC Request To User Using Email Address')); ?></h4>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="cp-user-profile-info">
                                                        <form class="mt-4" method="POST"
                                                              action="<?php echo e(route('sendCoinRequest')); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <div class="form-group mt-4">
                                                                <label><?php echo e(__('User Email')); ?></label>
                                                                <input name="email" type="email" placeholder="<?php echo e(__('User Email')); ?>"
                                                                       class="form-control " value="<?php echo e(old('email')); ?>">
                                                                <span class="text-warning" style="font-weight: 700;"><?php echo e(__('Note : ')); ?></span>
                                                                <span class="text-warning"><?php echo e(__('Input user email where you want to send request for coin.')); ?></span>
                                                            </div>
                                                            <div class="form-group mt-4">
                                                                <label><?php echo e(__('Coin Amount')); ?></label>
                                                                <input name="amount" type="text" placeholder="<?php echo e(__('Coin')); ?>"
                                                                       class="form-control number_only" value="<?php echo e(old('amount')); ?>">
                                                                <span class="text-warning" style="font-weight: 700;"><?php echo e(__('Minimum amount : ')); ?></span>
                                                                <span class="text-warning"><?php echo e(settings('minimum_withdrawal_amount')); ?> <?php echo e(settings('coin_name')); ?></span>
                                                                <span class="text-warning"><?php echo e(__(' and ')); ?></span>
                                                                <span class="text-warning" style="font-weight: 700;"><?php echo e(__('Maximum amount : ')); ?></span>
                                                                <span class="text-warning"><?php echo e(settings('maximum_withdrawal_amount')); ?> <?php echo e(settings('coin_name')); ?></span>
                                                            </div>
                                                            <div class="form-group m-0">
                                                                <button class="btn theme-btn"
                                                                        type="submit"><?php echo e(__('Send UNBC')); ?></button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade <?php if($qr == 'give'): ?> show active <?php endif; ?>" id="pills-transfer-2" role="tabpanel"
                                         aria-labelledby="pills-transfer-2-tab">

                                        <div class="cp-user-card-header-area">
                                            <div class="cp-user-title">
                                                <h4><?php echo e(__('Send UNBC To User From Your Wallet To User Primary Wallet Using Email Address')); ?></h4>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="cp-user-profile-info">
                                                    <form class="mt-4" method="POST" action="<?php echo e(route('giveCoin')); ?>"
                                                          onsubmit="return submitResult();">
                                                        <?php echo csrf_field(); ?>
                                                        <div class="form-group mt-4">
                                                            <label><?php echo e(__('Select Your Wallet')); ?></label>
                                                            <div class="cp-select-area">
                                                                <select name="wallet_id" class="form-control" id="">
                                                                    <option value=""><?php echo e(__('Select')); ?></option>
                                                                    <?php if(isset($wallets[0])): ?>
                                                                        <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($wallet->id); ?>"> <?php echo e($wallet->name); ?>

                                                                                (<?php echo e(number_format($wallet->balance,2)); ?>)
                                                                            </option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php endif; ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="form-group mt-4">
                                                            <label><?php echo e(__('Coin Amount')); ?></label>
                                                            <input name="amount" type="text" placeholder="<?php echo e(__('Coin')); ?>"
                                                                   class="form-control">
                                                            <span class="text-warning" style="font-weight: 700;"><?php echo e(__('Minimum send amount : ')); ?></span>
                                                            <span class="text-warning"><?php echo e(settings('minimum_withdrawal_amount')); ?> <?php echo e(settings('coin_name')); ?></span>
                                                            <span class="text-warning"><?php echo e(__(' and ')); ?></span>
                                                            <span class="text-warning" style="font-weight: 700;"><?php echo e(__('Maximum send amount : ')); ?></span>
                                                            <span class="text-warning"><?php echo e(settings('maximum_withdrawal_amount')); ?> <?php echo e(settings('coin_name')); ?></span>
                                                        </div>
                                                        <div class="form-group mt-4">
                                                            <label><?php echo e(__('User Email')); ?></label>
                                                            <input name="email" type="email" placeholder="<?php echo e(__('User Email')); ?>"
                                                                   class="form-control ">
                                                            <span class="text-warning" style="font-weight: 700;"><?php echo e(__('Note : ')); ?></span>
                                                            <span class="text-warning"><?php echo e(__('Input user email where you want to send coin. Coin will send to his/her primary wallet.')); ?></span>
                                                        </div>

                                                        <div class="form-group m-0">
                                                            <button class="btn btn-info theme-btn"
                                                                    type="submit"><?php echo e(__('Send UNBC')); ?></button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="tab-pane fade <?php if($qr == 'transfer'): ?> show active <?php endif; ?>" id="pills-transfer-3" role="tabpanel"
                                         aria-labelledby="pills-transfer-3-tab">

                                        <div class="cp-user-card-header-area">
                                            <div class="cp-user-title">
                                                <h4><?php echo e(__('Send UNBC To User From Your Wallet To User Primary Wallet Using Email Address')); ?></h4>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="cp-user-profile-info">
                                                    <form class="mt-4" method="POST" action="<?php echo e(route('transferCoinProcess')); ?>"
                                                          onsubmit="return submitResult();">
                                                        <?php echo csrf_field(); ?>
                                                        <div class="form-group mt-4">
                                                            <label><?php echo e(__('Select Your Wallet')); ?></label>
                                                            <div class="cp-select-area">
                                                                <select name="wallet_id" class="form-control" id="">
                                                                    <option value=""><?php echo e(__('Select')); ?></option>
                                                                    <?php if(isset($wallets[0])): ?>
                                                                        <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($wallet->id); ?>"> <?php echo e($wallet->name); ?>

                                                                                (<?php echo e(number_format($wallet->balance,2)); ?>)
                                                                            </option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php endif; ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="from-group mt-4">
                                                            <div class="cp-user-payment-type">
                                                                <h3><?php echo e(__('Transfer Type')); ?></h3>
                                                                <div class="form-group">
                                                                    <input type="radio"
                                                                           onchange="$('.crypto_address').removeClass('d-none').addClass('d-block');$('.crypto_iban').addClass('d-none').removeClass('d-block');"
                                                                           value="<?php echo e(TRANSFER_TYPE_FLAT); ?>" id="coin-option" name="type">
                                                                    <label for="coin-option"><?php echo e(__('FIAT ')); ?>(<?php echo e(isset(settings()['currency']) ? settings()['currency'] : 'USD'); ?>)</label>
                                                                </div>
                                                                <div class="form-group">
                                                                    <input type="radio" value="<?php echo e(TRANSFER_TYPE_CRYPTO); ?>"
                                                                           onchange="$('.crypto_address').addClass('d-none').removeClass('d-block');$('.crypto_iban').removeClass('d-none').addClass('d-block');"
                                                                           id="f-option" name="type">
                                                                    <label for="f-option"><?php echo e(__('Cryptocurrency (BTC, ETH, etc.)')); ?></label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group mt-4">
                                                            <label><?php echo e(__('Coin Amount')); ?></label>
                                                            <input name="amount" type="text" placeholder="<?php echo e(__('Coin')); ?>"
                                                                   class="form-control">
                                                            <span class="text-warning" style="font-weight: 700;"><?php echo e(__('Minimum send amount : ')); ?></span>
                                                            <span class="text-warning"><?php echo e(settings('minimum_withdrawal_amount')); ?> <?php echo e(settings('coin_name')); ?></span>
                                                            <span class="text-warning"><?php echo e(__(' and ')); ?></span>
                                                            <span class="text-warning" style="font-weight: 700;"><?php echo e(__('Maximum send amount : ')); ?></span>
                                                            <span class="text-warning"><?php echo e(settings('maximum_withdrawal_amount')); ?> <?php echo e(settings('coin_name')); ?></span>
                                                        </div>
                                                        <div class="form-group mt-4 crypto_address d-none">
                                                            <label><?php echo e(__('IBAN')); ?></label>
                                                            <input name="iban" type="text" placeholder="<?php echo e(__('IBAN No.')); ?>"
                                                                   class="form-control ">
                                                            <span class="text-warning" style="font-weight: 700;"><?php echo e(__('Note : ')); ?></span>
                                                            <span class="text-warning"><?php echo e(__('Input your iban no. where you want to send UNBC.')); ?></span>
                                                        </div>
                                                        <div class="form-group mt-4 crypto_address d-none">
                                                            <label><?php echo e(__('Beneficiary')); ?></label>
                                                            <input name="beneficiary" type="text" placeholder="<?php echo e(__('Name & Surname of  beneficiary.')); ?>"
                                                                   class="form-control ">
                                                            <span class="text-warning" style="font-weight: 700;"><?php echo e(__('Note : ')); ?></span>
                                                            <span class="text-warning"><?php echo e(__('Input name of bank account holder.')); ?></span>
                                                        </div>
                                                        <div class="form-group mt-4 crypto_iban d-none">
                                                            <label><?php echo e(__('Address')); ?></label>
                                                            <input name="address" type="text" placeholder="<?php echo e(__('User Coin Address')); ?>"
                                                                   class="form-control ">
                                                            <span class="text-warning" style="font-weight: 700;"><?php echo e(__('Note : ')); ?></span>
                                                            <span class="text-warning"><?php echo e(__('Input user coin address where you want to send coin.')); ?></span>
                                                        </div>
                                                        <div class="form-group m-0">
                                                            <button class="btn btn-info theme-btn" type="submit"><?php echo e(__('Transfer UNBC')); ?></button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function submitResult() {
            if (confirm("Are you sure to transfer coin?") == false) {
                return false;
            } else {
                return true;
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.master',['menu'=>'coin_request', 'sub_menu'=>'give_coin'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/cpoket-web/resources/views/user/request_coin/coin_request.blade.php ENDPATH**/ ?>