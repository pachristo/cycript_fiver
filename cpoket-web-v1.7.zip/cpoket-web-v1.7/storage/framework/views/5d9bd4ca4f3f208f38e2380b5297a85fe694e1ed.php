<?php $__env->startSection('title', isset($title) ? $title : ''); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- breadcrumb -->
    <div class="custom-breadcrumb">
        <div class="row">
            <div class="col-9">
                <ul>
                    <li><?php echo e(__('Setting')); ?></li>
                    <li class="active-item"><?php echo e($title); ?></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- /breadcrumb -->

    <!-- User Management -->
    <div class="user-management">
        <div class="row">
            <div class="col-12">
                <div class="header-bar p-4">
                    <div class="table-title">
                        <h3><?php echo e($title); ?></h3>
                    </div>
                </div>
                <div class="table-area">
                    <div>
                        <table id="table" class=" table table-borderless custom-table display text-center" width="100%">
                            <thead>
                            <tr>
                                <th scope="col"><?php echo e(__('Method Name')); ?></th>
                                <th scope="col"><?php echo e(__('Status')); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $payment_methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($value); ?>

                                    </td>
                                    <td>
                                        <?php if($key == BTC): ?>
                                            <div>
                                                <label class="switch">
                                                    <input type="checkbox" onclick="return processForm('payment_method_coin_payment')"
                                                           id="notification" name="security" <?php if(isset($settings['payment_method_coin_payment']) && ($settings['payment_method_coin_payment'] == 1)): ?> checked <?php endif; ?>>
                                                    <span class="slider" for="status"></span>
                                                </label>
                                            </div>
                                        <?php endif; ?>
                                        <?php if($key == BANK_DEPOSIT): ?>
                                            <div>
                                                <label class="switch">
                                                    <input type="checkbox" onclick="return processForm('payment_method_bank_deposit')"
                                                           id="notification" name="security" <?php if(isset($settings['payment_method_bank_deposit']) && ($settings['payment_method_bank_deposit'] == 1)): ?> checked <?php endif; ?>>
                                                    <span class="slider" for="status"></span>
                                                </label>
                                            </div>
                                        <?php endif; ?>
                                        <?php if($key == STRIPE): ?>
                                            <div>
                                                <label class="switch">
                                                    <input type="checkbox" onclick="return processForm('payment_method_stripe')"
                                                           id="notification" name="security" <?php if(isset($settings['payment_method_stripe']) && ($settings['payment_method_stripe'] == 1)): ?> checked <?php endif; ?>>
                                                    <span class="slider" for="status"></span>
                                                </label>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /User Management -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function processForm(active_id) {
            console.log(active_id)
            $.ajax({
                type: "POST",
                url: "<?php echo e(route('changePaymentMethodStatus')); ?>",
                data: {
                    '_token': "<?php echo e(csrf_token()); ?>",
                    'active_id': active_id
                },
                success: function (data) {
                    console.log(data);
                }
            });
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master',['menu'=>'setting', 'sub_menu'=>'payment-method'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/cpoket-web/resources/views/admin/settings/payment-method.blade.php ENDPATH**/ ?>