<!DOCTYPE HTML>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="author" content="itechtheme">
    <meta name="description" content="The Highly Secured Bitcoin Wallet">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- title here -->
    <title><?php echo e(settings('app_title')); ?>::<?php echo $__env->yieldContent('title'); ?></title>

    <!-- Favicon and Touch Icons -->
    <link rel="shortcut icon" href="<?php echo e(landingPageImage('favicon','images/fav.png')); ?>/">
    <!-- Place favicon.ico in the root directory -->
    <link rel="apple-touch-icon" href="apple-touch-icon.png">
    <!-- Fonts -->
    <link href="<?php echo e(asset('assets/css/gfont.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('landing')); ?>/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('landing')); ?>/css/flaticon.css">
    <!-- Plugin CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('landing')); ?>/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('landing')); ?>/css/animate.css">
    <link rel="stylesheet" href="<?php echo e(asset('landing')); ?>/css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('landing')); ?>/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('landing')); ?>/css/meanmenu.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('landing')); ?>/css/magnific-popup.css">
    <link href="<?php echo e(asset('landing')); ?>/css/aos.css" rel="stylesheet">
    
    <link href="<?php echo e(asset('assets/toast/vanillatoasts.css')); ?>" rel="stylesheet" >
    <!--Theme custom css -->
    <link rel="stylesheet" href="<?php echo e(asset('landing')); ?>/css/style.css">
    <!--Theme Responsive css-->
    <link rel="stylesheet" href="<?php echo e(asset('landing')); ?>/css/responsive.css" />
    <?php echo $__env->yieldContent('style'); ?>
    <script src="<?php echo e(asset('landing')); ?>/js/vendor/modernizr-3.6.0.min.js"></script>
    
    <script src="<?php echo e(asset('assets/toast/vanillatoasts.js')); ?>"></script>
</head>
<body>
<!-- header-area start here -->
<header class="header-area" id="sticky">
    <div class="container">
        <div class="row">
            <div class="col-md-2">
                <div class="logo-area">
                    <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(landingPageImage('logo','images/logo.svg')); ?>" alt=""></a>
                </div>
            </div>
            <div class="col-md-10">
                <div class="menu-area text-right">
                    <nav class="main-menu">
                        <ul id="nav">
                            <li class="current"><a href="#banner-area"><?php echo e(__('Home')); ?></a></li>
                            <li><a href="#features"><?php echo e(__('Features')); ?></a></li>
                            <li><a href="#about"><?php echo e(__('About')); ?></a></li>
                            <li><a href="#roadmap"><?php echo e(__('Roadmap')); ?></a></li>
                            <li><a href="#integration"><?php echo e(__('Integration')); ?></a></li>
                            <li><a href="#faq"><?php echo e(__('FAQ')); ?></a></li>
                            <li><a href="#contact"><?php echo e(__('Contact')); ?></a></li>
                            <?php if(Auth::check()): ?>
                                <li><a href="<?php echo e(route('logOut')); ?>"><?php echo e(__('Logout')); ?></a></li>
                            <?php else: ?>
                                <li><a href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a></li>
                                <li><a href="<?php echo e(route('signUp')); ?>"><?php echo e(__('Sign up')); ?></a></li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</header>

<!-- header-area end here -->
<!-- banner area start here -->

<?php echo $__env->yieldContent('content'); ?>

<!-- footer area start here -->
<footer class="footer-area">
    <div class="footer-top">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-6 mb-30">
                    <div class="single-wedgets text-widget">
                        <div class="footer-logo">
                            <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(landingPageImage('logo','images/logo.svg')); ?>" alt=""></a>
                        </div>
                        <div class="widget-text widget-inner">
                            <p>
                                <?php if(isset($content['footer_description'])): ?> <?php echo e($content['footer_description']); ?> <?php else: ?>
                                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been text ever since.
                                <?php endif; ?>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 mb-30">
                    <div class="single-wedgets text-widget">
                        <div class="widget-title">
                            <h4><?php echo e(__('Important Link')); ?></h4>
                        </div>
                        <div class="widget-inner">
                            <ul>
                                <li><a href="#banner-area"><?php echo e(__('Home')); ?></a></li>
                                <li><a href="#features"><?php echo e(__('Feature')); ?></a></li>
                                <li><a href="#integration"><?php echo e(__('Integrations')); ?></a></li>
                                <li><a href="#about"><?php echo e(__('About')); ?></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 mb-30">
                    <div class="single-wedgets text-widget">
                        <div class="widget-title">
                            <h4><?php echo e(__('Custom Pages')); ?></h4>
                        </div>
                        <div class="widget-inner">
                            <ul>
                               <?php $__currentLoopData = $custom_links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('getCustomPage',[$link->id,str_replace(' ','-',$link->key)])); ?>"><?php echo e($link->key); ?></a></li>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6">
                    <div class="single-wedgets social-link">
                        <div class="widget-title">
                            <h4><?php echo e(__('Social Link')); ?></h4>
                        </div>
                        <div class="widget-inner">
                            <ul>
                                <li><a href="https://www.facebook.com/"><?php echo e(__('Facebook')); ?></a></li>
                                <li><a href="https://twitter.com/"><?php echo e(__('Twitter')); ?></a></li>
                                <li><a href="https://www.linkedin.com/"><?php echo e(__('LinkedIn')); ?></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="copyright-area text-center">
                        <p><?php echo e(settings('copyright_text')); ?> <a href="<?php echo e(url('/')); ?>"><?php echo e(settings('app_title')); ?></a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- footer area end here -->
<!-- js file start -->
<script src="<?php echo e(asset('landing')); ?>/js/vendor/jquery-3.3.1.min.js"></script>
<script src="<?php echo e(asset('landing')); ?>/js/plugins.js"></script>
<script src="<?php echo e(asset('landing')); ?>/js/Popper.js"></script>
<script src="<?php echo e(asset('landing')); ?>/js/bootstrap.min.js"></script>
<script src="<?php echo e(asset('landing')); ?>/js/scrollup.js"></script>
<script src="<?php echo e(asset('landing')); ?>/js/owl.carousel.min.js"></script>
<script src="<?php echo e(asset('landing')); ?>/js/jquery.meanmenu.js"></script>
<script src="<?php echo e(asset('landing')); ?>/js/jquery.nav.js"></script>
<script src="<?php echo e(asset('landing')); ?>/js/aos.js"></script>
<script src="<?php echo e(asset('landing')); ?>/js/image-rotate.js"></script>
<script src="<?php echo e(asset('landing')); ?>/js/jquery.magnific-popup.min.js"></script>
<script src="<?php echo e(asset('landing')); ?>/js/particleground.js"></script>
<script src="<?php echo e(asset('landing')); ?>/js/particle-app.js"></script>
<!-- tweenmax canvas -->
<script type="x-shader/x-vertex" id="wrapVertexShader">
    #define PI 3.1415926535897932384626433832795
    attribute float size;
    void main() {
        vec4 mvPosition = modelViewMatrix * vec4( position, 1.0 );
        gl_PointSize = 3.0;
        gl_Position = projectionMatrix * mvPosition;
    }
</script>
<script type="x-shader/x-fragment" id="wrapFragmentShader">
    uniform sampler2D texture;
    void main(){
        vec4 textureColor = texture2D( texture, gl_PointCoord );
        if ( textureColor.a < 0.3 ) discard;
        // vec4 dotColor = vec4(0.06, 0.18, 0.36, 0.4);

        //vec4 dotColor = vec4(0.06, 0.7, 0.4, 0.7);
        vec4 dotColor = vec4(0.26, 0.17, 0.65, 0.7);
        vec4 color = dotColor * textureColor;
        gl_FragColor = color;
    }
</script>
<script src="<?php echo e(asset('landing')); ?>/js/TweenMax.min.js"></script>
<script src="<?php echo e(asset('landing')); ?>/js/three.min.js"></script>
<script src="<?php echo e(asset('landing')); ?>/js/main.js"></script>

<script>
    if ($(".particleground").length) {
        $('.particleground').particleground({
            dotColor: '#999999',
            lineColor: '#999999',
            particleRadius: 5,
            lineWidth: 2,
            curvedLines: true,
            proximity: 20,
            parallaxMultiplier: 10,
        });
    }

</script>
<?php if(session()->has('success')): ?>
    <script>
        window.onload = function () {
            VanillaToasts.create({
                //  title: 'Message Title',
                text: '<?php echo e(session('success')); ?>',
                backgroundColor: "linear-gradient(135deg, #73a5ff, #5477f5)",
                type: 'success',
                timeout: 10000
            });
        }

    </script>

<?php elseif(session()->has('dismiss')): ?>
    <script>
        window.onload = function () {

            VanillaToasts.create({
                // title: 'Message Title',
                text: '<?php echo e(session('dismiss')); ?>',
                type: 'warning',
                timeout: 10000

            });
        }
    </script>

<?php elseif($errors->any()): ?>
    <?php $__currentLoopData = $errors->getMessages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <script>
            window.onload = function () {
                VanillaToasts.create({
                    // title: 'Message Title2',
                    text: '<?php echo e($error[0]); ?>',
                    type: 'warning',
                    timeout: 10000

                });
            }
        </script>

        <?php break; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php endif; ?>
<?php echo $__env->yieldContent('script'); ?>
<!-- End js file -->
</body>
</html>

<?php /**PATH /var/www/html/cpoket-web/resources/views/landing/master.blade.php ENDPATH**/ ?>