<?php $__env->startSection('title', isset($title) ? $title : ''); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">

            <ul class="nav cp-user-profile-nav" id="pills-tab" role="tablist">
                <li class="nav-item">
                    <a class="nav-link <?php echo e(($qr == 'profile-tab') ? 'active' : ''); ?>" data-id="profile-tab"
                       id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab"
                       aria-controls="pills-profile" aria-selected="true">
                                <span class="cp-user-img">
                                    <img src="<?php echo e(asset('assets/user/images/profile-icons/profile.svg')); ?>"
                                         class="img-fluid img-normal" alt="">
                                    <img src="<?php echo e(asset('assets/user/images/profile-icons/active/profile.svg')); ?>"
                                         class="img-fluid img-active" alt="">
                                </span>
                        <?php echo e(__('Profile')); ?>

                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(($qr == 'eProfile-tab') ? 'active' : ''); ?>" data-id="eProfile-tab"
                       id="pills-edit-profile-tab" data-toggle="pill" href="#pills-edit-profile" role="tab"
                       aria-controls="pills-edit-profile" aria-selected="true">
                                <span class="cp-user-img">
                                    <img src="<?php echo e(asset('assets/user/images/profile-icons/edit-profile.svg')); ?>"
                                         class="img-fluid img-normal" alt="">
                                    <img src="<?php echo e(asset('assets/user/images/profile-icons/active/edit-profile.svg')); ?>"
                                         class="img-fluid img-active" alt=""
                                    ></span>
                        <?php echo e(__('Edit Profile')); ?>

                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(($qr == 'pvarification-tab') ? 'active' : ''); ?>" data-id="pvarification-tab"
                       id="pills-phone-verify-tab" data-toggle="pill" href="#pills-phone-verify" role="tab"
                       aria-controls="pills-phone-verify" aria-selected="true">
                                <span class="cp-user-img">
                                    <img src="<?php echo e(asset('assets/user/images/profile-icons/phone-verify.svg')); ?>"
                                         class="img-fluid img-normal" alt="">
                                    <img src="<?php echo e(asset('assets/user/images/profile-icons/active/phone-verify.svg')); ?>"
                                         class="img-fluid img-active" alt=""
                                    ></span>
                        <?php echo e(__('Phone Verification')); ?>

                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(($qr == 'idvarification-tab') ? 'active' : ''); ?>" data-id="idvarification-tab"
                       id="pills-id-verify-tab" data-toggle="pill" href="#pills-id-verify" role="tab"
                       aria-controls="pills-id-verify" aria-selected="true">
                                <span class="cp-user-img">
                                    <img src="<?php echo e(asset('assets/user/images/profile-icons/id-verify.svg')); ?>"
                                         class="img-fluid img-normal" alt="">
                                    <img src="<?php echo e(asset('assets/user/images/profile-icons/active/id-verify.svg')); ?>"
                                         class="img-fluid img-active" alt="">
                                </span>
                        <?php echo e(__('ID Verification')); ?>

                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link  <?php echo e(($qr == 'rpassword-tab') ? 'active' : ''); ?>" data-id="rpassword-tab"
                       id="pills-reset-pass-tab" data-toggle="pill" href="#pills-reset-pass" role="tab"
                       aria-controls="pills-id-verify" aria-selected="true">
                                <span class="cp-user-img">
                                    <img src="<?php echo e(asset('assets/user/images/profile-icons/reset-pass.svg')); ?>"
                                         class="img-fluid img-normal" alt="">
                                    <img src="<?php echo e(asset('assets/user/images/profile-icons/active/reset-pass.svg')); ?>"
                                         class="img-fluid img-active" alt="">
                                </span>
                        <?php echo e(__('Reset Password')); ?>

                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(($qr == 'activity-tab') ? 'active' : ''); ?>" data-id="activity-tab"
                       id="pills-activity-log-tab" data-toggle="pill" href="#pills-activity-log" role="tab"
                       aria-controls="pills-id-verify" aria-selected="true">
                                <span class="cp-user-img">
                                    <img src="<?php echo e(asset('assets/user/images/profile-icons/activity-log.svg')); ?>"
                                         class="img-fluid img-normal" alt="">
                                    <img src="<?php echo e(asset('assets/user/images/profile-icons/active/activity-log.svg')); ?>"
                                         class="img-fluid img-active" alt=""
                                    >
                                </span>
                        <?php echo e(__('Activity')); ?>

                    </a>
                </li>
            </ul>
            <div class="tab-content cp-user-profile-tab-content" id="pills-tabContent">
                <div class="tab-pane fade show <?php echo e(($qr == 'profile-tab') ? 'show active in' : ''); ?>" id="pills-profile"
                     role="tabpanel" aria-labelledby="pills-profile-tab">
                    <div class="row">
                        <div class="col-xl-4 mb-xl-0 mb-4">
                            <div class="card cp-user-custom-card">
                                <div class="card-body">
                                    <div class="user-profile-area">
                                        <div class="user-profile-img">
                                            <img src="<?php echo e(show_image($user->id,'user')); ?>" class="img-fluid" alt="">
                                        </div>
                                        <div class="user-cp-user-profile-info">
                                            <h4><?php echo e($user->first_name.' '.$user->last_name); ?></h4>
                                            <p><?php echo e($user->email); ?></p>
                                            <p class="cp-user-btc">
                                                <?php if(!empty($clubInfos['club_id'])): ?>
                                                    <span>
                                                    <img src="<?php echo e($clubInfos['plan_image']); ?>"  class="img-fluid" alt="">
                                                </span>
                                            </p>
                                            <p>
                                                <?php echo e($clubInfos['plan_name']); ?>

                                            </p>
                                            <?php endif; ?>
                                            <div class="cp-user-available-balance-profile">
                                                <p><?php echo e(__('Blocked Coin')); ?>

                                                    <span><?php echo e(number_format(get_blocked_coin(Auth::id()),2)); ?></span> <?php echo e(allsetting('coin_name')); ?>

                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-8">
                            <div class="card cp-user-custom-card">
                                <div class="card-body">
                                    <div class="cp-user-profile-header">
                                        <h5><?php echo e(__('Profile Information')); ?></h5>
                                    </div>
                                    <div class="cp-user-profile-info">
                                        <ul>
                                            <li>
                                                <span><?php echo e(__('Name')); ?></span>
                                                <span class="cp-user-dot">:</span>
                                                <span><?php echo e($user->first_name.' '.$user->last_name); ?></span>
                                            </li>
                                            <li>
                                                <span><?php echo e(__('Country')); ?></span>
                                                <span class="cp-user-dot">:</span>
                                                <span><?php echo e($user->country); ?></span>
                                            </li>
                                            <li>
                                                <span><?php echo e(__('Email')); ?></span>
                                                <span class="cp-user-dot">:</span>
                                                <span><?php echo e($user->email); ?></span>
                                            </li>
                                            <li>
                                                <span><?php echo e(__('Email Verification')); ?></span>
                                                <span class="cp-user-dot">:</span>
                                                <span><?php echo e(statusAction($user->is_verified)); ?></span>
                                            </li>
                                            <li>
                                                <span><?php echo e(__('Phone')); ?></span>
                                                <span class="cp-user-dot">:</span>
                                                <span><?php echo e($user->phone); ?></span>
                                            </li>
                                            
                                            
                                            
                                            
                                            

                                            <li>
                                                <span><?php echo e(__('Role')); ?></span>
                                                <span class="cp-user-dot">:</span>
                                                <span><?php echo e(userRole($user->role)); ?></span>
                                            </li>
                                            <li>
                                                <span><?php echo e(__('Active Status')); ?></span>
                                                <span class="cp-user-dot">:</span>
                                                <span><?php echo e(statusAction($user->status)); ?></span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade <?php echo e(($qr == 'eProfile-tab') ? 'show active in' : ''); ?>" id="pills-edit-profile"
                     role="tabpanel" aria-labelledby="pills-edit-profile-tab">
                    <div class="row">
                        <div class="col-xl-4 mb-xl-0 mb-4">
                            <div class="card cp-user-custom-card">
                                <div class="card-body">
                                    <div class="user-profile-area">
                                        <div class="user-profile-img">
                                            <img src="<?php echo e(show_image($user->id,'user')); ?>" class="img-fluid" alt="">
                                        </div>
                                        <form enctype="multipart/form-data" method="post"
                                              action="<?php echo e(route('uploadProfileImage')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <div class="user-cp-user-profile-info">
                                                <input type="file" name="file_one" id="upload-user-img">
                                                <label for="upload-user-img" class="upload-user-img">
                                                    <?php echo e(__('Upload New Image')); ?>

                                                </label>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-8">
                            <div class="card cp-user-custom-card">
                                <div class="card-body">
                                    <div class="cp-user-profile-header">
                                        <h5><?php echo e(__('Edit Profile Information')); ?></h5>
                                    </div>
                                    <div class="cp-user-profile-info">
                                        <form action="<?php echo e(route('userProfileUpdate')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group">
                                                <label><?php echo e(__('First Name')); ?></label>
                                                <input type="text" name="first_name" value="<?php echo e($user->first_name); ?>"
                                                       class="form-control">
                                            </div>
                                            <div class="form-group">
                                                <label><?php echo e(__('Last Name')); ?></label>
                                                <input type="text" name="last_name" value="<?php echo e($user->last_name); ?>"
                                                       class="form-control">
                                            </div>
                                            <div class="form-group">
                                                <label><?php echo e(__('Phone')); ?></label>
                                                <input type="text" name="phone" value="<?php echo e($user->phone); ?>"
                                                       class="form-control">
                                                <small><?php echo e(__('Please add phone number with country phone code but not (+ sign.) Ex. for portugal 351*****')); ?></small>
                                            </div>
                                            <div class="form-group">
                                                <label><?php echo e(__('Country')); ?></label>
                                                <select name="country" id="" class="form-control">
                                                    <?php $__currentLoopData = country(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($key); ?>"
                                                                <?php if(isset($user->country) && ($user->country == $key)): ?> selected <?php endif; ?>>
                                                            <?php echo e($value); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label><?php echo e(__('Gender')); ?></label>
                                                <select class="form-control" name="gender" id="">
                                                    <option <?php if($user->gender == 1): ?> selected
                                                            <?php endif; ?> value="1"><?php echo e(__('Male')); ?></option>
                                                    <option <?php if($user->gender == 2): ?> selected
                                                            <?php endif; ?> value="2"><?php echo e(__('Female')); ?></option>
                                                    <option <?php if($user->gender == 3): ?> selected
                                                            <?php endif; ?> value="3"><?php echo e(__('Others')); ?></option>
                                                </select>
                                            </div>
                                            <div class="form-group m-0">
                                                <button class="btn profile-edit-btn"
                                                        type="submit"><?php echo e(__('Update')); ?></button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade <?php echo e(($qr == 'pvarification-tab') ? 'show active in' : ''); ?>"
                     id="pills-phone-verify" role="tabpanel" aria-labelledby="pills-phone-verify-tab">
                    <div class="card cp-user-custom-card">
                        <div class="card-body">
                            <div class="row justify-content-center">
                                <div class="col-lg-9">
                                    <div class="cp-user-profile-header">
                                        <h5><?php echo e(__('Phone Verification')); ?></h5>
                                    </div>
                                    <div class="cp-user-profile-info">
                                        <form method="post" action="<?php echo e(route('phoneVerify')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group">
                                                <label for="number"><?php echo e(__('Phone number')); ?></label>
                                                <div class="code-list">
                                                    <?php if(!empty($user->phone)): ?>
                                                        <input type="text" readonly value="<?php echo e(Auth::user()->phone); ?>"
                                                               class="form-control" id="">
                                                        <?php if((Auth::user()->phone_verified == 0 )  && (!empty(\Illuminate\Support\Facades\Cookie::get('code')))): ?>
                                                            <a href="<?php echo e(route('sendSMS')); ?>"
                                                               class="primary-btn"><?php echo e(__('Resend SMS')); ?></a>
                                                            <p><?php echo e(__('Did not receive code?')); ?></p>
                                                        <?php elseif(Auth::user()->phone_verified == 1 ): ?>
                                                            <span class="verified"><?php echo e(__('Verified')); ?></span>
                                                        <?php else: ?>
                                                            <a href="<?php echo e(route('sendSMS')); ?>"
                                                               class="primary-btn"><?php echo e(__('Send SMS')); ?></a>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <p><?php echo e(__('Please add mobile no. first from edit profile')); ?></p>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <?php if((Auth::user()->phone_verified == 0) && (!empty(\Illuminate\Support\Facades\Cookie::get('code')))): ?>
                                                <div class="form-group">
                                                    <label for="number"><?php echo e(__('Verify Code')); ?></label>
                                                    <div class="code-list">
                                                        <input name="code" type="text" min="" max=""
                                                               class="form-control" id="">
                                                    </div>
                                                </div>
                                                <button type="submit"
                                                        class="btn profile-edit-btn phn-verify-btn"><?php echo e(__('Verify')); ?></button>
                                            <?php endif; ?>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade <?php echo e(($qr == 'idvarification-tab') ? 'show active in' : ''); ?>"
                     id="pills-id-verify" role="tabpanel" aria-labelledby="pills-id-verify-tab">
                    <div class="card cp-user-custom-card idverifycard">
                        <div class="card-body">
                            <div class="cp-user-profile-header">
                                <h5><?php echo e(__('Select Your ID Type')); ?></h5>
                            </div>
                            <div class="row justify-content-center">
                                <div class="col-lg-10">
                                    <div class="cp-user-profile-info-id-type">
                                        <div class="id-card-type">
                                            <div class="id-card" data-toggle="modal"
                                                 data-target=".cp-user-idverifymodal">
                                                <img src="<?php echo e(asset('assets/user/images/cards/nid.svg')); ?>"
                                                     class="img-fluid" alt="">
                                            </div>
                                            <div class="card-bottom">
                                                <?php if((!empty($nid_back ) && !empty($nid_front)) && (($nid_back->status == STATUS_SUCCESS) && ($nid_front->status == STATUS_SUCCESS))): ?>
                                                    <span class="text-success"><?php echo e(__('Approved')); ?></span>
                                                <?php elseif((!empty($nid_back ) && !empty($nid_front)) && (($nid_back->status == STATUS_REJECTED) && ($nid_front->status == STATUS_REJECTED))): ?>
                                                    <span class="text-danger"><?php echo e(__('Rejected')); ?></span>
                                                <?php elseif((!empty($nid_back ) && !empty($nid_front)) && (($nid_back->status == STATUS_PENDING) && ($nid_front->status == STATUS_PENDING))): ?>
                                                    <span class="text-warning"><?php echo e(__('Pending')); ?></span>
                                                <?php else: ?>
                                                    <span class="text-warning"><?php echo e(__('Not Submitted')); ?></span>
                                                <?php endif; ?>
                                                <h5><?php echo e(__('National Id Card')); ?></h5>
                                            </div>
                                        </div>
                                        <div class="id-card-type">
                                            <div class="id-card" data-toggle="modal"
                                                 data-target=".cp-user-passwordverifymodal">
                                                <img src="<?php echo e(asset('assets/user/images/cards/passport.svg')); ?>"
                                                     class="img-fluid" alt="">
                                            </div>
                                            <div class="card-bottom">
                                                <?php if((!empty($pass_back ) && !empty($pass_front)) && (($pass_back->status == STATUS_SUCCESS) && ($pass_front->status == STATUS_SUCCESS))): ?>
                                                    <span class="text-success"><?php echo e(__('Approved')); ?></span>
                                                <?php elseif((!empty($pass_back ) && !empty($pass_front)) && (($pass_back->status == STATUS_REJECTED) && ($pass_front->status == STATUS_REJECTED))): ?>
                                                    <span class="text-danger"><?php echo e(__('Rejected')); ?></span>

                                                <?php elseif((!empty($pass_back ) && !empty($pass_front)) && (($pass_back->status == STATUS_PENDING) && ($pass_front->status == STATUS_PENDING))): ?>
                                                    <span class="text-warning"><?php echo e(__('Pending')); ?></span>
                                                <?php else: ?>
                                                    <span class="text-warning"><?php echo e(__('Not Submitted')); ?></span>
                                                <?php endif; ?>
                                                <h5><?php echo e(__('Passport')); ?></h5>
                                            </div>
                                        </div>
                                        <div class="id-card-type">
                                            <div class="id-card" data-toggle="modal"
                                                 data-target=".cp-user-driververifymodal">
                                                <img src="<?php echo e(asset('assets/user/images/cards/driving-license.svg')); ?>"
                                                     class="img-fluid" alt="">
                                            </div>
                                            <div class="card-bottom">
                                                <?php if((!empty($drive_back ) && !empty($drive_front)) && (($drive_back->status == STATUS_SUCCESS) && ($drive_front->status == STATUS_SUCCESS))): ?>
                                                    <span class="text-success"><?php echo e(__('Approved')); ?></span>
                                                <?php elseif((!empty($drive_back ) && !empty($drive_front)) && (($drive_back->status == STATUS_REJECTED) && ($drive_front->status == STATUS_REJECTED))): ?>
                                                    <span class="text-danger"><?php echo e(__('Rejected')); ?></span>
                                                <?php elseif((!empty($drive_back ) && !empty($drive_front)) && (($drive_back->status == STATUS_PENDING) && ($drive_front->status == STATUS_PENDING))): ?>
                                                    <span class="text-warning"><?php echo e(__('Pending')); ?></span>
                                                <?php else: ?>
                                                    <span class="text-warning"><?php echo e(__('Not Submitted')); ?></span>
                                                <?php endif; ?>
                                                <h5><?php echo e(__('Driving License')); ?></h5>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade <?php echo e(($qr == 'rpassword-tab') ? 'show active in' : ''); ?>" id="pills-reset-pass"
                     role="tabpanel" aria-labelledby="pills-reset-pass-tab">
                    <div class="card cp-user-custom-card">
                        <div class="card-body">
                            <div class="row justify-content-center">
                                <div class="col-lg-9">
                                    <div class="cp-user-profile-header">
                                        <h5><?php echo e(__('Reset Password')); ?></h5>
                                    </div>

                                </div>
                                <div class="col-lg-9">
                                    <div class="cp-user-profile-info">
                                        <form method="POST" action="<?php echo e(route('changePasswordSave')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group">
                                                <label><?php echo e(__('Current Password')); ?></label>
                                                <input name="password" type="password"
                                                       placeholder="<?php echo e(__('Current Password')); ?>" class="form-control">
                                            </div>
                                            <div class="form-group">
                                                <label><?php echo e(__('New Password')); ?></label>
                                                <input name="new_password" type="password"
                                                       placeholder="<?php echo e(__('New Password')); ?>" class="form-control">
                                            </div>
                                            <div class="form-group">
                                                <label><?php echo e(__('Confirm New Password')); ?></label>
                                                <input name="confirm_new_password" type="password"
                                                       placeholder="<?php echo e(__('Re Enter New Password')); ?>"
                                                       class="form-control">
                                            </div>
                                            <div class="form-group m-0">
                                                <button class="btn profile-edit-btn"
                                                        type="submit"><?php echo e(__('Change Password')); ?></button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade <?php echo e(($qr == 'activity-tab') ? 'show active in' : ''); ?>" id="pills-activity-log"
                     role="tabpanel" aria-labelledby="pills-activity-log-tab">
                    <div class="card cp-user-custom-card">
                        <div class="card-body">
                            <div class="cp-user-profile-header">
                                <h5><?php echo e(__('All ActivityList')); ?></h5>
                            </div>
                            <div class="row">
                                <div class="col-12">
                                    <div class="cp-user-wallet-table table-responsive">
                                        <table id="activity-tbl" class="table table-borderless cp-user-custom-table"
                                               width="100%">
                                            <thead>
                                            <tr>
                                                <th class="all"><?php echo e(__('Action')); ?></th>
                                                <th class="desktop"><?php echo e(__('Source')); ?></th>
                                                <th class="desktop"><?php echo e(__('IP Address')); ?></th>
                                                
                                                <th class="all"><?php echo e(__('Updated At')); ?></th>
                                            </tr>
                                            </thead>
                                            <tbody>

                                            </tbody>
                                        </table>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade cp-user-idverifymodal" id="exampleModalCenter" tabindex="-1" role="dialog"
         aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true"><img src="<?php echo e(asset('assets/user/images/close.svg')); ?>" class="img-fluid"
                                                      alt=""></span>
                    </button>
                    <form id="nidUpload" class="Upload" action="<?php echo e(route('nidUpload')); ?>" enctype="multipart/form-data"
                          method="post">
                        <?php echo csrf_field(); ?>
                        <div class="container">
                            <div class="row">

                                <div class="col-12">
                                    <div class="card-list">
                                        <div class="alert alert-danger d-none error_msg" id="" role="alert">
                                        </div>
                                        <div class="alert alert-success d-none succ_msg" id="" role="alert">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 mb-lg-0 mb-4">
                                    <div class="idcard">
                                        <h3 class="title"><?php echo e(__('Front Side')); ?></h3>
                                        <div id="file-upload" class="section-p">
                                            <?php if(isset($nid_back) && isset($nid_front)): ?>
                                                <?php if((empty($nid_back ) && empty($nid_front)) || (($nid_back->status == STATUS_REJECTED) && ($nid_front->status == STATUS_REJECTED))): ?>
                                                    <input type="file" accept="image/x-png,image/jpeg" name="file_two"
                                                           id="file" ref="file" class="dropify"
                                                           <?php if(!empty($nid_front) && (!empty($nid_front->photo))): ?>  data-default-file="<?php echo e(asset(IMG_USER_VIEW_PATH.$nid_front->photo)); ?>" <?php endif; ?> />
                                                <?php else: ?>
                                                    <div class="card-inner">
                                                        <img src="<?php echo e(asset(IMG_USER_VIEW_PATH.$nid_front->photo)); ?>"
                                                             class="img-fluid" alt="">
                                                    </div>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <input type="file" accept="image/x-png,image/jpeg" name="file_two"
                                                       id="file" ref="file" class="dropify"
                                                       <?php if(!empty($nid_front) && (!empty($nid_front->photo))): ?>  data-default-file="<?php echo e(asset(IMG_USER_VIEW_PATH.$nid_front->photo)); ?>" <?php endif; ?> />
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 mb-lg-0 mb-4">
                                    <div class="idcard">
                                        <h3 class="title"><?php echo e(__('Back Side')); ?></h3>
                                        <?php if(isset($nid_back) && isset($nid_front)): ?>
                                            <?php if((empty($nid_back ) && empty($nid_front)) || (($nid_back->status == STATUS_REJECTED) && ($nid_front->status == STATUS_REJECTED))): ?>
                                                <input type="file" accept="image/x-png,image/jpeg" name="file_three"
                                                       id="file" ref="file" class="dropify"
                                                       <?php if(!empty($nid_back) && (!empty($nid_back->photo))): ?>  data-default-file="<?php echo e(asset(IMG_USER_VIEW_PATH.$nid_back->photo)); ?>" <?php endif; ?> />
                                            <?php else: ?>
                                                <div class="card-inner">
                                                    <img src="<?php echo e(asset(IMG_USER_VIEW_PATH.$nid_back->photo)); ?>"
                                                         class="img-fluid" alt="">
                                                </div>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <input type="file" accept="image/x-png,image/jpeg" name="file_three"
                                                   id="file" ref="file" class="dropify"
                                                   <?php if(!empty($nid_back) && (!empty($nid_back->photo))): ?>  data-default-file="<?php echo e(asset(IMG_USER_VIEW_PATH.$nid_back->photo)); ?>" <?php endif; ?> />
                                        <?php endif; ?>

                                    </div>
                                </div>
                                <?php if(isset($nid_back) && isset($nid_front)): ?>
                                    <?php if((empty($nid_back ) && empty($nid_front)) || (($nid_back->status == STATUS_REJECTED) && ($nid_front->status == STATUS_REJECTED))): ?>
                                        <div class="col-12">
                                            <button type="submit" class="btn carduploadbtn"><?php echo e(__('Upload')); ?></button>
                                        </div>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <div class="col-12">
                                        <button type="submit" class="btn carduploadbtn"><?php echo e(__('Upload')); ?></button>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade cp-user-passwordverifymodal" id="exampleModalCenter" tabindex="-1" role="dialog"
         aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true"><img src="<?php echo e(asset('assets/user/images/close.svg')); ?>" class="img-fluid"
                                                      alt=""></span>
                    </button>
                    <form id="nidUpload" class="Upload" action="<?php echo e(route('passUpload')); ?>" enctype="multipart/form-data"
                          method="post">
                        <?php echo csrf_field(); ?>
                        <div class="container">
                            <div class="row">
                                <div class="col-12">
                                    <div class="card-list">
                                        <div class="alert alert-danger d-none error_msg" id="" role="alert">
                                        </div>
                                        <div class="alert alert-success d-none succ_msg" id="" role="alert">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 mb-lg-0 mb-4">
                                    <div class="idcard">
                                        <h3 class="title"><?php echo e(__('Front Side')); ?></h3>
                                        <div id="file-upload" class="section-p">
                                            <?php if((isset($pass_back ) && isset($pass_front))): ?>
                                                <?php if((empty($pass_back ) && empty($pass_front)) || (($pass_back->status == STATUS_REJECTED) && ($pass_front->status == STATUS_REJECTED))): ?>
                                                    <input type="file" accept="image/x-png,image/jpeg" name="file_two"
                                                           id="file" ref="file" class="dropify"
                                                           <?php if(!empty($pass_front) && (!empty($pass_front->photo))): ?>  data-default-file="<?php echo e(asset(IMG_USER_VIEW_PATH.$pass_front->photo)); ?>" <?php endif; ?> />
                                                <?php else: ?>
                                                    <div class="card-inner">
                                                        <img src="<?php echo e(asset(IMG_USER_VIEW_PATH.$pass_front->photo)); ?>"
                                                             class="img-fluid" alt="">
                                                    </div>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <input type="file" accept="image/x-png,image/jpeg" name="file_two"
                                                       id="file" ref="file" class="dropify"
                                                       <?php if(!empty($pass_front) && (!empty($pass_front->photo))): ?>  data-default-file="<?php echo e(asset(IMG_USER_VIEW_PATH.$pass_front->photo)); ?>" <?php endif; ?> />
                                            <?php endif; ?>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 mb-lg-0 mb-4">
                                    <div class="idcard">
                                        <h3 class="title"><?php echo e(__('Back Side')); ?></h3>
                                        <?php if((isset($pass_back ) && isset($pass_front))): ?>
                                            <?php if((empty($pass_back ) && empty($pass_front)) || (($pass_back->status == STATUS_REJECTED) && ($pass_front->status == STATUS_REJECTED))): ?>
                                                <input type="file" accept="image/x-png,image/jpeg" name="file_three"
                                                       id="file" ref="file" class="dropify"
                                                       <?php if(!empty($pass_back) && (!empty($pass_back->photo))): ?>  data-default-file="<?php echo e(asset(IMG_USER_VIEW_PATH.$pass_back->photo)); ?>" <?php endif; ?> />
                                            <?php else: ?>
                                                <div class="card-inner">
                                                    <img src="<?php echo e(asset(IMG_USER_VIEW_PATH.$pass_back->photo)); ?>"
                                                         class="img-fluid" alt="">
                                                </div>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <input type="file" accept="image/x-png,image/jpeg" name="file_three"
                                                   id="file" ref="file" class="dropify"
                                                   <?php if(!empty($pass_back) && (!empty($pass_back->photo))): ?>  data-default-file="<?php echo e(asset(IMG_USER_VIEW_PATH.$pass_back->photo)); ?>" <?php endif; ?> />

                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php if((isset($pass_back ) && isset($pass_front))): ?>
                                    <?php if((empty($pass_back ) && empty($pass_front)) || (($pass_back->status == STATUS_REJECTED) && ($pass_front->status == STATUS_REJECTED))): ?>
                                        <div class="col-12">
                                            <button type="submit" class="btn carduploadbtn"><?php echo e(__('Upload')); ?></button>
                                        </div>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <div class="col-12">
                                        <button type="submit" class="btn carduploadbtn"><?php echo e(__('Upload')); ?></button>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade cp-user-driververifymodal" id="exampleModalCenter" tabindex="-1" role="dialog"
         aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true"><img src="<?php echo e(asset('assets/user/images/close.svg')); ?>" class="img-fluid"
                                                      alt=""></span>
                    </button>
                    <form id="nidUpload" class="Upload" action="<?php echo e(route('driveUpload')); ?>" enctype="multipart/form-data"
                          method="post">
                        <?php echo csrf_field(); ?>
                        <div class="container">
                            <div class="row">
                                <div class="col-12">
                                    <div class="card-list">
                                        <div class="alert alert-danger d-none error_msg" id="" role="alert">
                                        </div>
                                        <div class="alert alert-success d-none succ_msg" id="" role="alert">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 mb-lg-0 mb-4">
                                    <div class="idcard">
                                        <h3 class="title"><?php echo e(__('Front Side')); ?></h3>
                                        <div id="file-upload" class="section-p">
                                            <?php if((isset($drive_back ) && isset($drive_front))): ?>
                                                <?php if((empty($drive_back ) && empty($drive_front)) || (($drive_back->status == STATUS_REJECTED) && ($drive_front->status == STATUS_REJECTED))): ?>
                                                    <input type="file" accept="image/x-png,image/jpeg" name="file_two"
                                                           id="file" ref="file" class="dropify"
                                                           <?php if(!empty($drive_front) && (!empty($drive_front->photo))): ?>  data-default-file="<?php echo e(asset(IMG_USER_VIEW_PATH.$drive_front->photo)); ?>" <?php endif; ?> />
                                                <?php else: ?>
                                                    <div class="card-inner">
                                                        <img src="<?php echo e(asset(IMG_USER_VIEW_PATH.$drive_front->photo)); ?>"
                                                             class="img-fluid" alt="">
                                                    </div>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <input type="file" accept="image/x-png,image/jpeg" name="file_two"
                                                       id="file" ref="file" class="dropify"
                                                       <?php if(!empty($drive_front) && (!empty($drive_front->photo))): ?>  data-default-file="<?php echo e(asset(IMG_USER_VIEW_PATH.$drive_front->photo)); ?>" <?php endif; ?> />

                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 mb-lg-0 mb-4">
                                    <div class="idcard">
                                        <h3 class="title"><?php echo e(__('Back Side')); ?></h3>
                                        <?php if((isset($drive_back ) && isset($drive_front))): ?>
                                            <?php if((empty($drive_back ) && empty($drive_front)) || (($drive_back->status == STATUS_REJECTED) && ($drive_front->status == STATUS_REJECTED))): ?>
                                                <input type="file" accept="image/x-png,image/jpeg" name="file_three"
                                                       id="file" ref="file" class="dropify"
                                                       <?php if(!empty($drive_back) && (!empty($drive_back->photo))): ?>  data-default-file="<?php echo e(asset(IMG_USER_VIEW_PATH.$drive_back->photo)); ?>" <?php endif; ?> />
                                            <?php else: ?>
                                                <div class="card-inner">
                                                    <img src="<?php echo e(asset(IMG_USER_VIEW_PATH.$drive_back->photo)); ?>"
                                                         class="img-fluid" alt="">
                                                </div>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <input type="file" accept="image/x-png,image/jpeg" name="file_three"
                                                   id="file" ref="file" class="dropify"
                                                   <?php if(!empty($drive_back) && (!empty($drive_back->photo))): ?>  data-default-file="<?php echo e(asset(IMG_USER_VIEW_PATH.$drive_back->photo)); ?>" <?php endif; ?> />

                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php if((isset($drive_back ) && isset($drive_front))): ?>
                                    <?php if((empty($drive_back ) && empty($drive_front)) || (($drive_back->status == STATUS_REJECTED) && ($drive_front->status == STATUS_REJECTED))): ?>
                                        <div class="col-12">
                                            <button type="submit" class="btn carduploadbtn"><?php echo e(__('Upload')); ?></button>
                                        </div>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <div class="col-12">
                                        <button type="submit" class="btn carduploadbtn"><?php echo e(__('Upload')); ?></button>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $('.nav-link').on('click', function () {
            var query = $(this).data('id');
            window.history.pushState('page2', 'Title', '<?php echo e(route('userProfile')); ?>?qr=' + query);
        });

        jQuery("#upload-user-img").change(function () {
            this.form.submit();
        });

        $(function () {
            $(document.body).on('submit', '.Upload', function (e) {
                e.preventDefault();
                $('.error_msg').addClass('d-none');
                $('.succ_msg').addClass('d-none');
                var form = $(this);
                $.ajax({
                    type: "POST",
                    enctype: 'multipart/form-data',
                    url: form.attr('action'),
                    data: new FormData($(this)[0]),
                    async: false,
                    cache: false,
                    contentType: false,
                    processData: false,
                    success: function (data) {
                        if (data.success == true) {
                            $('.succ_msg').removeClass('d-none');
                            $('.succ_msg').html(data.message);

                            $(".succ_msg").fadeTo(2000, 500).slideUp(500, function () {
                                $(".succ_msg").slideUp(500);
                            });
                        } else {
                            $('.error_msg').removeClass('d-none');
                            $('.error_msg').html(data.message);

                            $(".error_msg").fadeTo(2000, 500).slideUp(500, function () {
                                $(".error_msg").slideUp(500);
                            });
                        }
                    }
                });
                return false;
            });
        });

        $(".reveal").on('click', function () {
            var $pwd = $(".show-pass");
            if ($pwd.attr('type') === 'password') {
                $pwd.attr('type', 'text');
            } else {
                $pwd.attr('type', 'password');
            }
        });

        $(".reveal-1").on('click', function () {
            var $pwd = $(".show-pass-1");
            if ($pwd.attr('type') === 'password') {
                $pwd.attr('type', 'text');
            } else {
                $pwd.attr('type', 'password');
            }
        });
        $(".reveal-2").on('click', function () {
            var $pwd = $(".show-pass-2");
            if ($pwd.attr('type') === 'password') {
                $pwd.attr('type', 'text');
            } else {
                $pwd.attr('type', 'password');
            }
        });
    </script>

    <script>
        $(".toggle-password").click(function () {
            $(this).toggleClass("fa-eye-slash fa-eye");
        });

        function showHidePassword(id) {

            var x = document.getElementById(id);
            if (x.type === "password") {
                x.type = "text";

            } else {
                x.type = "password";
            }
        }

        function readURL(input, img) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#' + img).attr('src', e.target.result);
                };
                reader.readAsDataURL(input.files[0]);
            }
        }

        $(document.body).on('click', '#password_btn', function () {
            console.log($('#password').input.type);
        });
    </script>

    <script>
        $(document.body).on('click', '.iti__country', function () {
            var cd = $(this).find('.iti__dial-code').html();
            $('#code_v').val(cd)
        });
    </script>

    <script>
        $('#activity-tbl').DataTable({
            processing: true,
            serverSide: true,
            pageLength: 10,
            retrieve: true,
            bLengthChange: true,
            responsive: true,
            ajax: '<?php echo e(route('userProfile')); ?>',
            order: [3, 'desc'],
            autoWidth: false,
            language: {
                paginate: {
                    next: 'Next &#8250;',
                    previous: '&#8249; Previous'
                }
            },
            columns: [
                {"data": "action", "orderable": false},
                {"data": "source", "orderable": false},
                {"data": "ip_address", "orderable": false},
                {"data": "updated_at", "orderable": true},
            ],
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.master',['menu'=>'profile'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/cpoket-web/resources/views/user/profile/profile.blade.php ENDPATH**/ ?>