<?php $__env->startSection('title', isset($title) ? $title : ''); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- breadcrumb -->
    <div class="custom-breadcrumb">
        <div class="row">
            <div class="col-12">
                <ul>
                    <li><?php echo e(__('Bank Management')); ?></li>
                    <li class="active-item"><?php echo e($title); ?></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- /breadcrumb -->

    <!-- User Management -->
    <div class="user-management">
        <div class="row">
            <div class="col-12">
                <div class="profile-info-form">
                    <div class="card-body">
                        <form action="<?php echo e(route('bankAddProcess')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6 mt-20">
                                    <div class="form-group">
                                        <label for="firstname"><?php echo e(__('Account Holder Name')); ?></label>
                                        <input type="text" name="account_holder_name" class="form-control" id="firstname" placeholder="<?php echo e(__('Holder name')); ?>"
                                               <?php if(isset($item)): ?> value="<?php echo e($item->account_holder_name); ?>" <?php else: ?> value="<?php echo e(old('account_holder_name')); ?>" <?php endif; ?>>
                                        <span class="text-danger"><strong><?php echo e($errors->first('account_holder_name')); ?></strong></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mt-20">
                                    <div class="form-group">
                                        <label for="lastname"><?php echo e(__('Account Holder Address')); ?></label>
                                        <input name="account_holder_address" type="text" class="form-control" id="lastname"  placeholder="<?php echo e(__('Account holder address')); ?>"
                                               <?php if(isset($item)): ?> value="<?php echo e($item->account_holder_address); ?>" <?php else: ?> value="<?php echo e(old('account_holder_address')); ?>" <?php endif; ?>>
                                        <span class="text-danger"><strong><?php echo e($errors->first('account_holder_address')); ?></strong></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mt-20">
                                    <div class="form-group">
                                        <label for="email"><?php echo e(__('Bank Name')); ?></label>
                                        <input type="text" name="bank_name" class="form-control" id="email" placeholder="<?php echo e(__('Bank Name')); ?>"
                                               <?php if(isset($item)): ?> value="<?php echo e($item->bank_name); ?>" <?php else: ?> value="<?php echo e(old('bank_name')); ?>" <?php endif; ?>>
                                        <span class="text-danger"><strong><?php echo e($errors->first('bank_name')); ?></strong></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mt-20">
                                    <div class="form-group">
                                        <label for="bank_address"><?php echo e(__('Bank Address')); ?></label>
                                        <input type="text" class="form-control" id="bank_address" name="bank_address"  placeholder="<?php echo e(__('Bank Address')); ?>"
                                               <?php if(isset($item)): ?> value="<?php echo e($item->bank_address); ?>" <?php else: ?> value="<?php echo e(old('bank_address')); ?>" <?php endif; ?>>
                                        <span class="text-danger"><strong><?php echo e($errors->first('bank_address')); ?></strong></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mt-20">
                                    <div class="form-group">
                                        <label for="iban"><?php echo e(__('IBAN')); ?></label>
                                        <input type="text" class="form-control" id="iban" name="iban"  placeholder="<?php echo e(__('Bank Account Number')); ?>"
                                               <?php if(isset($item)): ?> value="<?php echo e($item->iban); ?>" <?php else: ?> value="<?php echo e(old('iban')); ?>" <?php endif; ?>>
                                        <span class="text-danger"><strong><?php echo e($errors->first('iban')); ?></strong></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mt-20">
                                    <div class="form-group">
                                        <label for="swift_code"><?php echo e(__('Swift Code')); ?></label>
                                        <input type="text" class="form-control" id="swift_code" name="swift_code"  placeholder="<?php echo e(__('Swift Code')); ?>"
                                               <?php if(isset($item)): ?> value="<?php echo e($item->swift_code); ?>" <?php else: ?> value="<?php echo e(old('swift_code')); ?>" <?php endif; ?>>
                                        <span class="text-danger"><strong><?php echo e($errors->first('swift_code')); ?></strong></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mt-20">
                                    <div class="form-group">
                                        <label for="ref_code"><?php echo e(__('Reference Code')); ?></label>
                                        <input type="text" class="form-control" id="ref_code" name="ref_code"  placeholder="<?php echo e(__('Reference Code')); ?>"
                                               <?php if(isset($item)): ?> value="<?php echo e($item->ref_code); ?>" <?php else: ?> value="<?php echo e(old('ref_code')); ?>" <?php endif; ?>>
                                        <span class="text-danger"><strong><?php echo e($errors->first('ref_code')); ?></strong></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mt-20">
                                    <div class="form-group">
                                        <label><?php echo e(__('Country')); ?></label>
                                        <div class="cp-select-area">
                                        <select name="country" class="form-control wide">
                                            <option value=""><?php echo e(__('Select')); ?></option>
                                            <?php $__currentLoopData = country(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php if(isset($item) && ($item->country == $key)): ?> selected
                                                        <?php elseif((old('country') != null) && (old('country') == $key)): ?> <?php endif; ?> value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                                                <span class="text-danger"><strong><?php echo e($errors->first('country')); ?></strong></span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 mt-20">
                                    <div class="form-group">
                                        <label><?php echo e(__('Activation Status')); ?></label>
                                        <div class="cp-select-area">
                                            <select name="status" class="form-control wide" >
                                                <?php $__currentLoopData = status(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php if(isset($item) && ($item->status == $key)): ?> selected
                                                            <?php elseif((old('status') != null) && (old('status') == $key)): ?> <?php endif; ?> value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                                                    <span class="text-danger"><strong><?php echo e($errors->first('status')); ?></strong></span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12 mt-20">
                                    <div class="form-group">
                                        <label><?php echo e(__('Short Note')); ?></label>
                                        <textarea name="note" id="" rows="2" class="form-control"><?php if(isset($item)): ?><?php echo e($item->note); ?><?php else: ?><?php echo e(old('note')); ?><?php endif; ?></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <?php if(isset($item)): ?>
                                        <input type="hidden" name="edit_id" value="<?php echo e($item->id); ?>">
                                    <?php endif; ?>
                                    <button class="button-primary theme-btn"><?php if(isset($item)): ?> <?php echo e(__('Update')); ?> <?php else: ?> <?php echo e(__('Save')); ?> <?php endif; ?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /User Management -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master',['menu'=>'setting', 'sub_menu'=>'bank'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/cpoket-web/resources/views/admin/bank/addEdit.blade.php ENDPATH**/ ?>