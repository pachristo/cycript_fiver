<?php $__env->startSection('title', isset($title) ? $title : ''); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- breadcrumb -->
    <div class="custom-breadcrumb">
        <div class="row">
            <div class="col-12">
                <ul>
                    <li><?php echo e(__('Buy Coin Order List')); ?></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- /breadcrumb -->

    <!-- User Management -->
    <div class="user-management">
        <div class="row">
            <div class="col-12">
                <ul class="nav user-management-nav mb-3" id="pills-tab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="pills-user-tab" data-toggle="pill" href="#pills-user" role="tab"
                           aria-controls="pills-user" aria-selected="true">
                            <span><?php echo e(__('Pending List')); ?></span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="pills-suspended-user-tab" data-toggle="pill"
                           href="#pills-suspended-user" role="tab" aria-controls="pills-suspended-user"
                           aria-selected="true">
                            <span><?php echo e(__('Approved List')); ?></span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="pills-deleted-user-tab" data-toggle="pill" href="#pills-deleted-user"
                           role="tab" aria-controls="pills-deleted-user" aria-selected="true">
                            <span><?php echo e(__('Rejected List')); ?></span>
                        </a>
                    </li>
                </ul>
                <div class="tab-content" id="pills-tabContent">
                    <div class="tab-pane show active" id="pills-user" role="tabpanel" aria-labelledby="pills-user-tab">
                        <div class="header-bar">
                            <div class="table-title">
                                <h3><?php echo e(__('Pending Order List')); ?></h3>
                            </div>
                        </div>
                        <div class="table-area">
                            <div class=" table-responsive">
                                <table id="table"
                                       class="table responsive table-borderless custom-table display text-center"
                                       width="100%">
                                    <thead>
                                    <tr>
                                        <th scope="col" class="all"><?php echo e(__('Email')); ?></th>
                                        <th scope="col" class="desktop"><?php echo e(__('Coin amount')); ?></th>
                                        <th scope="col" class="desktop"><?php echo e(__('Payable Coin')); ?></th>
                                        <th scope="col" class="desktop"><?php echo e(__('Payment Type')); ?></th>
                                        <th scope="col" class="desktop"><?php echo e(__('Address')); ?></th>
                                        <th scope="col" class="all"><?php echo e(__('Date')); ?></th>
                                        <th scope="col" class="all"><?php echo e(__('Actions')); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="pills-suspended-user" role="tabpanel"
                         aria-labelledby="pills-suspended-user-tab">
                        <div class="header-bar">
                            <div class="table-title">
                                <h3><?php echo e(__('Approved Order List')); ?></h3>
                            </div>
                        </div>
                        <div class="table-area">
                            <div class=" table-responsive">
                                <table id="table-approved"
                                       class="table responsive table-borderless custom-table display text-center"
                                       width="100%">
                                    <thead>
                                    <tr>
                                        <th scope="col" class="all"><?php echo e(__('Email')); ?></th>
                                        <th scope="col" class="desktop"><?php echo e(__('Coin Amount')); ?></th>
                                        <th scope="col" class="desktop"><?php echo e(__('Payable Coin')); ?></th>
                                        <th scope="col" class="desktop"><?php echo e(__('Payment Type')); ?></th>
                                        <th scope="col" class="desktop"><?php echo e(__('Address')); ?></th>
                                        <th scope="col" class="all"><?php echo e(__('Date')); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="pills-deleted-user" role="tabpanel"
                         aria-labelledby="pills-deleted-user-tab">
                        <div class="header-bar">
                            <div class="table-title">
                                <h3><?php echo e(__('Rejected Order List')); ?></h3>
                            </div>
                        </div>
                        <div class="table-area">
                            <div class="table-responsive">
                                <table id="table-rejected"
                                       class="table table-borderless custom-table display text-center" width="100%">
                                    <thead>
                                    <tr>
                                        <th scope="col" class="all"><?php echo e(__('Email')); ?></th>
                                        <th scope="col" class="desktop"><?php echo e(__('Coin Amount')); ?></th>
                                        <th scope="col" class="desktop"><?php echo e(__('Payable Coin')); ?></th>
                                        <th scope="col" class="desktop"><?php echo e(__('Payment Type')); ?></th>
                                        <th scope="col" class="desktop"><?php echo e(__('Address')); ?></th>
                                        <th scope="col" class="all"><?php echo e(__('Date')); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /User Management -->
        <?php $__env->stopSection(); ?>

        <?php $__env->startSection('script'); ?>
            <script>

                $('#table').DataTable({
                    processing: true,
                    serverSide: true,
                    pageLength: 10,
                    responsive: true,
                    order: [5, 'desc'],
                    autoWidth: false,
                    ajax: '<?php echo e(route('adminPendingCoinOrder')); ?>',
                    language: {
                        paginate: {
                            next: 'Next &#8250;',
                            previous: '&#8249; Previous'
                        }
                    },
                    columns: [
                        {"data": "email","orderable": true},
                        {"data": "coin","orderable": true},
                        {"data": "btc","orderable": true},
                        {"data": "payment_type","orderable": false},
                        {"data": "address","orderable": true},
                        {"data": "created_at","orderable": true},
                        {"data": "action","orderable": false}
                    ]
                });

            </script>
            <script>
                $('#table-approved').DataTable({
                    processing: true,
                    serverSide: true,
                    pageLength: 25,
                    responsive: true,
                    order: [5, 'desc'],
                    autoWidth: false,
                    ajax: '<?php echo e(route('adminApprovedOrder')); ?>',
                    language: {
                        paginate: {
                            next: 'Next &#8250;',
                            previous: '&#8249; Previous'
                        }
                    },
                    columns: [
                        {"data": "email"},
                        {"data": "coin"},
                        {"data": "btc"},
                        {"data": "payment_type","orderable": false},
                        {"data": "address"},
                        {"data": "created_at","orderable": true},
                    ]
                });

            </script>
            <script>
                $('#table-rejected').DataTable({
                    processing: true,
                    serverSide: true,
                    pageLength: 10,
                    responsive: true,
                    order: [5, 'desc'],
                    autoWidth: false,
                    ajax: '<?php echo e(route('adminRejectedOrder')); ?>',
                    language: {
                        paginate: {
                            next: 'Next &#8250;',
                            previous: '&#8249; Previous'
                        }
                    },
                    columns: [
                        {"data": "email"},
                        {"data": "coin"},
                        {"data": "btc"},
                        {"data": "payment_type","orderable": false},
                        {"data": "address"},
                        {"data": "created_at","orderable": true},
                    ]
                });

            </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master',['menu'=>'buy_coin','sub_menu'=>'buy_coin'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/cpoket-web/resources/views/admin/coin-order/pending_list.blade.php ENDPATH**/ ?>