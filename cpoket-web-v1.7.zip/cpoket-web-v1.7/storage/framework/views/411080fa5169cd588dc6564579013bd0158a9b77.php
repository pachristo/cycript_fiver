<?php $__env->startSection('title', isset($title) ? $title : ''); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- breadcrumb -->
    <div class="custom-breadcrumb">
        <div class="row">
            <div class="col-12">
                <ul>
                    <li><?php echo e(__('Transaction History')); ?> </li>
                    <li class="active-item"><?php echo e(__('Withdrawal History')); ?></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- /breadcrumb -->

    <!-- User Management -->
    <div class="user-management wallet-transaction-area">
        <div class="row">
            <div class="col-12">

                <div class="header-bar">
                    <ul class="nav wallet-transaction user-management-nav mb-3" id="pills-tab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="pills-deposit-tab" data-toggle="pill" href="#pills-deposit"
                               role="tab" aria-controls="pills-deposit" aria-selected="true">
                                <?php echo e(__('Pending Withdrawal List')); ?>

                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="pills-withdraw-tab" data-toggle="pill" href="#pills-withdraw"
                               role="tab" aria-controls="pills-withdraw" aria-selected="true">
                                <?php echo e(__('Rejected Withdrawal List')); ?>

                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="pills-success-withdraw-tab" data-toggle="pill"
                               href="#pills-success-withdraw" role="tab" aria-controls="pills-success-withdraw"
                               aria-selected="true">
                                <?php echo e(__('Active Withdrawal List')); ?>

                            </a>
                        </li>
                    </ul>
                </div>
                <div class="card-body">
                    <div class="tab-content" id="pills-tabContent">
                        <div class="tab-pane fade show active" id="pills-deposit" role="tabpanel"
                             aria-labelledby="pills-deposit-tab">
                            <div class="table-area">
                                <div class="table-responsive">
                                    <table id="table" class="table table-borderless custom-table display text-left"
                                           width="100%">
                                        <thead>
                                        <tr>
                                            <th class="all"><?php echo e(__('Type')); ?></th>
                                            <th class="all"><?php echo e(__('Sender')); ?></th>
                                            <th class="all"><?php echo e(__('Coin Type')); ?></th>
                                            <th class="all"><?php echo e(__('Address')); ?></th>
                                            <th class="all"><?php echo e(__('Receiver')); ?></th>
                                            <th class="all"><?php echo e(__('Amount')); ?></th>
                                            <th class="all"><?php echo e(__('Fees')); ?></th>
                                            <th class="all"><?php echo e(__('Transaction Id')); ?></th>
                                            <th class="all"><?php echo e(__('Update Date')); ?></th>
                                            <th class="all"><?php echo e(__('Actions')); ?></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="pills-withdraw" role="tabpanel"
                             aria-labelledby="pills-withdraw-tab">
                            <div class="table-area">
                                <div class="table-responsive">
                                    <table id="reject-withdrawal"
                                           class="table table-borderless custom-table display text-left" width="100%">
                                        <thead>
                                        <tr>
                                            <th class="all"><?php echo e(__('Type')); ?></th>
                                            <th class="all"><?php echo e(__('Sender')); ?></th>
                                            <th class="all"><?php echo e(__('Coin Type')); ?></th>
                                            <th class="all"><?php echo e(__('Address')); ?></th>
                                            <th class="all"><?php echo e(__('Receiver')); ?></th>
                                            <th class="all"><?php echo e(__('Amount')); ?></th>
                                            <th class="all"><?php echo e(__('Fees')); ?></th>
                                            <th class="all"><?php echo e(__('Transaction Id')); ?></th>
                                            <th class="all"><?php echo e(__('Update Date')); ?></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="pills-success-withdraw" role="tabpanel"
                             aria-labelledby="pills-success-withdraw-tab">
                            <div class="table-area">
                                <div class="table-responsive">
                                    <table id="success-withdrawal"
                                           class="table table-borderless custom-table display text-left" width="100%">
                                        <thead>
                                        <tr>
                                            <th class="all"><?php echo e(__('Type')); ?></th>
                                            <th class="all"><?php echo e(__('Sender')); ?></th>
                                            <th class="all"><?php echo e(__('Coin Type')); ?></th>
                                            <th class="all"><?php echo e(__('Address')); ?></th>
                                            <th class="all"><?php echo e(__('Receiver')); ?></th>
                                            <th class="all"><?php echo e(__('Amount')); ?></th>
                                            <th class="all"><?php echo e(__('Fees')); ?></th>
                                            <th class="all"><?php echo e(__('Transaction Id')); ?></th>
                                            <th class="all"><?php echo e(__('Update Date')); ?></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /User Management -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $('#table').DataTable({
            processing: true,
            serverSide: true,
            pageLength: 25,
            responsive: false,
            ajax: '<?php echo e(route('adminPendingWithdrawal')); ?>',
            order: [8, 'desc'],
            autoWidth: false,
            language: {
                paginate: {
                    next: 'Next &#8250;',
                    previous: '&#8249; Previous'
                }
            },
            columns: [
                {"data": "address_type"},
                {"data": "sender"},
                {"data": "coin_type"},
                {"data": "address"},
                {"data": "receiver"},
                {"data": "amount"},
                {"data": "fees"},
                {"data": "transaction_hash"},
                {"data": "updated_at"},
                {"data": "actions"}
            ]
        });
    </script>
    <script>
        $('#reject-withdrawal').DataTable({
            processing: true,
            serverSide: true,
            pageLength: 25,
            responsive: false,
            ajax: '<?php echo e(route('adminRejectedWithdrawal')); ?>',
            order: [8, 'desc'],
            autoWidth: false,
            language: {
                paginate: {
                    next: 'Next &#8250;',
                    previous: '&#8249; Previous'
                }
            },
            columns: [
                {"data": "address_type"},
                {"data": "sender"},
                {"data": "coin_type"},
                {"data": "address"},
                {"data": "receiver"},
                {"data": "amount"},
                {"data": "fees"},
                {"data": "transaction_hash"},
                {"data": "updated_at"},
            ]
        });
    </script>
    <script>
        $('#success-withdrawal').DataTable({
            processing: true,
            serverSide: true,
            pageLength: 25,
            responsive: false,
            ajax: '<?php echo e(route('adminActiveWithdrawal')); ?>',
            order: [8, 'desc'],
            autoWidth: false,
            language: {
                paginate: {
                    next: 'Next &#8250;',
                    previous: '&#8249; Previous'
                }
            },
            columns: [
                {"data": "address_type"},
                {"data": "sender"},
                {"data": "coin_type"},
                {"data": "address"},
                {"data": "receiver"},
                {"data": "amount"},
                {"data": "fees"},
                {"data": "transaction_hash"},
                {"data": "updated_at"},
            ]
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master',['menu'=>'transaction', 'sub_menu'=>'transaction_withdrawal'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/cpoket-web/resources/views/admin/transaction/pending-withdrawal.blade.php ENDPATH**/ ?>