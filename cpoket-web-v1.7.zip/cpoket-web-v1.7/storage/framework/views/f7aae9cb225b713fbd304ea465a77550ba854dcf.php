<?php $__env->startSection('title', isset($title) ? $title : ''); ?>
<?php $__env->startSection('style'); ?>
    <style>
        .address-pagin ul.pagination li.page-item:not(:last-child) {
            margin-right: 5px;
        }

        .address-pagin ul.pagination .page-item .page-link {
            color: #fff;
            background: transparent;
            border: none;
            font-size: 16px;
            width: 30px;
            height: 30px;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .address-pagin ul.pagination .page-item:hover .page-link,
        .address-pagin ul.pagination .page-item.active .page-link {
            background: linear-gradient(to bottom, #3e4c8d 0%, #4254a5 100%);
            border-radius: 2px;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card cp-user-custom-card cp-user-deposit-card">
        <div class="row">
            <div class="col-sm-12">
                <div class="wallet-inner">
                    <div class="wallet-content card-body">
                        <div class="wallet-top cp-user-card-header-area">
                            <div class="title">
                                <div class="wallet-title text-center">
                                    <h4><?php echo e($wallet->name); ?></h4>
                                </div>
                            </div>
                            <div class="tab-navbar">
                                <div class="tabe-menu">
                                    <ul class="nav cp-user-profile-nav mb-0" id="myTab" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link wallet <?php echo e(($active == 'deposit') ? 'active' : ''); ?>"
                                               id="diposite-tab"
                                               href="<?php echo e(route('walletDetails',$wallet->id)); ?>?q=deposit"
                                               aria-controls="diposite" aria-selected="true">
                                                <i class="flaticon-wallet"></i> <?php echo e(__('Deposit')); ?>

                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link send  <?php echo e(($active == 'withdraw') ? 'active' : ''); ?>"
                                               id="withdraw-tab"
                                               href="<?php echo e(route('walletDetails',$wallet->id)); ?>?q=withdraw"
                                               aria-controls="withdraw" aria-selected="false">
                                                <i class="flaticon-send"> </i> <?php echo e(__('Withdraw')); ?>

                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link share  <?php echo e(($active == 'activity') ? 'active' : ''); ?>"
                                               id="activity-tab"
                                               href="<?php echo e(route('walletDetails',$wallet->id)); ?>?q=activity"
                                               aria-controls="activity" aria-selected="false">
                                                <i class="flaticon-share"> </i> <?php echo e(__('Activity log')); ?>

                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade   <?php echo e(($active == 'deposit') ? 'show active' : ''); ?> in"
                                 id="diposite" role="tabpanel"
                                 aria-labelledby="diposite-tab">
                                <div class="row">
                                    <div class="col-lg-4 offset-lg-1">
                                        <div class="qr-img text-center">
                                            <?php if(!empty($address)): ?>  <?php echo QrCode::size(300)->generate($address);; ?>

                                            <?php else: ?>
                                                <?php echo QrCode::size(300)->generate(0);; ?>

                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="cp-user-copy tabcontent-right">
                                            <form action="#" class="px-3">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <button type="button"
                                                                class="copy_to_clip btn"><?php echo e(__('Copy')); ?></button>
                                                    </div>
                                                    <input readonly value="<?php echo e(isset($address) ? $address : 0); ?>"
                                                           type="text" class="form-control" id="address">
                                                </div>
                                            </form>
                                            <div class="aenerate-address">
                                                <a class="btn cp-user-buy-btn"
                                                   href="<?php echo e(route('generateNewAddress')); ?>?wallet_id=<?php echo e($wallet_id); ?>">
                                                    <?php echo e(__('Generate a new address')); ?>

                                                </a>
                                            </div>
                                            <div class="show-post">
                                                <button class="btn cp-user-buy-btn"
                                                        onclick="$('.address-list').toggleClass('show');">Show past
                                                    address
                                                </button>
                                                <div class="address-list">
                                                    <div class="cp-user-wallet-table table-responsive">
                                                        <table class="table">
                                                            <thead>
                                                            <tr>
                                                                <th><?php echo e(__('Address')); ?></th>
                                                                <th><?php echo e(__('Created At')); ?></th>
                                                            </tr>
                                                            </thead>
                                                            <tbody>
                                                            <?php $__currentLoopData = $address_histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address_history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td><?php echo e($address_history->address); ?></td>
                                                                    <td><?php echo e($address_history->created_at); ?></td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tbody>
                                                        </table>


                                                        <?php if(isset($address_histories[0])): ?>
                                                            <div class="pull-right address-pagin">
                                                                <?php echo e($address_histories->appends(request()->input())->links()); ?>

                                                            </div>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade <?php echo e(($active == 'withdraw') ? 'show active' : ''); ?> in" id="withdraw"
                                 role="tabpanel" aria-labelledby="withdraw-tab">
                                <div class="row">
                                    <div class="col-lg-6 offset-lg-3">
                                        <div class="form-area cp-user-profile-info withdraw-form">
                                            <form action="<?php echo e(route('WithdrawBalance')); ?>" method="post"
                                                  id="withdrawFormData">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="wallet_id" value="<?php echo e($wallet_id); ?>">
                                                <div class="form-group">
                                                    <label for="to">To</label>
                                                    <input name="address" type="text" class="form-control" id="to"
                                                           placeholder="<?php echo e(__('Address')); ?>">
                                                    <span class="flaticon-wallet icon"></span>
                                                    <span
                                                        class="text-warning"><?php echo e(__('Note : Please input here your ')); ?> <?php echo e(find_coin_type($wallet->coin_type)); ?> <?php echo e(__(' Coin address for withdrawal')); ?></span><br>
                                                    <span
                                                        class="text-danger"><?php echo e(__('Warning : Please input your ')); ?> <?php echo e(find_coin_type($wallet->coin_type)); ?> <?php echo e(__(' Coin address carefully. Because of wrong address if coin is lost, we will not responsible for that.')); ?></span>
                                                </div>
                                                <div class="form-group">
                                                    <label for="amount"><?php echo e(__('Amount')); ?></label>
                                                    <input name="amount" type="text" class="form-control" id="amount"
                                                           placeholder="Amount">
                                                    <span class="text-warning"
                                                          style="font-weight: 700;"><?php echo e(__('Minimum withdrawal amount : ')); ?></span>
                                                    <span
                                                        class="text-warning"><?php echo e(settings('minimum_withdrawal_amount')); ?> <?php echo e(find_coin_type($wallet->coin_type)); ?></span>
                                                    <span class="text-warning"><?php echo e(__(' and ')); ?></span>
                                                    <span class="text-warning"
                                                          style="font-weight: 700;"><?php echo e(__('Maximum withdrawal amount : ')); ?></span>
                                                    <span
                                                        class="text-warning"><?php echo e(settings('maximum_withdrawal_amount')); ?> <?php echo e(find_coin_type($wallet->coin_type)); ?></span>
                                                    <p class="text-warning" id="equ_btc"><span class="totalBTC"></span>
                                                        <span class="coinType"></span></p>
                                                </div>
                                                <div class="form-group">
                                                    <label for="note"><?php echo e(__('Note')); ?></label>
                                                    <textarea class="form-control" name="message" id="note"
                                                              placeholder="<?php echo e(__('Type your message here(Optional)')); ?>"></textarea>
                                                </div>
                                                <button onclick="withDrawBalance()" type="button"
                                                        class="btn profile-edit-btn"><?php echo e(__('Submit')); ?></button>
                                                <div class="modal fade" id="g2fcheck" tabindex="-1" role="dialog"
                                                     aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title"
                                                                    id="exampleModalLabel"><?php echo e(__('Google Authentication')); ?></h5>
                                                                <button type="button" class="close" data-dismiss="modal"
                                                                        aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <div class="row">
                                                                    <div class="col-12">
                                                                        <p><?php echo e(__('Open your Google Authenticator app and enter the 6-digit code from the app into the input field to remove the google secret key')); ?></p>
                                                                        <input placeholder="<?php echo e(__('Code')); ?>" required
                                                                               type="text" class="form-control"
                                                                               name="code">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary"
                                                                        data-dismiss="modal"><?php echo e(__('Close')); ?></button>
                                                                <button type="submit"
                                                                        class="btn btn-primary"><?php echo e(__('Verify')); ?></button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade  <?php echo e(($active == 'activity') ? 'show active' : ''); ?> in"
                                 id="activity" role="tabpanel" aria-labelledby="activity-tab">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="activity-area">
                                            <div class="activity-top-area">
                                                <div class="cp-user-card-header-area">
                                                    <div class="title">
                                                        <h4 id="list_title"><?php echo e(__('All Deposit List')); ?></h4>
                                                    </div>
                                                    <div class="deposite-tabs cp-user-deposit-card">
                                                        <div class="activity-right text-right">
                                                            <ul class="nav cp-user-profile-nav mb-0">
                                                                <li class="nav-item">
                                                                    <a class="nav-link <?php if(!isset($ac_tab)): ?> active <?php endif; ?>"
                                                                       data-toggle="tab"
                                                                       onclick="$('#list_title').html('All Deposit List')"
                                                                       data-title=""
                                                                       href="#Deposit"><?php echo e(__('Deposit')); ?></a>
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a class="nav-link <?php if(isset($ac_tab) && $ac_tab == 'withdraw'): ?> active <?php endif; ?>"
                                                                       data-toggle="tab"
                                                                       onclick="$('#list_title').html('All Withdrawal List')"
                                                                       href="#Withdraw"><?php echo e(__('Withdraw')); ?></a>
                                                                </li>
                                                                <?php if(co_wallet_feature_active() && $wallet->type == CO_WALLET): ?>
                                                                    <li class="nav-item">
                                                                        <a class="nav-link <?php if(isset($ac_tab) && $ac_tab == 'co-withdraw'): ?> active <?php endif; ?>"
                                                                           data-toggle="tab"
                                                                           onclick="$('#list_title').html('Pending Co Withdrawals')"
                                                                           href="#co-withdraw"><?php echo e(__('Pending Co Withdraw')); ?></a>
                                                                    </li>
                                                                <?php endif; ?>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="activity-list">
                                                <div class="tab-content">
                                                    <div id="Deposit"
                                                         class="tab-pane fade <?php if(!isset($ac_tab)): ?> show active <?php endif; ?>">

                                                        <div class="cp-user-wallet-table table-responsive">
                                                            <table class="table">
                                                                <thead>
                                                                <tr>
                                                                    <th><?php echo e(__('Address')); ?></th>
                                                                    <th><?php echo e(__('Amount')); ?></th>
                                                                    <th><?php echo e(__('Transaction Hash')); ?></th>
                                                                    <th><?php echo e(__('Status')); ?></th>
                                                                    <th><?php echo e(__('Created At')); ?></th>
                                                                </tr>
                                                                </thead>
                                                                <tbody>
                                                                <?php if(isset($histories[0])): ?>
                                                                    <?php $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <tr>
                                                                            <td><?php echo e($history->address); ?></td>
                                                                            <td><?php echo e($history->amount); ?></td>
                                                                            <td><?php echo e($history->transaction_id); ?></td>
                                                                            <td><?php echo e(deposit_status($history->status)); ?></td>
                                                                            <td><?php echo e($history->created_at); ?></td>
                                                                        </tr>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php else: ?>
                                                                    <tr>
                                                                        <td colspan="5"
                                                                            class="text-center"><?php echo e(__('No data available')); ?></td>
                                                                    </tr>
                                                                <?php endif; ?>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                    <div id="Withdraw"
                                                         class="tab-pane fade <?php if(isset($ac_tab) && $ac_tab == 'withdraw'): ?> show active <?php endif; ?> ">

                                                        <div class="cp-user-wallet-table table-responsive">
                                                            <table class="table">
                                                                <thead>
                                                                <tr>
                                                                    <th><?php echo e(__('Address')); ?></th>
                                                                    <th><?php echo e(__('Amount')); ?></th>
                                                                    <th><?php echo e(__('Transaction Hash')); ?></th>
                                                                    <th><?php echo e(__('Status')); ?></th>
                                                                    <th><?php echo e(__('Created At')); ?></th>
                                                                </tr>
                                                                </thead>
                                                                <tbody>
                                                                <?php if(isset($withdraws[0])): ?>
                                                                    <?php $__currentLoopData = $withdraws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdraw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <tr>
                                                                            <td><?php echo e($withdraw->address); ?></td>
                                                                            <td><?php echo e($withdraw->amount); ?></td>
                                                                            <td><?php echo e($withdraw->transaction_hash); ?></td>
                                                                            <td><?php echo e(deposit_status($withdraw->status)); ?></td>
                                                                            <td><?php echo e($withdraw->created_at); ?></td>
                                                                        </tr>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php else: ?>
                                                                    <tr>
                                                                        <td colspan="5"
                                                                            class="text-center"><?php echo e(__('No data available')); ?></td>
                                                                    </tr>
                                                                <?php endif; ?>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                    <?php if(co_wallet_feature_active() && $wallet->type == CO_WALLET): ?>
                                                        <div id="co-withdraw"
                                                             class="tab-pane fade <?php if(isset($ac_tab) && $ac_tab == 'co-withdraw'): ?> show active <?php endif; ?>">

                                                            <div class="cp-user-wallet-table table-responsive">
                                                                <table class="table">
                                                                    <thead>
                                                                    <tr>
                                                                        <th><?php echo e(__('Address')); ?></th>
                                                                        <th><?php echo e(__('Amount')); ?></th>
                                                                        <th><?php echo e(__('Status')); ?></th>
                                                                        <th><?php echo e(__('Created At')); ?></th>
                                                                        <th><?php echo e(__('Actions')); ?></th>
                                                                    </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                    <?php if(isset($tempWithdraws[0])): ?>
                                                                        <?php $__currentLoopData = $tempWithdraws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdraw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <tr>
                                                                                <td><?php echo e($withdraw->address); ?></td>
                                                                                <td><?php echo e($withdraw->amount); ?></td>
                                                                                <td><?php echo e(__('Need co users approval')); ?></td>
                                                                                <td><?php echo e($withdraw->created_at); ?></td>
                                                                                <td>
                                                                                    <ul class="d-flex justify-content-center align-items-center">
                                                                                        <li>
                                                                                            <a title="<?php echo e(__('Approvals')); ?>"
                                                                                               href="<?php echo e(route('coWalletApprovals', $withdraw->id)); ?>">
                                                                                                <img
                                                                                                    src="<?php echo e(asset('assets/user/images/wallet-table-icons/send.svg')); ?>"
                                                                                                    class="img-fluid" alt="">
                                                                                            </a>
                                                                                        </li>
                                                                                        <?php if($withdraw->user_id == \Illuminate\Support\Facades\Auth::id()): ?>
                                                                                            <li>
                                                                                                <a title="<?php echo e(__('Reject Withdraw')); ?>" class="confirm-modal"
                                                                                                   data-title="<?php echo e(__('Do you really want to reject?')); ?>"
                                                                                                   href="javascript:" data-href="<?php echo e(route('rejectCoWalletWithdraw', $withdraw->id)); ?>">
                                                                                                    <img style="width: 25px; opacity: 0.7"
                                                                                                        src="<?php echo e(asset('assets/user/images/close.png')); ?>"
                                                                                                        class="img-fluid"
                                                                                                        alt="">
                                                                                                </a>
                                                                                            </li>
                                                                                        <?php endif; ?>
                                                                                    </ul>
                                                                                </td>
                                                                            </tr>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php else: ?>
                                                                        <tr>
                                                                            <td colspan="5"
                                                                                class="text-center"><?php echo e(__('No data available')); ?></td>
                                                                        </tr>
                                                                    <?php endif; ?>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function withDrawBalance() {
            var g2fCheck = '<?php echo e(\Illuminate\Support\Facades\Auth::user()->google2fa_secret); ?>';


            if (g2fCheck.length > 1) {
                var frm = $('#withdrawFormData');

                $.ajax({
                    type: frm.attr('method'),
                    url: frm.attr('action'),
                    data: frm.serialize(),
                    success: function (data) {
                        console.log(data.success);
                        if (data.success == true) {
                            $('#g2fcheck').modal('show');

                        } else {
                            VanillaToasts.create({
                                // title: 'Message Title',
                                text: data.message,
                                type: 'warning',
                                timeout: 3000

                            });
                        }

                    },
                    error: function (data) {

                    },
                });
            } else {
                VanillaToasts.create({
                    // title: 'Message Title',
                    text: "<?php echo e(__('Your google authentication is disabled,please enable it')); ?>",
                    type: 'warning',
                    timeout: 3000

                });
            }

        }
    </script>
    <script>


        document.querySelector('button').addEventListener('click', function (event) {

            var copyTextarea = document.querySelector('#address');
            copyTextarea.focus();
            copyTextarea.select();

            try {
                var successful = document.execCommand('copy');
                VanillaToasts.create({
                    // title: 'Message Title',
                    text: '<?php echo e(__('Address copied successfully')); ?>',
                    type: 'success',

                });
            } catch (err) {

            }
        });

        function generateNewAddress() {
            $.ajax({
                type: "GET",
                enctype: 'multipart/form-data',
                url: "<?php echo e(route('generateNewAddress')); ?>?wallet_id=<?php echo e($wallet_id); ?>",
                success: function (data) {
                    if (data.success == true) {

                        $('#address').val(data.address);
                        var srcVal = "<?php echo e(route('qrCodeGenerate')); ?>?address=" + data.address;
                        document.getElementById('qrcode').src = srcVal;
                        VanillaToasts.create({
                            // title: 'Message Title',
                            text: data.message,
                            type: 'success',
                            timeout: 3000

                        });
                        $('#qrcode').src(data.qrcode);
                    } else {

                        VanillaToasts.create({
                            // title: 'Message Title',
                            text: data.message,
                            type: 'warning',
                            timeout: 3000

                        });

                    }
                }
            });
        }
    </script>

    
    
    
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    
    
    

    
    
    
    

    
    
    
    

    

    
    <!-- copy_to_clip -->
    <script>
        $('.copy_to_clip').on('click', function () {
            /* Get the text field */
            var copyFrom = document.getElementById("address");

            /* Select the text field */
            copyFrom.select();

            /* Copy the text inside the text field */
            document.execCommand("copy");

            VanillaToasts.create({
                title: 'Copied the text',
                // text: copyFrom.value,
                type: 'success',
                timeout: 3000,
                positionClass: 'topCenter'
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.master',['menu'=>'pocket','sub_menu'=>'my_pocket'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/cpoket-web/resources/views/user/pocket/wallet_details.blade.php ENDPATH**/ ?>