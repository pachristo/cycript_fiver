<!DOCTYPE HTML>
<html class="no-js" lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta property="og:type" content="article" />
    
    <meta property="og:image" content="<?php echo e(asset('assets/admin/images/logo.svg')); ?>">
    <meta property="og:site_name" content="Cpoket"/>
    <meta property="og:url" content="<?php echo e(url()->current()); ?>"/>
    <meta itemprop="image" content="<?php echo e(asset('assets/admin/images/logo.svg')); ?>" />
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/bootstrap.min.css')); ?>">
    <!-- metismenu CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/metisMenu.min.css')); ?>">
    <!-- fontawesome CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/font-awesome.min.css')); ?>">
    
    <link href="<?php echo e(asset('assets/toast/vanillatoasts.css')); ?>" rel="stylesheet" >
    <!-- Style CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/style.css')); ?>">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/responsive.css')); ?>">
    <?php echo $__env->yieldContent('style'); ?>
    <title><?php echo $__env->yieldContent('title'); ?> <?php echo e(settings('app_title')); ?></title>
    <!-- Favicon and Touch Icons -->
    <link rel="shortcut icon" href="<?php echo e(landingPageImage('favicon','images/fav.png')); ?>/">
</head>

<body class="body-bg">

    <?php echo $__env->yieldContent('content'); ?>

<!-- js file start -->

<!-- JavaScript -->
<script src="<?php echo e(asset('assets/admin/js/jquery.min.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="<?php echo e(asset('assets/admin/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/metisMenu.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/toast/vanillatoasts.js')); ?>"></script>

<script src="<?php echo e(asset('assets/admin/js/main.js')); ?>"></script>


    <?php if(session()->has('success')): ?>
        <script>
            window.onload = function () {
                VanillaToasts.create({
                    //  title: 'Message Title',
                    text: '<?php echo e(session('success')); ?>',
                    backgroundColor: "linear-gradient(135deg, #73a5ff, #5477f5)",
                    type: 'success',
                    timeout: 10000
                });
            }

        </script>

    <?php elseif(session()->has('dismiss')): ?>
        <script>
            window.onload = function () {

                VanillaToasts.create({
                    // title: 'Message Title',
                    text: '<?php echo e(session('dismiss')); ?>',
                    type: 'warning',
                    timeout: 10000

                });
            }
        </script>

    <?php elseif($errors->any()): ?>
        <?php $__currentLoopData = $errors->getMessages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <script>
                window.onload = function () {
                    VanillaToasts.create({
                        // title: 'Message Title',
                        text: '<?php echo e($error[0]); ?>',
                        type: 'warning',
                        timeout: 10000

                    });
                }
            </script>

            <?php break; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php endif; ?>
<?php echo $__env->yieldContent('script'); ?>
<!-- End js file -->

</body>
</html>

<?php /**PATH /var/www/html/cpoket-web/resources/views/auth/master.blade.php ENDPATH**/ ?>