<!DOCTYPE HTML>
<html class="no-js" lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="The Highly Secured Bitcoin Wallet">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta property="og:type" content="article" />
    <meta property="og:title" content="<?php echo e(allsetting('app_title')); ?>"/>
    <meta property="og:image" content="<?php echo e(asset('assets/admin/images/logo.svg')); ?>">
    <meta property="og:site_name" content="Cpoket"/>
    <meta property="og:url" content="<?php echo e(url()->current()); ?>"/>



    <meta itemprop="image" content="<?php echo e(asset('assets/admin/images/logo.svg')); ?>" />
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/bootstrap.min.css')); ?>">
    <!-- metismenu CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/metisMenu.min.css')); ?>">
    <!-- fontawesome CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/font-awesome.min.css')); ?>">
    
    <link href="<?php echo e(asset('assets/toast/vanillatoasts.css')); ?>" rel="stylesheet" >
    <!-- Datatable CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/user/css/datatable/datatables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/user/css/datatable/dataTables.bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/user/css/datatable/dataTables.jqueryui.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/user/css/datatable/dataTables.responsive.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/user/css/datatable/jquery.dataTables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/css-circular-prog-bar.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/datepicker/css/bootstrap-datepicker.min.css')); ?>">

    
    <link rel="stylesheet" href="<?php echo e(asset('assets/dropify/dropify.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('assets/summernote/summernote.min.css')); ?>">
    <!-- Style CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/style.css')); ?>">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/responsive.css')); ?>">
    <?php echo $__env->yieldContent('style'); ?>
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!-- Favicon and Touch Icons -->
    <link rel="shortcut icon" href="<?php echo e(landingPageImage('favicon','images/fav.png')); ?>/">
</head>

<body class="body-bg">
<!-- Start sidebar -->
<div class="sidebar">
    <!-- logo -->
    <div class="logo">
        <a href="<?php echo e(route('adminDashboard')); ?>">
            <img src="<?php echo e(show_image(Auth::user()->id,'logo')); ?>" class="img-fluid" alt="">
        </a>
    </div><!-- /logo -->

    <!-- sidebar menu -->
    <div class="sidebar-menu">
        <nav>
            <ul id="metismenu">
                <li class="<?php if(isset($menu) && $menu == 'dashboard'): ?> active-page <?php endif; ?>">
                    <a href="<?php echo e(route('adminDashboard')); ?>">
                        <span class="icon"><img src="<?php echo e(asset('assets/admin/images/sidebar-icons/dashboard.svg')); ?>" class="img-fluid" alt=""></span>
                        <span class="name"><?php echo e(__('Dashboard')); ?></span>
                    </a>
                </li>
                <li class="<?php if(isset($menu) && $menu == 'users'): ?> active-page <?php endif; ?>">
                    <a href="#" aria-expanded="true">
                        <span class="icon"><img src="<?php echo e(asset('assets/admin/images/sidebar-icons/user.svg')); ?>" class="img-fluid" alt=""></span>
                        <span class="name"><?php echo e(__('User Management')); ?></span>
                    </a>
                    <ul class="<?php if(isset($menu) && $menu == 'users'): ?>  mm-show  <?php endif; ?>">
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'user'): ?> submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('adminUsers')); ?>"><?php echo e(__('User')); ?></a>
                        </li>
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'pending_id'): ?> submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('adminUserIdVerificationPending')); ?>"><?php echo e(__('Pending ID Verification')); ?></a>
                        </li>
                    </ul>
                </li>
                <li class="<?php if(isset($menu) && $menu == 'coin'): ?> active-page <?php endif; ?>">
                    <a href="<?php echo e(route('adminCoinList')); ?>">
                        <span class="icon"><img src="<?php echo e(asset('assets/admin/images/sidebar-icons/coin.svg')); ?>" class="img-fluid" alt=""></span>
                        <span class="name"><?php echo e(__('Coin ')); ?></span>
                    </a>
                </li>
                <li class="<?php if(isset($menu) && $menu == 'pocket'): ?> active-page <?php endif; ?>">
                    <a href="#" aria-expanded="true">
                        <span class="icon"><img src="<?php echo e(asset('assets/admin/images/sidebar-icons/wallet.svg')); ?>" class="img-fluid" alt=""></span>
                        <span class="name"><?php echo e(__('Pocket')); ?></span>
                    </a>
                    <ul class="<?php if(isset($menu) && $menu == 'pocket'): ?>  mm-show  <?php endif; ?>">
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'personal'): ?> submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('adminWalletList')); ?>"><?php echo e(__('Personal Pockets')); ?></a>
                        </li>
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'co'): ?> submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('adminCoWallets')); ?>"><?php echo e(__(' Multi-signature Pockets')); ?></a>
                        </li>
                    </ul>
                </li>
                <li class="<?php if(isset($menu) && $menu == 'transaction'): ?> active-page <?php endif; ?>">
                    <a href="#" aria-expanded="true">
                        <span class="icon"><img src="<?php echo e(asset('assets/admin/images/sidebar-icons/Transaction-1.svg')); ?>" class="img-fluid" alt=""></span>
                        <span class="name"><?php echo e(__('Transaction History')); ?></span>
                    </a>
                    <ul class="<?php if(isset($menu) && $menu == 'transaction'): ?>  mm-show  <?php endif; ?>">
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'transaction_all'): ?> submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('adminTransactionHistory')); ?>"><?php echo e(__('All Transaction')); ?></a>
                        </li>
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'transaction_withdrawal'): ?> submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('adminPendingWithdrawal')); ?>"><?php echo e(__('Pending Withdrawal')); ?></a>
                        </li>
                    </ul>
                </li>
                <li class="<?php if(isset($menu) && $menu == 'phase'): ?> active-page <?php endif; ?>">
                    <a href="#" aria-expanded="true">
                        <span class="icon"><img src="<?php echo e(asset('assets/admin/images/sidebar-icons/phase.svg')); ?>" class="img-fluid" alt=""></span>
                        <span class="name"><?php echo e(__('Ico Phase')); ?></span>
                    </a>
                    <ul class="<?php if(isset($menu) && $menu == 'phase'): ?>  mm-show  <?php endif; ?>">
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'phase_list'): ?> submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('adminPhaseList')); ?>"><?php echo e(__('Ico Phase List')); ?></a>
                        </li>
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'phase_add'): ?> submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('adminPhaseAdd')); ?>"><?php echo e(__('Create Phase')); ?></a>
                        </li>
                    </ul>
                </li>
                <li class="<?php if(isset($menu) && $menu == 'buy_coin'): ?> active-page <?php endif; ?>">
                    <a href="#" aria-expanded="true">
                        <span class="icon"><img src="<?php echo e(asset('assets/admin/images/sidebar-icons/coin-order-list.svg')); ?>" class="img-fluid" alt=""></span>
                        <span class="name"><?php echo e(__('Buy Coin')); ?></span>
                    </a>
                    <ul class="<?php if(isset($menu) && $menu == 'buy_coin'): ?>  mm-show  <?php endif; ?>">
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'buy_coin'): ?> submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('adminPendingCoinOrder')); ?>"><?php echo e(__('Buy coin order list')); ?></a>
                        </li>
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'give_coin'): ?> submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('adminGiveCoinToUser')); ?>"><?php echo e(__('Give Coin')); ?></a>
                        </li>
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'give_coin_history'): ?> submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('adminGiveCoinHistory')); ?>"><?php echo e(__('Give Coin History')); ?></a>
                        </li>
                    </ul>
                </li>

                <li class="<?php if(isset($menu) && $menu == 'profile'): ?> active-page <?php endif; ?>">
                    <a href="<?php echo e(route('adminProfile')); ?>">
                        <span class="icon"><img src="<?php echo e(asset('assets/admin/images/sidebar-icons/profile.svg')); ?>" class="img-fluid" alt=""></span>
                        <span class="name"><?php echo e(__('Profile')); ?></span>
                    </a>
                </li>
                <li class="<?php if(isset($menu) && $menu == 'club'): ?> active-page <?php endif; ?>">
                    <a href="#" aria-expanded="true">
                        <span class="icon"><img src="<?php echo e(asset('assets/admin/images/sidebar-icons/Membership.svg')); ?>" class="img-fluid" alt=""></span>
                        <span class="name"><?php echo e(__('Membership Club')); ?></span>
                    </a>
                    <ul class="<?php if(isset($menu) && $menu == 'club'): ?>  mm-show  <?php endif; ?>">
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'member_list'): ?> submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('membershipList')); ?>"><?php echo e(__('Member List')); ?></a>
                        </li>
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'plan_list'): ?> submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('planList')); ?>"><?php echo e(__('Plan List')); ?></a>
                        </li>
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'transaction_history'): ?> submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('coinTransactionHistory')); ?>"><?php echo e(__('Transaction History')); ?></a>
                        </li>
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'bonus'): ?> submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('clubBonusDistribution')); ?>"><?php echo e(__('Bonus Distribution')); ?></a>
                        </li>
                    </ul>
                </li>
                <li class="<?php if(isset($menu) && $menu == 'setting'): ?> active-page <?php endif; ?>">
                    <a href="#" aria-expanded="true">
                        <span class="icon"><img src="<?php echo e(asset('assets/admin/images/sidebar-icons/settings.svg')); ?>" class="img-fluid" alt=""></span>
                        <span class="name"><?php echo e(__('Settings')); ?></span>
                    </a>
                    <ul class="<?php if(isset($menu) && $menu == 'setting'): ?>  mm-show  <?php endif; ?>">
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'general'): ?> submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('adminSettings')); ?>"><?php echo e(__('General Settings')); ?></a>
                        </li>
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'feature'): ?> submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('adminFeatureSettings')); ?>"><?php echo e(__('Feature Settings')); ?></a>
                        </li>
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'payment-method'): ?> submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('adminPaymentSetting')); ?>"><?php echo e(__('Payment Method')); ?></a>
                        </li>
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'bank'): ?> submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('bankList')); ?>"><?php echo e(__('Bank Management')); ?></a>
                        </li>
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'custom_pages'): ?> submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('adminCustomPageList')); ?>"><?php echo e(__('Custom Pages')); ?></a>
                        </li>
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'landing'): ?> submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('adminLandingSetting')); ?>"><?php echo e(__('Landing Settings')); ?></a>
                        </li>
                    </ul>
                </li>
                <li class="<?php if(isset($menu) && $menu == 'notification'): ?> active-page <?php endif; ?>">
                    <a href="#" aria-expanded="true">
                        <span class="icon"><img src="<?php echo e(asset('assets/admin/images/sidebar-icons/Notification.svg')); ?>" class="img-fluid" alt=""></span>
                        <span class="name"><?php echo e(__('Notification')); ?></span>
                    </a>
                    <ul class="<?php if(isset($menu) && $menu == 'notification'): ?>  mm-show  <?php endif; ?>">
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'notify'): ?> submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('sendNotification')); ?>"><?php echo e(__('Notification')); ?></a>
                        </li>
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'email'): ?> submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('sendEmail')); ?>"><?php echo e(__('Bulk Email')); ?></a>
                        </li>
                    </ul>
                </li>
                <li class="<?php if(isset($menu) && $menu == 'faq'): ?> active-page <?php endif; ?>">
                    <a href="<?php echo e(route('adminFaqList')); ?>">
                        <span class="icon"><img src="<?php echo e(asset('assets/admin/images/sidebar-icons/FAQ.svg')); ?>" class="img-fluid" alt=""></span>
                        <span class="name"><?php echo e(__('FAQs')); ?></span>
                    </a>
                </li>
            </ul>
        </nav>
    </div><!-- /sidebar menu -->

</div>
<!-- End sidebar -->
<!-- top bar -->
<div class="top-bar">
    <div class="container-fluid">
        <div class="row align-items-center justify-content-between">
            <div class="col-xl-1 col-md-2 col-3 top-bar-logo top-bar-logo-hide">
                <div class="logo">
                    <a href="<?php echo e(route('adminDashboard')); ?>"><img src="<?php echo e(show_image(Auth::user()->id,'logo')); ?>" class="img-fluid logo-large" alt=""></a>
                    <a href="<?php echo e(route('adminDashboard')); ?>"><img src="<?php echo e(show_image(Auth::user()->id,'logo')); ?>" class="img-fluid logo-small" alt=""></a>
                </div>
            </div>
            <div class="col-xl-1 col-md-2 col-3">
                <div class="menu-bars">
                    <img src="<?php echo e(asset('assets/admin/images/sidebar-icons/menu.svg')); ?>" class="img-fluid" alt="">
                </div>
            </div>
            <div class="col-xl-10 col-md-8 col-6">
                <div class="top-bar-right">
                    <ul>
                        <li>














                            <div class="btn-group profile-dropdown">
                                <button type="button" class="btn dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <span class="cp-user-avater">
                                        <span class="cp-user-img">
                                            <img src="<?php echo e(show_image(Auth::user()->id,'user')); ?>" class="img-fluid" alt="">
                                        </span>
                                        <span class="name"><?php echo e(Auth::user()->first_name.' '.Auth::user()->last_name); ?></span>
                                    </span>
                                </button>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <span class="big-user-thumb">
                                        <img src="<?php echo e(show_image(Auth::user()->id,'user')); ?>" class="img-fluid" alt="">
                                    </span>
                                    <div class="user-name">
                                        <p><?php echo e(Auth::user()->first_name.' '.Auth::user()->last_name); ?></p>
                                    </div>
                                    <button class="dropdown-item" type="button"><a href="<?php echo e(route('adminProfile')); ?>"><i class="fa fa-user-circle-o"></i> <?php echo e(__('Profile')); ?></a></button>
                                    <button class="dropdown-item" type="button"><a href="<?php echo e(route('logOut')); ?>"><i class="fa fa-sign-out"></i> <?php echo e(__('Logout')); ?></a></button>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /top bar -->

<!-- main wrapper -->
<div class="main-wrapper">
    <div class="container-fluid">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</div>
<!-- /main wrapper -->

<!-- js file start -->

<!-- JavaScript -->
<script src="<?php echo e(asset('assets/admin/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/metisMenu.min.js')); ?>"></script>






<script src="<?php echo e(asset('assets/admin/js/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/jquery.circlechart.js')); ?>"></script>


<script src="<?php echo e(asset('assets/toast/vanillatoasts.js')); ?>"></script>
<!-- Datatable -->
<script src="<?php echo e(asset('assets/user/js/datatable/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/user/js/datatable/dataTables.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/user/js/datatable/dataTables.jqueryui.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/user/js/datatable/dataTables.responsive.js')); ?>"></script>
<script src="<?php echo e(asset('assets/user/js/datatable/jquery.dataTables.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/admin/datepicker/js/bootstrap-datepicker.min.js')); ?>"></script>


<script src="<?php echo e(asset('assets/summernote/summernote.min.js')); ?>"></script>


<script src="<?php echo e(asset('assets/dropify/dropify.js')); ?>"></script>
<script src="<?php echo e(asset('assets/dropify/form-file-uploads.js')); ?>"></script>

<script src="<?php echo e(asset('assets/admin/js/main.js')); ?>"></script>


<?php if(session()->has('success')): ?>
    <script>
        window.onload = function () {
            VanillaToasts.create({
                //  title: 'Message Title',
                text: '<?php echo e(session('success')); ?>',
                backgroundColor: "linear-gradient(135deg, #73a5ff, #5477f5)",
                type: 'success',
                timeout: 10000
            });
        }

    </script>

<?php elseif(session()->has('dismiss')): ?>
    <script>
        window.onload = function () {

            VanillaToasts.create({
                // title: 'Message Title',
                text: '<?php echo e(session('dismiss')); ?>',
                type: 'warning',
                timeout: 10000

            });
        }
    </script>

<?php elseif($errors->any()): ?>
    <?php $__currentLoopData = $errors->getMessages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <script>
            window.onload = function () {
                VanillaToasts.create({
                    // title: 'Message Title2',
                    text: '<?php echo e($error[0]); ?>',
                    type: 'warning',
                    timeout: 10000

                });
            }
        </script>

        <?php break; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php endif; ?>
<script>
    /* Add here all your JS customizations */
    $('.number-only').keypress(function (e) {
        alert(11);
        var regex = /^[+0-9+.\b]+$/;
        var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
        if (regex.test(str)) {
            return true;
        }
        e.preventDefault();
        return false;
    });
    $('.no-regx').keypress(function (e) {
        var regex = /^[a-zA-Z+0-9+\b]+$/;
        var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
        if (regex.test(str)) {
            return true;
        }
        e.preventDefault();
        return false;
    });
</script>
<?php echo $__env->yieldContent('script'); ?>
<!-- End js file -->
</body>
</html>

<?php /**PATH /var/www/html/cpoket-web/resources/views/admin/master.blade.php ENDPATH**/ ?>