<?php $__env->startSection('title', isset($title) ? $title : ''); ?>
<?php $__env->startSection('style'); ?>
    <style type="text/css">
        .panel-title {
            display: inline;
            font-weight: bold;
        }
        .display-table {
            display: table;
        }
        .display-tr {
            display: table-row;
        }
        .display-td {
            display: table-cell;
            vertical-align: middle;
            width: 61%;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xl-6 mb-xl-0 mb-4">
            <div class="card cp-user-custom-card">
                <div class="card-body">
                    <div class="cp-user-card-header-area">
                        <h4><?php echo e(__('Buy Our Coin From Here')); ?></h4>
                    </div>
                    <div class="cp-user-buy-coin-content-area">
                        <?php if($no_phase): ?>
                            <p>
                                <span class="text-danger"><i class="fa fa-exclamation-triangle"></i> <?php echo e(__('No phase active yet')); ?></span>
                                <br>
                                <span><?php echo e(__('Now you can buy our regular coin')); ?></span>
                            </p>
                        <?php elseif($activePhase['futurePhase'] == true): ?>
                            <p>
                                <span class="text-warning"> <?php echo e(__('New Ico Phase will start soon')); ?></span> <br>
                                <span><?php echo e(__('Now you can buy our regular coin')); ?></span>
                            </p>
                        <?php else: ?>
                            <?php
                                $phase = $activePhase['pahse_info'];
                                $total_sell = \App\Model\BuyCoinHistory::where('status',STATUS_SUCCESS)->where('phase_id',$phase->id)->sum('coin');
                                $progress_bar = 0;

                                $target = $phase->amount;
                                $unsold = ($target >=  $total_sell ) ? bcsub($target,$total_sell) : 0;
                                if ($target != 0) {
                                  $sale = bcmul(100, $total_sell);
                                  $progress_bar = ceil(bcdiv($sale,$target));
                                }
                            ?>
                            <p>
                                <span class="text-success"><?php echo e(__('New Ico Phase are available now')); ?></span> <br>
                                <span
                                    class="text-warning"><?php echo e(__('Now you can get some extra facility  when buy coin')); ?></span>
                            </p>

                        <?php endif; ?>
                        <div class="cp-user-coin-info">
                            <form action="<?php echo e(route('buyCoinProcess')); ?>" method="POST" enctype="multipart/form-data"
                                  id="buy_coin">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <?php if(isset($phase)): ?>
                                        <input type="hidden" name="phase_id" value="<?php echo e($phase->id); ?>">
                                    <?php endif; ?>
                                    <label><?php echo e(__('Coin Amount')); ?></label>
                                    <input
                                        oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"
                                        name="coin" autocomplete="off" id="amount" class="form-control"
                                        placeholder="<?php echo e(__('Your Amount')); ?>">
                                    <ul class="coin_price">
                                        <li><?php echo e($coin_price); ?> x <span class="coinAmount">1</span> = <span
                                                class="CoinInDoller"><?php echo e($coin_price); ?> </span> USD
                                        </li>
                                        <li>$<span class="CoinInDoller"><?php echo e($coin_price); ?> USD</span> = <span
                                                class="totalBTC"><?php echo e($btc_dlr); ?></span> <span class="coinType"> BTC</span>
                                        </li>
                                        <?php if(isset($phase)): ?>


                                            <li><span class=""><?php echo e(__('Bonus')); ?></span> = <span
                                                    class="coinBonus">0 </span> <?php echo e(settings('coin_name')); ?></li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                                <div class="cp-user-payment-type">
                                    <h3><?php echo e(__('Payment Type')); ?></h3>
                                    <?php if(isset($settings['payment_method_coin_payment']) && $settings['payment_method_coin_payment'] == 1): ?>
                                        <div class="form-group">
                                            <input type="radio" onclick="call_coin_payment();"
                                                   onchange="$('.payment_method').addClass('d-none');$('.bank-details').addClass('d-none');$('.bank-details').removeClass('d-block'); $('.payment-stripe').addClass('d-none').removeClass('d-block');$('.btc_payment').toggleClass('d-none');$('.normal-btn').addClass('d-block').removeClass('d-none')"
                                                   value="<?php echo e(BTC); ?>" id="coin-option" name="payment_type">
                                            <label for="coin-option"><?php echo e(__('Coin Payment')); ?></label>
                                        </div>
                                    <?php endif; ?>
                                    <?php if(isset($settings['payment_method_bank_deposit']) && $settings['payment_method_bank_deposit'] == 1): ?>
                                        <div class="form-group">
                                            <input type="radio" onclick="call_coin_payment();" value="<?php echo e(BANK_DEPOSIT); ?>"
                                                   onchange="$('.payment_method').addClass('d-none');$('.bank-details').addClass('d-block');$('.bank-details').removeClass('d-none');$('.payment-stripe').addClass('d-none').removeClass('d-block');$('.bank_payment').toggleClass('d-none');$('.normal-btn').addClass('d-block').removeClass('d-none')"
                                                   id="f-option" name="payment_type">
                                            <label for="f-option"><?php echo e(__('Bank Deposit')); ?></label>
                                        </div>
                                    <?php endif; ?>
                                    <?php if(isset($settings['payment_method_stripe']) && $settings['payment_method_stripe'] == 1): ?>
                                        <div class="form-group">
                                            <input type="radio" onclick="call_coin_payment();" value="<?php echo e(STRIPE); ?>"
                                                   onchange="$('.normal-btn').addClass('d-none');$('.payment_method').addClass('d-none');$('.bank-details').addClass('d-none');$('.payment-stripe').addClass('d-block');$('.payment-stripe').removeClass('d-none');$('.payment-stripe-div').toggleClass('d-none');"
                                                   id="stripe-option" name="payment_type">
                                            <label for="stripe-option"><?php echo e(__('Credit Card')); ?></label>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <div class="check-box-list btc_payment payment_method d-none">

                                    <div class="form-group buy_coin_address_input ">
                                        <p>
                                            <span id="coinpayment_address"></span>
                                        </p>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label for=""><?php echo e(__('Payable Coin')); ?></label>
                                                <input class="form-control" disabled type="text"
                                                       oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"
                                                       readonly name="total_price" id="total_price"
                                                       placeholder="Amount">
                                            </div>
                                            <div class="col-md-6">
                                                <label for=""><?php echo e(__('Select')); ?></label>
                                                <div class="cp-select-area">
                                                    <select name="payment_coin_type"
                                                            class="selet-im vodiapicker form-control "
                                                            id="payment_type">
                                                        <?php if(isset($coins[0])): ?>
                                                            <?php $__currentLoopData = $coins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option
                                                                    value="<?php echo e($key->type); ?>">
                                                                    <?php echo e($key->type); ?>

                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="check-box-list bank_payment payment_method d-none">
                                    <div class="form-group">
                                        <label><?php echo e(__('Select Bank')); ?></label>
                                        <div class="cp-select-area">
                                            <select name="bank_id" class="bank-id form-control ">
                                                <option value=""><?php echo e(__('Select')); ?></option>
                                                <?php if(isset($banks[0])): ?>
                                                    <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option
                                                            <?php if((old('bank_id') != null) && (old('bank_id') == $value->id)): ?> <?php endif; ?> value="<?php echo e($value->id); ?>"><?php echo e($value->bank_name); ?></option>
                                                        <span
                                                            class="text-danger"><strong><?php echo e($errors->first('bank_id')); ?></strong></span>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group buy_coin_address_input mt-4">
                                        <div id="file-upload" class="section-p">
                                            <input type="hidden" name="bank_deposit_id" value="">



                                        </div>
                                    </div>

                                </div>

                                <button id="buy_button" type="submit" class="btn normal-btn theme-btn"><?php echo e(__('Buy Now')); ?></button>
                            </form>

                            <div class="payment-stripe payment-stripe-div  d-none card card-body dark-bg2">
                                <form role="form" action="<?php echo e(route('buyCoinProcess')); ?>" method="post" class="require-validation"
                                      data-cc-on-file="false"
                                      data-stripe-publishable-key="<?php echo e(isset(settings()['STRIPE_KEY']) ? settings()['STRIPE_KEY'] : ''); ?>"
                                      id="payment-form">
                                    <?php echo csrf_field(); ?>
                                    <?php if(isset($phase)): ?>
                                        <input type="hidden" name="phase_id" value="<?php echo e($phase->id); ?>">
                                    <?php endif; ?>
                                    <input type="hidden" name="payment_type" value="<?php echo e(STRIPE); ?>">
                                    <input type="hidden" name="coin" value="" id="amountCoin" class="form-control" >
                                    <div class='form-row row'>
                                        <div class='col-12 form-group required'>
                                            <label class='control-label'><?php echo e(__('Name on Card')); ?></label>
                                            <input class='form-control' size="50" type='text'>
                                        </div>
                                    </div>

                                    <div class='form-row row'>
                                        <div class='col-12 form-group required'>
                                            <label class='control-label'><?php echo e(__('Card Number')); ?></label>
                                            <input autocomplete='off' size="50" class='form-control card-number' type='text'>
                                        </div>
                                    </div>

                                    <div class='form-row row'>
                                        <div class='col-xs-12 col-md-4 form-group cvc required'>
                                            <label class='control-label'><?php echo e(__('CVC')); ?></label>
                                            <input autocomplete='off' class='form-control card-cvc' placeholder='ex. 311' size='4' type='text'>
                                        </div>
                                        <div class='col-xs-12 col-md-4 form-group expiration required'>
                                            <label class='control-label'><?php echo e(__('Expiration Month')); ?></label>
                                            <input class='form-control card-expiry-month' placeholder='MM' size='2' type='text'>
                                        </div>
                                        <div class='col-xs-12 col-md-4 form-group expiration required'>
                                            <label class='control-label'><?php echo e(__('Expiration Year')); ?></label>
                                            <input class='form-control card-expiry-year' placeholder='YYYY' size='4' type='text'>
                                        </div>
                                    </div>

                                    <div class='form-row row'>
                                        <div class='col-md-12 error form-group hide'>
                                            <div class='alert-danger card-alert'></div>
                                        </div>
                                    </div>

                                    <div class="form-row row">
                                        <div class="col-xs-12">
                                            <button id="buy_button" type="submit" class="btn theme-btn"><?php echo e(__('Buy Now')); ?></button>
                                        </div>
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-6">
            <div class="card cp-user-custom-card ico-phase-info-list">
                <div class="card-body">
                    <?php if($no_phase): ?>
                        <div class="cp-user-card-header-area">
                            <h4><?php echo e(__("Today’s Coin Rate")); ?></h4>
                        </div>
                    <?php elseif($activePhase['futurePhase'] == true): ?>
                        <div class="cp-user-card-header-area future-ico-phase">
                            <h4 class="mb-3"><?php echo e(__("New Ico Phase will start soon")); ?></h4>
                            <p>Start at  : <?php echo e(date('d M y', strtotime($activePhase['futureDate']))); ?></p>
                        </div>
                    <?php else: ?>
                        <div class="cp-user-card-header-area">
                            <h4><?php echo e(__("New Ico Phase is running")); ?></h4>
                        </div>
                    <?php endif; ?>
                    <div class="cp-user-coin-rate">
                        <?php if($no_phase): ?>
                            <ul class="">
                                <li>1 <?php echo e(settings('coin_name')); ?></li>
                                <li>=</li>
                                <li><?php echo e(number_format($coin_price,2)); ?> USD</li>
                            </ul>

                            <div class="img" id="r-side-img">
                                <img src="<?php echo e(asset('assets/user/images/buy-coin-vector.svg')); ?>" class="img-fluid"
                                     alt="">
                            </div>
                        <?php elseif($activePhase['futurePhase'] == true): ?>
                            <div id="futurePhase" class="countdown-row">
                                <div class="countdown-section">
                                    <span class="days"></span>
                                    <div class="smalltext"><?php echo e(__('Days')); ?></div>
                                </div>
                                <div class="countdown-section">
                                    <span class="hours"></span>
                                    <div class="smalltext"><?php echo e(__('Hours')); ?></div>
                                </div>
                                <div class="countdown-section">
                                    <span class="minutes"></span>
                                    <div class="smalltext"><?php echo e(__('Minutes')); ?></div>
                                </div>
                                <div class="countdown-section">
                                    <span class="seconds"></span>
                                    <div class="smalltext"><?php echo e(__('Seconds')); ?></div>
                                </div>
                            </div>

                            <ul class="">
                                <li>1 <?php echo e(settings('coin_name')); ?></li>
                                <li>=</li>
                                <li><?php echo e(number_format($coin_price,2)); ?> USD</li>
                            </ul>
                            <div class="img" id="r-side-img">
                                <img src="<?php echo e(asset('assets/user/images/buy-coin-vector.svg')); ?>" class="img-fluid"
                                     alt="">
                            </div>
                        <?php else: ?>

                            <ul class="ico-phase-ul">
                                <li><p><?php echo e($phase->phase_name); ?></p></li>
                                <li>
                                    <p><?php echo e(__('Phase Rate')); ?> :</p>
                                    <p>1 <?php echo e(settings('coin_name')); ?> = <?php echo e(number_format($phase->rate,2)); ?> USD</p>
                                </li>


                                <li><p><?php echo e(__('Bonus Percentage')); ?> :</p>
                                    <p><?php echo e(number_format($phase->bonus,2)); ?>%</p></li>
                                <li><p><?php echo e(__('Start at')); ?> :</p>
                                    <p><?php echo e(date('d M y', strtotime($phase->start_date))); ?></p></li>
                                <li><p><?php echo e(__('End at')); ?> : </p>
                                    <p><?php echo e(date('d M y', strtotime($phase->end_date))); ?></p></li>
                            </ul>
                            <hr>
                            <h5 class="ico-phase-amount-title"><?php echo e(settings('coin_name')); ?> <?php echo e(__(' Sales Progress')); ?></h5>
                            <ul class="ico-phase-ul ico-phase-amount">
                                <li class="total_sale">
                                    <span><?php echo e(__('RAISED AMOUNT')); ?></span>
                                    <span><?php echo e(number_format($total_sell,2)); ?> <?php echo e(settings('coin_name')); ?></span>
                                </li>
                                <li class="total_target">
                                    <span><?php echo e(__('TARGET AMOUNT')); ?></span>
                                    <?php echo e(number_format($target,2)); ?> <?php echo e(settings('coin_name')); ?>

                                </li>
                            </ul>
                            <div class="ico-phase-progress-bar">
                                <div class="progress" data-toggle="tooltip" data-placement="top"
                                     title="<?php echo e(__('Raised Amount')); ?> (<?php echo e(number_format($progress_bar,2)); ?> %)">
                                    <div class="progress-bar" role="progressbar" style="width: <?php echo e($progress_bar); ?>%;"
                                         aria-valuenow="<?php echo e($progress_bar); ?>" aria-valuemin="0"
                                         aria-valuemax="100"><?php echo e($progress_bar); ?>%
                                    </div>
                                </div>
                                
                            </div>
                            <p class="card-text card-text-2 mb-2">
                                <span><?php echo e(__("SALES END IN")); ?></span>
                                <span><?php echo e(date('d M y', strtotime($phase->end_date))); ?></span>
                            </p>
                            <div id="clockdiv" class="countdown-row">
                                <div class="countdown-section">
                                    <span class="days"></span>
                                    <div class="smalltext"><?php echo e(__('Days')); ?></div>
                                </div>
                                <div class="countdown-section">
                                    <span class="hours"></span>
                                    <div class="smalltext"><?php echo e(__('Hours')); ?></div>
                                </div>
                                <div class="countdown-section">
                                    <span class="minutes"></span>
                                    <div class="smalltext"><?php echo e(__('Minutes')); ?></div>
                                </div>
                                <div class="countdown-section">
                                    <span class="seconds"></span>
                                    <div class="smalltext"><?php echo e(__('Seconds')); ?></div>
                                </div>
                            </div>

                        <?php endif; ?>
                        <div class="bank-details">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript" src="https://js.stripe.com/v2/"></script>

    <script type="text/javascript">
        $(function() {
            var $form         = $(".require-validation");
            $('form.require-validation').bind('submit', function(e) {
                var $form         = $(".require-validation"),
                    inputSelector = ['input[type=email]', 'input[type=password]',
                        'input[type=text]', 'input[type=file]',
                        'textarea'].join(', '),
                    $inputs       = $form.find('.required').find(inputSelector),
                    $errorMessage = $form.find('div.error'),
                    valid         = true;
                $errorMessage.addClass('hide');

                $('.has-error').removeClass('has-error');
                $inputs.each(function(i, el) {
                    var $input = $(el);
                    if ($input.val() === '') {
                        $input.parent().addClass('has-error');
                        $errorMessage.removeClass('hide');
                        e.preventDefault();
                    }
                });

                if (!$form.data('cc-on-file')) {
                    e.preventDefault();
                    Stripe.setPublishableKey($form.data('stripe-publishable-key'));
                    Stripe.createToken({
                        number: $('.card-number').val(),
                        cvc: $('.card-cvc').val(),
                        exp_month: $('.card-expiry-month').val(),
                        exp_year: $('.card-expiry-year').val()
                    }, stripeResponseHandler);
                }

            });

            function stripeResponseHandler(status, response) {
                console.log(response);
                if (response.error) {
                    $('.error')
                        .removeClass('hide')
                        .find('.card-alert')
                        .text(response.error.message);
                } else {
                    var amount = $('input[name=coin]').val();
                    $('#amountCoin').val(amount);
                    // token contains id, last4, and card type
                    $('.error')
                        .addClass('hide')
                        .find('.card-alert')
                    var token = response['id'];
                    // insert the token into the form so it gets submitted to the server
                    $form.find('input[type=text]').empty();
                    $form.append("<input type='hidden' name='stripeToken' value='" + token + "'/>");
                    $form.get(0).submit();
                }
            }

        });
    </script>
    <script>
        $('[data-toggle="tooltip"]').tooltip()
        //bank details

        $('.bank-id').change(function () {
            var id = $(this).val();
            $.ajax({
                url: "<?php echo e(route('bankDetails')); ?>?val=" + id,
                type: "get",
                success: function (data) {
                    // console.log(data);
                    $('div.bank-details').html(data.data_genetare);
                    $('#r-side-img').hide();
                },
                error: function (jqXHR, textStatus, errorThrown) {

                }
            });
        });
    </script>

    <script>
        //change payment type

        $('#payment_type').change(function () {
            var id = $(this).val();
            var amount = $('input[name=coin]').val();
            var pay_type = document.querySelector('input[name="payment_type"]:checked').value;
            var payment_type = $('#payment_type').val();
            call_coin_rate(amount, pay_type, payment_type);

        });
    </script>

    <script>
        function call_coin_rate(amount, pay_type, payment_type) {
            // console.log(amount,pay_type,payment_type);
            $.ajax({
                type: "POST",
                url: "<?php echo e(route('buyCoinRate')); ?>",
                data: {
                    '_token': "<?php echo e(csrf_token()); ?>",
                    'amount': amount,
                    'payment_type': payment_type,
                    'pay_type': pay_type,
                },
                dataType: 'JSON',

                success: function (data) {
                    // console.log(data);
                    $('.coinAmount').text(data.amount);
                    $('.CoinInDoller').text(data.coin_price);
                    $('.totalBTC').text(data.btc_dlr);
                    $('#total_price').val(data.btc_dlr);
                    $('.coinType').text(data.coin_type);
                    if(data.no_phase == false) {
                      //  $('.coinFees').text(data.phase_fees);
                        $('.coinBonus').text(data.bonus);
                    }
                },
                error: function () {
                    $('.btc-price').addClass('d-none');
                    $('.private-sell-submit').attr('disabled', false);
                }
            });
        }
    </script>

    <script>
        function delay(callback, ms) {
            var timer = 0;
            return function () {
                var context = this, args = arguments;
                clearTimeout(timer);
                timer = setTimeout(function () {
                    callback.apply(context, args);
                }, ms || 0);
            };
        }

        function call_coin_payment() {
            var amount = $('input[name=coin]').val();
            var pay_type = document.querySelector('input[name="payment_type"]:checked').value;
            var payment_type = $('#payment_type').val();
            call_coin_rate(amount, pay_type, payment_type);
        }

        $("#amount").keyup(delay(function (e) {
            var amount = $('input[name=coin]').val();
            // if(document.querySelector('input[name="payment_type"]:checked') == null) {
            //     var pay_type = 4;
            // } else {
              //  var pay_type = document.querySelector('input[name="payment_type"]:checked').value;
            // }
           if (document.getElementById('payment_type').checked){
               var payment_type = $('#payment_type').val();
               call_coin_rate(amount, pay_type, payment_type);
           }


        }, 500));


    </script>

    <script>
        <?php if(isset($phase)): ?>
        function getTimeRemaining(endtime) {
            const total = Date.parse(endtime) - Date.parse(new Date());
            const seconds = Math.floor((total / 1000) % 60);
            const minutes = Math.floor((total / 1000 / 60) % 60);
            const hours = Math.floor((total / (1000 * 60 * 60)) % 24);
            const days = Math.floor(total / (1000 * 60 * 60 * 24));

            return {
                total,
                days,
                hours,
                minutes,
                seconds
            };
        }

        function initializeClock(id, endtime) {
            const clock = document.getElementById(id);
            const daysSpan = clock.querySelector('.days');
            const hoursSpan = clock.querySelector('.hours');
            const minutesSpan = clock.querySelector('.minutes');
            const secondsSpan = clock.querySelector('.seconds');

            function updateClock() {
                const t = getTimeRemaining(endtime);

                daysSpan.innerHTML = t.days;
                hoursSpan.innerHTML = ('0' + t.hours).slice(-2);
                minutesSpan.innerHTML = ('0' + t.minutes).slice(-2);
                secondsSpan.innerHTML = ('0' + t.seconds).slice(-2);

                if (t.total <= 0) {
                    clearInterval(timeinterval);
                }
            }

            updateClock();
            const timeinterval = setInterval(updateClock, 1000);
        }

        // const deadline = new Date(Date.parse(new Date()) + 15 * 24 * 60 * 60 * 1000);
        initializeClock('clockdiv', '<?php echo e($phase->end_date); ?>');
        <?php endif; ?>
        <?php if(isset($activePhase['futurePhase']) &&  ($activePhase['futurePhase']== true)): ?>
        function getTimeRemaining(endtime) {
            const total = Date.parse(endtime) - Date.parse(new Date());
            const seconds = Math.floor((total / 1000) % 60);
            const minutes = Math.floor((total / 1000 / 60) % 60);
            const hours = Math.floor((total / (1000 * 60 * 60)) % 24);
            const days = Math.floor(total / (1000 * 60 * 60 * 24));

            return {
                total,
                days,
                hours,
                minutes,
                seconds
            };
        }

        function initializeClock(id, endtime) {
            const clock = document.getElementById(id);
            const daysSpan = clock.querySelector('.days');
            const hoursSpan = clock.querySelector('.hours');
            const minutesSpan = clock.querySelector('.minutes');
            const secondsSpan = clock.querySelector('.seconds');

            function updateClock() {
                const t = getTimeRemaining(endtime);

                daysSpan.innerHTML = t.days;
                hoursSpan.innerHTML = ('0' + t.hours).slice(-2);
                minutesSpan.innerHTML = ('0' + t.minutes).slice(-2);
                secondsSpan.innerHTML = ('0' + t.seconds).slice(-2);

                if (t.total <= 0) {
                    clearInterval(timeinterval);
                }
            }

            updateClock();
            const timeinterval = setInterval(updateClock, 1000);
        }

        // const deadline = new Date(Date.parse(new Date()) + 15 * 24 * 60 * 60 * 1000);
        initializeClock('futurePhase', '<?php echo e($activePhase['futureDate']); ?>');
        <?php endif; ?>
    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.master',['menu'=>'coin', 'sub_menu'=>'buy_coin'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/cpoket-web/resources/views/user/buy_coin/index.blade.php ENDPATH**/ ?>