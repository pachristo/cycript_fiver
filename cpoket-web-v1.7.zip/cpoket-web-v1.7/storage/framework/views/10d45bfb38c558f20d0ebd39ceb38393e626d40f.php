<?php $__env->startSection('title', isset($title) ? $title : ''); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- breadcrumb -->
    <div class="custom-breadcrumb">
        <div class="row">
            <div class="col-12">
                <ul>
                    <li><?php echo e(__('Settings')); ?></li>
                    <li class="active-item"><?php echo e($title); ?></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- /breadcrumb -->

    <!-- User Management -->
    <div class="user-management">
        <div class="row">
            <div class="col-12">
                <ul class="nav user-management-nav mb-3" id="pills-tab" role="tablist">
                    <li class="nav-item">
                        <a class="<?php if(isset($tab) && $tab=='general'): ?> active <?php endif; ?> nav-link " id="pills-user-tab"
                           data-toggle="pill" data-controls="general" href="#general" role="tab"
                           aria-controls="pills-user" aria-selected="true">
                            <span><?php echo e(__('General Settings')); ?></span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="<?php if(isset($tab) && $tab=='email'): ?> active <?php endif; ?> nav-link " id="pills-add-user-tab"
                           data-toggle="pill" data-controls="email" href="#email" role="tab"
                           aria-controls="pills-add-user" aria-selected="true">
                            <span><?php echo e(__('Email Settings')); ?> </span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="<?php if(isset($tab) && $tab=='sms'): ?> active <?php endif; ?> nav-link " id="pills-sms-tab"
                           data-toggle="pill" data-controls="sms" href="#sms" role="tab" aria-controls="pills-sms"
                           aria-selected="true">
                            <span><?php echo e(__('Twillo Settings')); ?> </span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="<?php if(isset($tab) && $tab=='withdraw'): ?> active <?php endif; ?> nav-link "
                           id="pills-deleted-user-tab" data-toggle="pill" data-controls="withdraw" href="#withdraw"
                           role="tab" aria-controls="pills-deleted-user" aria-selected="true">
                            <span><?php echo e(__('Withdrawal Settings')); ?></span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="<?php if(isset($tab) && $tab=='referral'): ?> active <?php endif; ?> nav-link "
                           id="pills-suspended-user-tab" data-toggle="pill" data-controls="referral" href="#referral"
                           role="tab" aria-controls="pills-suspended-user" aria-selected="true">
                            <span><?php echo e(__('Referral Settings')); ?></span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="<?php if(isset($tab) && $tab=='payment'): ?> active <?php endif; ?> nav-link " id="pills-email-tab"
                           data-toggle="pill" data-controls="payment" href="#payment" role="tab"
                           aria-controls="pills-email" aria-selected="true">
                            <span><?php echo e(__('Payment Settings')); ?></span>
                        </a>
                    </li>
                </ul>
                <div class="tab-content" id="pills-tabContent">
                    <div class="tab-pane show <?php if(isset($tab) && $tab=='general'): ?>  active <?php endif; ?>" id="general"
                         role="tabpanel" aria-labelledby="pills-user-tab">
                        <div class="header-bar">
                            <div class="table-title">
                                <h3><?php echo e(__('General Settings')); ?></h3>
                            </div>
                        </div>
                        <div class="profile-info-form">
                            <form action="<?php echo e(route('adminCommonSettings')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-lg-6 col-12 mt-20">
                                        <div class="form-group">
                                            <label><?php echo e(__('Language')); ?></label>
                                            <div class="cp-select-area">
                                                <select name="lang" class="form-control">
                                                    <?php $__currentLoopData = language(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option
                                                            <?php if(isset($settings['lang']) && $settings['lang']==$val): ?> selected
                                                            <?php endif; ?> value="<?php echo e($val); ?>"><?php echo e(langName($val)); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-12  mt-20">
                                        <div class="form-group">
                                            <label for="#"><?php echo e(__('Coin Name')); ?></label>
                                            <input class="form-control" type="text" name="coin_name"
                                                   placeholder="<?php echo e(__('Coin Name')); ?>" value="<?php echo e($settings['coin_name']); ?>">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-12  mt-20">
                                        <div class="form-group">
                                            <label for="#"><?php echo e(__('Company Name')); ?></label>
                                            <input class="form-control" type="text" name="company_name"
                                                   placeholder="<?php echo e(__('Company Name')); ?>"
                                                   value="<?php echo e($settings['app_title']); ?>">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-12  mt-20">
                                        <div class="form-group">
                                            <label for="#"><?php echo e(__('Coin Price (in USD)')); ?></label>
                                            <input class="form-control number_only" type="text" name="coin_price"
                                                   placeholder="<?php echo e(__('coin price')); ?>"
                                                   value="<?php echo e(isset($settings['coin_price']) ? $settings['coin_price'] : ''); ?>">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-12  mt-20">
                                        <div class="form-group">
                                            <label for="#"><?php echo e(__('Company USD Account no.')); ?></label>
                                            <input class="form-control" type="text" name="admin_usdt_account_no"
                                                   placeholder="<?php echo e(__('Company usd account mo.')); ?>"
                                                   value="<?php echo e(isset($settings['admin_usdt_account_no']) ? $settings['admin_usdt_account_no'] : ''); ?>">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-12  mt-20">
                                        <div class="form-group">
                                            <label for="#"><?php echo e(__('Coin Payment Base Coin Type')); ?></label>
                                            <input class="form-control" type="text" name="base_coin_type"
                                                   placeholder="<?php echo e(__('Coin Type eg. BTC')); ?>"
                                                   value="<?php echo e(isset($settings['base_coin_type']) ? $settings['base_coin_type'] : ''); ?>">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-12  mt-20">
                                        <div class="form-group">
                                            <label for="#"><?php echo e(__('Copyright Text')); ?></label>
                                            <input class="form-control" type="text" name="copyright_text"
                                                   placeholder="<?php echo e(__('Copyright Text')); ?>"
                                                   value="<?php echo e($settings['copyright_text']); ?>">
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-12 mt-20">
                                        <div class="form-group">
                                            <label
                                                for="#"><?php echo e(__('Number of confirmation for Notifier deposit')); ?> </label>
                                            <input class="form-control number_only" type="text"
                                                   name="number_of_confirmation" placeholder=""
                                                   value="<?php echo e($settings['number_of_confirmation']); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="uplode-img-list">
                                    <div class="row">
                                        <div class="col-lg-4 mt-20">
                                            <div class="single-uplode">
                                                <div class="uplode-catagory">
                                                    <span><?php echo e(__('Logo')); ?></span>
                                                </div>
                                                <div class="form-group buy_coin_address_input ">
                                                    <div id="file-upload" class="section-p">
                                                        <input type="file" placeholder="0.00" name="logo" value=""
                                                               id="file" ref="file" class="dropify"
                                                               <?php if(isset($settings['logo']) && (!empty($settings['logo']))): ?>  data-default-file="<?php echo e(asset(path_image().$settings['logo'])); ?>" <?php endif; ?> />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 mt-20">
                                            <div class="single-uplode">
                                                <div class="uplode-catagory">
                                                    <span><?php echo e(__('Login Logo')); ?></span>
                                                </div>
                                                <div class="form-group buy_coin_address_input ">
                                                    <div id="file-upload" class="section-p">
                                                        <input type="file" placeholder="0.00" name="login_logo" value=""
                                                               id="file" ref="file" class="dropify"
                                                               <?php if(isset($settings['login_logo']) && (!empty($settings['login_logo']))): ?>  data-default-file="<?php echo e(asset(path_image().$settings['login_logo'])); ?>" <?php endif; ?> />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 mt-20">
                                            <div class="single-uplode">
                                                <div class="uplode-catagory">
                                                    <span><?php echo e(__('Favicon')); ?></span>
                                                </div>
                                                <div class="form-group buy_coin_address_input ">
                                                    <div id="file-upload" class="section-p">
                                                        <input type="file" placeholder="0.00" name="favicon" value=""
                                                               id="file" ref="file" class="dropify"
                                                               <?php if(isset($settings['favicon']) && (!empty($settings['favicon']))): ?>  data-default-file="<?php echo e(asset(path_image().$settings['favicon'])); ?>" <?php endif; ?> />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <?php if(isset($itech)): ?>
                                        <input type="hidden" name="itech" value="<?php echo e($itech); ?>">
                                    <?php endif; ?>
                                    <div class="col-lg-2 col-12 mt-20">
                                        <button class="button-primary theme-btn"><?php echo e(__('Update')); ?></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="tab-pane <?php if(isset($tab) && $tab=='email'): ?> show active <?php endif; ?>" id="email"
                         role="tabpanel" aria-labelledby="pills-add-user-tab">
                        <div class="header-bar">
                            <div class="table-title">
                                <h3><?php echo e(__('Email Setup')); ?></h3>
                            </div>
                        </div>
                        <div class="profile-info-form">
                            <form action="<?php echo e(route('adminSaveEmailSettings')); ?>" method="post"
                                  enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-lg-6 col-12  mt-20">
                                        <div class="form-group">
                                            <label for="#"><?php echo e(__('Email Host')); ?></label>
                                            <input class="form-control" type="text" name="mail_host"
                                                   placeholder="<?php echo e(__('Host')); ?>" value="<?php echo e($settings['mail_host']); ?>">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-12  mt-20">
                                        <div class="form-group">
                                            <label for="#"><?php echo e(__('Email Port')); ?></label>
                                            <input class="form-control" type="text" name="mail_port"
                                                   placeholder="<?php echo e(__('Port')); ?>" value="<?php echo e($settings['mail_port']); ?>">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-12  mt-20">
                                        <div class="form-group">
                                            <label for="#"><?php echo e(__('Email Username')); ?></label>
                                            <input class="form-control" type="text" name="mail_username"
                                                   placeholder="<?php echo e(__('Username')); ?>"
                                                   value="<?php echo e(isset($settings['mail_username']) ? $settings['mail_username'] : ''); ?>">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-12  mt-20">
                                        <div class="form-group">
                                            <label for="#"><?php echo e(__('Email Password')); ?></label>
                                            <input class="form-control" type="password" name="mail_password"
                                                   placeholder="<?php echo e(__('Password')); ?>"
                                                   value="<?php echo e($settings['mail_password']); ?>">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-12  mt-20">
                                        <div class="form-group">
                                            <label for="#"><?php echo e(__('Mail Encryption')); ?></label>
                                            <input class="form-control" type="text" name="mail_encryption"
                                                   placeholder="<?php echo e(__('Encryption')); ?>"
                                                   value="<?php echo e(isset($settings['mail_encryption']) ? $settings['mail_encryption'] : ''); ?>">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-12  mt-20">
                                        <div class="form-group">
                                            <label for="#"><?php echo e(__('Mail Form Address')); ?></label>
                                            <input class="form-control" type="text" name="mail_from_address"
                                                   placeholder="<?php echo e(__('Mail from address')); ?>"
                                                   value="<?php echo e(isset($settings['mail_from_address']) ? $settings['mail_from_address'] : ''); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-2 col-12 mt-20">
                                        <button type="submit" class="button-primary theme-btn"><?php echo e(__('Update')); ?></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="tab-pane <?php if(isset($tab) && $tab=='sms'): ?> show active <?php endif; ?>" id="sms" role="tabpanel"
                         aria-labelledby="pills-sms-tab">
                        <div class="header-bar">
                            <div class="table-title">
                                <h3><?php echo e(__('Twillo Setup')); ?></h3>
                            </div>
                        </div>
                        <div class="profile-info-form">
                            <form action="<?php echo e(route('adminSaveSmsSettings')); ?>" method="post"
                                  enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-lg-6 col-12  mt-20">
                                        <div class="form-group">
                                            <label for="#"><?php echo e(__('Twillo Secret Key')); ?></label>
                                            <input class="form-control" type="text" name="twillo_secret_key"
                                                   placeholder="<?php echo e(__('Secret Key')); ?>"
                                                   value="<?php echo e($settings['twillo_secret_key']); ?>">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-12  mt-20">
                                        <div class="form-group">
                                            <label for="#"><?php echo e(__('Auth Token')); ?></label>
                                            <input class="form-control" type="text" name="twillo_auth_token"
                                                   placeholder="<?php echo e(__('Auth Token')); ?>"
                                                   value="<?php echo e($settings['twillo_auth_token']); ?>">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-12  mt-20">
                                        <div class="form-group">
                                            <label for="#"><?php echo e(__('Twillo Number')); ?></label>
                                            <input class="form-control" type="text" name="twillo_number"
                                                   placeholder="<?php echo e(__('Number')); ?>"
                                                   value="<?php echo e(isset($settings['twillo_number']) ? $settings['twillo_number'] : ''); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-2 col-12 mt-20">
                                        <button type="submit" class="button-primary theme-btn"><?php echo e(__('Update')); ?></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="tab-pane <?php if(isset($tab) && $tab=='referral'): ?> show active <?php endif; ?>" id="referral"
                         role="tabpanel" aria-labelledby="pills-suspended-user-tab">
                        <div class="header-bar">
                            <div class="table-title">
                                <h3><?php echo e(__('Referral Settings')); ?></h3>
                            </div>
                        </div>
                        <div class="profile-info-form">
                            <form method="post" action="<?php echo e(route('adminReferralFeesSettings')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-lg-12 col-12  mt-20">
                                        <div class="form-group">
                                            <label
                                                class=""><?php echo e(__('Maximum Affiliation Level : ')); ?> 3</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-12  mt-20">
                                        <div class="form-group">
                                            <label class=""><?php echo e(__('Referral reward for signup')); ?></label>
                                            <input type="text" class="form-control number_only"
                                                   name="referral_signup_reward" min="0"
                                                   value="<?php echo e(old('referral_signup_reward', isset($settings['referral_signup_reward']) ? $settings['referral_signup_reward'] : 100)); ?>">
                                        </div>
                                    </div>
                                    <?php for($i = 1; $i <=3 ; $i ++): ?>
                                        <div class="col-lg-6 col-12  mt-20">
                                            <div class="form-group">
                                                <label for="#"><?php echo e(__('Level')); ?> <?php echo e($i); ?> (%)</label>
                                                <?php ( $slug_name = 'fees_level'.$i); ?>
                                                <p class="fees-wrap">
                                                    <input type="text" class="number_only form-control"
                                                           name="<?php echo e($slug_name); ?>"
                                                           value="<?php echo e(old($slug_name, isset($settings[$slug_name]) ? $settings[$slug_name] : 0)); ?>">
                                                    <span>%</span>
                                                </p>
                                            </div>
                                        </div>
                                    <?php endfor; ?>
                                </div>
                                <div class="row">
                                    <div class="col-lg-2 col-12 mt-20">
                                        <button class="button-primary theme-btn"><?php echo e(__('Update')); ?></button>
                                    </div>
                                </div>
                            </form>
                            <!-- Fees Settings end-->
                        </div>
                    </div>
                    <div class="tab-pane <?php if(isset($tab) && $tab=='withdraw'): ?> show active <?php endif; ?>" id="withdraw"
                         role="tabpanel" aria-labelledby="pills-deleted-user-tab">
                        <div class="header-bar">
                            <div class="table-title">
                                <h3><?php echo e(__('Withdrawal Settings')); ?></h3>
                            </div>
                        </div>
                        <div class="profile-info-form">
                            <form method="post" action="<?php echo e(route('adminWithdrawalSettings')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-lg-6 col-12 mt-20">
                                        <div class="form-group">
                                            <label for="#"><?php echo e(__('Minimum Withdrawal Amount')); ?></label>
                                            <input type="text" class="form-control" name="minimum_withdrawal_amount"
                                                   placeholder="<?php echo e(__('Minimum withdrawal amount')); ?>"
                                                   value="<?php echo e($settings['minimum_withdrawal_amount']); ?>">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-12 mt-20">
                                        <div class="form-group">
                                            <label for="#"><?php echo e(__('Maximum Withdrawal Amount')); ?></label>
                                            <input type="text" class="form-control" name="maximum_withdrawal_amount"
                                                   placeholder="<?php echo e(__('Maximum withdrawal amount')); ?>"
                                                   value="<?php echo e($settings['maximum_withdrawal_amount']); ?>">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-12 mt-20">
                                        <div class="form-group">
                                            <label for="#"><?php echo e(__('Max. Send Limit (per day)')); ?></label>
                                            <input type="text" class="form-control" name="max_send_limit"
                                                   placeholder="<?php echo e(__('Send Limit')); ?>"
                                                   value="<?php echo e($settings['max_send_limit']); ?>">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-12  mt-20">
                                        <div class="form-group">
                                            <label for="#"><?php echo e(__('Withdrawal Fees Method')); ?></label>
                                            <div class="cp-select-area">
                                                <select class="form-control" name="send_fees_type">
                                                    <?php $__currentLoopData = sendFeesType(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key_sft=>$value_sft): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($key_sft); ?>"
                                                                <?php if($settings['send_fees_type']==$key_sft): ?> selected <?php endif; ?> ><?php echo e($value_sft); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-12 mt-20">
                                        <div class="form-group">
                                            <label for="#"><?php echo e(__('Withdrawal Fixed Fees')); ?></label>
                                            <input class="form-control" type="text" name="send_fees_fixed"
                                                   placeholder="<?php echo e(__('Send Coin Fixed Fees')); ?>"
                                                   value="<?php echo e($settings['send_fees_fixed']); ?>">
                                        </div>
                                    </div>
                                    <div class="col-6 mt-20">
                                        <div class="form-group">
                                            <label for="#"><?php echo e(__('Withdrawal Fees Percent')); ?></label>
                                            <p class="fees-wrap">
                                                <input class="form-control" type="text" name="send_fees_percentage"
                                                       placeholder="<?php echo e(__('Currency Deposit Fees in Percent')); ?>"
                                                       value="<?php echo e($settings['send_fees_percentage']); ?>">
                                                <span>%</span>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-2 col-12 mt-20">
                                        <button type="submit" class="btn"><?php echo e(__('Update')); ?></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="tab-pane <?php if(isset($tab) && $tab=='payment'): ?> show active <?php endif; ?>" id="payment"
                         role="tabpanel" aria-labelledby="pills-email-tab">
                        <div class="header-bar">
                            <div class="table-title">
                                <h3><?php echo e(__('Coin Payment Details')); ?></h3>
                            </div>
                        </div>
                        <div class="profile-info-form">
                            <form action="<?php echo e(route('adminSavePaymentSettings')); ?>" method="post"
                                  enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-lg-6 col-12 mt-20">
                                        <div class="form-group">
                                            <label for="#"><?php echo e(__('COIN PAYMENT PUBLIC KEY')); ?></label>
                                            <input class="form-control" type="text" name="COIN_PAYMENT_PUBLIC_KEY"
                                                   autocomplete="off" placeholder=""
                                                   value="<?php echo e(settings('COIN_PAYMENT_PUBLIC_KEY')); ?>">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-12 mt-20">
                                        <div class="form-group">
                                            <label for="#"><?php echo e(__('COIN PAYMENT PRIVATE KEY')); ?></label>
                                            <input class="form-control" type="text" name="COIN_PAYMENT_PRIVATE_KEY"
                                                   autocomplete="off" placeholder=""
                                                   value="<?php echo e(settings('COIN_PAYMENT_PRIVATE_KEY')); ?>">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-12 mt-20">
                                        <div class="form-group">
                                            <label for="#"><?php echo e(__('COIN PAYMENT IPN MERCHANT ID')); ?></label>
                                            <input class="form-control" type="text" name="ipn_merchant_id"
                                                   autocomplete="off" placeholder=""
                                                   value="<?php echo e(isset(settings()['ipn_merchant_id']) ? settings('ipn_merchant_id') : ''); ?>">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-12 mt-20">
                                        <div class="form-group">
                                            <label for="#"><?php echo e(__('COIN PAYMENT IPN SECRET')); ?></label>
                                            <input class="form-control" type="text" name="ipn_secret"
                                                   autocomplete="off" placeholder=""
                                                   value="<?php echo e(isset(settings()['ipn_secret']) ? settings('ipn_secret') : ''); ?>">
                                        </div>
                                    </div>








                                </div>
                                <hr>
                                <div class="header-bar">
                                    <div class="table-title">
                                        <h3><?php echo e(__('Stripe Details')); ?></h3>
                                    </div>
                                </div>
                                <div class="row">

                                    <div class="col-lg-6 col-12 mt-20">
                                        <div class="form-group">
                                            <label for="#"><?php echo e(__('STRIPE PUBLISHABLE KEY')); ?></label>
                                            <input class="form-control" type="text" name="STRIPE_KEY"
                                                   autocomplete="off" placeholder=""
                                                   value="<?php echo e(isset(settings()['STRIPE_KEY']) ? settings()['STRIPE_KEY'] : ''); ?>">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-12 mt-20">
                                        <div class="form-group">
                                            <label for="#"><?php echo e(__('STRIPE SECRET KEY')); ?></label>
                                            <input class="form-control" type="text" name="STRIPE_SECRET"
                                                   autocomplete="off" placeholder=""
                                                   value="<?php echo e(isset(settings()['STRIPE_SECRET']) ? settings()['STRIPE_SECRET'] : ''); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-2 col-12 mt-20">
                                        <button type="submit" class="button-primary theme-btn"><?php echo e(__('Update')); ?></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /User Management -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $('.nav-link').on('click', function () {
            $('.nav-link').removeClass('active');
            $(this).addClass('active');
            var str = '#' + $(this).data('controls');
            $('.tab-pane').removeClass('show active');
            $(str).addClass('show active');
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master',['menu'=>'setting', 'sub_menu'=>'general'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/cpoket-web/resources/views/admin/settings/general.blade.php ENDPATH**/ ?>